wxc\_sdk.person\_settings.call\_intercept module
================================================

.. automodule:: wxc_sdk.person_settings.call_intercept
   :members:
   :undoc-members:
   :show-inheritance:
