wxc\_sdk.telephony.devices package
==================================

.. automodule:: wxc_sdk.telephony.devices
   :members:
   :undoc-members:
   :show-inheritance:
