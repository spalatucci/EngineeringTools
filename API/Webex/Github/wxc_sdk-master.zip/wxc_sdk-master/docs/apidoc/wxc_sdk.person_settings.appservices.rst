wxc\_sdk.person\_settings.appservices module
============================================

.. automodule:: wxc_sdk.person_settings.appservices
   :members:
   :undoc-members:
   :show-inheritance:
