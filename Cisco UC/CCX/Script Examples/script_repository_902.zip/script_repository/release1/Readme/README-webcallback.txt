webcallback.aef:
****************
Description:
============
This script is meant for a potential caller to fill out a web form specifying
their name, callback number, and perhaps a message describing what their issue
is that needs attention and then submitting it for a later callback

How it works:
=============
(1) Gets web form data such as "name" and "numberToCall" and "description"
(2) Loads a web page template to be sent back to the potential caller
(3) Substitutes any of the form data into the template to be used as a
	confirmation page for the potential caller
(4) Sends the HTTP confirmation page back to the potential caller
	(a) Saves webcallback information in a text file for a hard copy on disk.
		Records located at "/opt/cisco/uccx/Customer" and the title is saved with the form:
			name + numberToCall + ".txt"
(5) Places a phantom call to the route point for the webcallback_queueing application
(6) Creates a new session with session id the same as the contact id of the call to the
	webcallback_queueing application
(7) Sets session info with variables containing the retrieved web form data
(8) Prompts the webcallback_queueing contact (will be an agent) to call the potential caller


Instructions:
=============
For this template, you will need a file "returnPage.html" at:
	/opt/cisco/uccx/Customer location 

whose contents are:
	<html>
	<head>
		<title>Return page</title>
	</head>
	<body>
	<center>
		<h1>Confirmation Page</h1>
		<font face=verdana size=1>
		<table border=0 cellpadding=5>
		<tr>
			<td bgcolor="F5F5F5" align=right><font size=1>Name:</td>
			<td><font size=1>%name%</td>
		</tr>
		<tr>
			<td bgcolor="F5F5F5" align=right><font size=1>Callback Number:</td>
			<td><font size=1>%numberToCall%</td>
		</tr>
		<tr>
			<td bgcolor="F5F5F5" align=right><font size=1>Problem Description:</td>
			<td><font size=1>%description%</font></td>
		</tr>
		</table>
		<p><b>You will receive a call from the next available agent</b>
		</font>
	</center>
	</body>
	</html>
	
as well as an HTML form page whose contents are:
	<html>
	<form action="http://aupark-svr1.cisco.com:8080/webCallback" method=GET>
	<body>
	<center>
	<h1>Request for Web Callback</h1>
	<font face=verdana size=2>
	<table border=0>
		<tr>
			<td bgcolor="F5F5F5" align=right><font size=1>What is your name</td>
			<td><input type="text" name="name"></td>
		</tr>
		<tr>
			<td bgcolor="F5F5F5" align=right><font size=1>Number you would like us to call</td>
			<td><input type="text" name="numberToCall"></td>
		</tr>
		<tr>
			<td bgcolor="F5F5F5" align=right><font size=1>Description of Problem</td>
			<td><font size=1><input type=text name="description" size=40 maxlength=39 value="Enter brief description of problem here"></font></td>
		</tr> 
		<tr>
			<td></td>
			<td><font size=1>* limit to 40 characters</font></td>
		</tr>
		<tr>
			<td align=right><input type="submit" value="Submit"></td>
			<td><input type="reset" value="Reset"></td>
		</tr>
	</table>
	</font>
	</center>
	</form>
	</body>
	</html>
	
Remember the retrieved web form data, set them in the session variable so they
will be able to be retrieved by the agent on the CAD.
Remember to provide the route point number for the webcallback_queueing application
either in the script itself or in Application Administrator when you set up this
application

	