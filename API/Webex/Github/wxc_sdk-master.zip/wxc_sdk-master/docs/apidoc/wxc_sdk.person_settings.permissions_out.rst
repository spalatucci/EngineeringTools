wxc\_sdk.person\_settings.permissions\_out module
=================================================

.. automodule:: wxc_sdk.person_settings.permissions_out
   :members:
   :undoc-members:
   :show-inheritance:
