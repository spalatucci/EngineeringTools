wxc\_sdk.person\_settings.push\_to\_talk module
===============================================

.. automodule:: wxc_sdk.person_settings.push_to_talk
   :members:
   :undoc-members:
   :show-inheritance:
