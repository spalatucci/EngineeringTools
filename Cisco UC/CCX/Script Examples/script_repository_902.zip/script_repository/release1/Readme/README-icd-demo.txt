icd-demo.aef:
*************
Description:
============
This script is a very basic ICD application that demonstrates how to implement 
holidayCheck.aef, emergencyCheck.aef, autoAgentGreeting.aef, and agentsLoggedInCheck.aef
as subflows.