wxc\_sdk.person\_settings.sequential\_ring module
=================================================

.. automodule:: wxc_sdk.person_settings.sequential_ring
   :members:
   :undoc-members:
   :show-inheritance:
