wxc\_sdk.meetings.transcripts package
=====================================

.. automodule:: wxc_sdk.meetings.transcripts
   :members:
   :undoc-members:
   :show-inheritance:
