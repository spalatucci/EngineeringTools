wxc\_sdk.telephony.huntgroup module
===================================

.. automodule:: wxc_sdk.telephony.huntgroup
   :members:
   :undoc-members:
   :show-inheritance:
