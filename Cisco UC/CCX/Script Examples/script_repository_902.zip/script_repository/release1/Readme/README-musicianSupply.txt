musicianSupply.aef:
*******************
Installing Musician Supply Demo

1.	Obtain the appropriate scripts
	�	Download the files: musiciansupply.aef, holidayCheck.aef, leaveAMessage.aef, and positionInQueue.aef

2.	Obtain the appropriate prompts
	�	Download all of the prompts
	�	Zip the folder

3.	Upload the scripts into AppAdmin
	�	Go to Applications->Script Management
	�	Click the default folder
	�	Click the link Upload New Scripts
	�	Browse for the file.
	�	Click the Upload Button

4.	Upload the prompts into AppAdmin
	�	Go to Applications->Prompt Management
	�	One by one
		i.	Click the link Create New Folder
		ii.	Name the folder MusicianSupply
		iii.	Click the MusicianSupply folder
		iv.	Click the link Upload New Prompts
		v.	Upload the appropriate files
	�	Upload zip file
		i.	Click the link Upload Zip Files
		ii.	All the files must be zipped with some directory path (i.e. �en_US\MusiciansSupply\...�; can�t just be dropped into the default directory

5.	Create a JTAPI Call Control Group
	�	Go to Subsystems->JTAPI
	�	Click the link Add a New JTAPI Call Control Group
	�	Group ID: 0
	�	Number of CTI Ports: 50
	�	Starting Directory Number: 6000
	�	Device Name Prefix: ctip
	�	Click the Add button

6.	Create a Cisco Media Group
	�	Go to Subsystems->Cisco Media
	�	Click the link Add a New CMT Dialog Control Group
	�	Group ID: 0
	�	Maximum Number Of Channels: 50
	�	Click the Add button

7.	Create an Application
	�	Go to Applications->Application Management
	�	Click the link Add a New Application
	�	Application Type: Cisco Script Application
	�	Name: ICD_musiciansupply
	�	Description: ICD_musiciansupply
	�	ID: 1
	�	Maximum Number of Sessions: 50
	�	Script: SCRIPT[musicianSupply.aef]
	�	Select the checkboxes Welcome Prompt and QueuePrompt
	�	WelcomePrompt: P[MusicianSupply\ICDWelcome.wav]
	�	QueuePrompt: P[MusicianSupply\ICDQueue.wav]
	�	Click the Add button
	�	Click OK
	�	Click the link Add new trigger
	�	Trigger Type: Cisco JTAPI Trigger
	�	Directory Number: <Find one that is available (See Appendix A)>
	�	Language: English (United States) [en_US]
	�	Maximum Number Of sessions: 50
	�	Call Control Group: JTAPI Group #0(0)
	�	Primary Dialog Group: Cisco Media Group#0(0)
	�	Device Name: RP_<Directory Number>
	�	Description: RP_<Directory Number>
	�	Alerting Name ASCII: <Directory Number>
	�	Click the Add button
		i.	Returns to application page without telling you it failed to get the route point	

8.	Create the appropriate Skills
	�	Go to Subsystems->RmCm
	�	Click the link Skills
	�	Skill Name: bskills
	�	Click the Add button
	�	Click the link Add a new skill
	�	Skill  Name: dskills
	�	Click the Add button
	�	Click the link Add a new skill
	�	Skill Name: gskills
	�	Click the Add button

9.	Create a Resource Group
	�	Go to Subsystems->RmCm
	�	Click the link Resource Groups
	�	Click the link Add a new Resource Group
	�	Resource Group Name: anybody
	�	Click the Add button

10.	Create resources
	�	Go to the Cisco CallManager Administration
	�	Go to User Management->End User
	�	Click the Find button
	�	Click on a user (yourself)
	�	IPCC Extension: <any>
	�	Click the Diskette icon

11.	Assign Skills
	�	Go to Subsystems->RmCm
	�	Click on the link Assign Skills
	�	Select the resource
	�	Click the Add Skill button
	�	Resource Group: anybody
	�	Skills to Add: <whichever skills you choose (Use arrow buttons)>
	�	Click the Update button


12.	Create the appropriate Contact Service Queues
	�	Go to Subsystems->RmCm
	�	Click on the link Contact Service Queues
	�	Click on the link Add a new Contact Service Queue
	�	Contact Service Queue Name: anybody
	�	Resource Pool Selection Model: Resource Group
	�	Click the Next button
	�	Resource Group: anybody
	�	Click the Add button
	�	Click on the link Add a new Contact Service Queue
	�	Contact Service Queue Name: bskills
	�	Click the Next button
	�	Select Skills: bskills
	�	Click the Add button in the Skills Required section
	�	Click the Add button
	�	Click on the link Add a new Contact Service Queue
	�	Contact Service Queue Name: dskills
	�	Click the Next button
	�	Select Skills: dskills
	�	Click the Add button in the Skills Required section
	�	Click the Add button
	�	Click on the link Add a new Contact Service Queue
	�	Contact Service Queue Name: gskills
	�	Click the Next button
	�	Select Skills: gskills
	�	Click the Add button in the Skills Required section
	�	Click the Add button

13.	Edit the Teams
	�	Go to Subsystem->RmCm
	�	Click on the link Teams
	�	Click on the default team
	�	Assigned CSQ: <Everything>
	�	Click the Update button

14.	Install the Cisco IPCC Express Agent Desktop
	�	Go to Tools->Plug-ins
	�	Click the link Cisco IPCC Express Desktop Product Suite
	�	Click the link Cisco IPCC Express Agent Desktop
	�	Save it to your computer
	�	Install the program
