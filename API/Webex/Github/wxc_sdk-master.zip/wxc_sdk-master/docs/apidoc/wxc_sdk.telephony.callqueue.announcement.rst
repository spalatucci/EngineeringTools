wxc\_sdk.telephony.callqueue.announcement module
================================================

.. automodule:: wxc_sdk.telephony.callqueue.announcement
   :members:
   :undoc-members:
   :show-inheritance:
