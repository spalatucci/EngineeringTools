wxc\_sdk.person\_settings.msteams module
========================================

.. automodule:: wxc_sdk.person_settings.msteams
   :members:
   :undoc-members:
   :show-inheritance:
