wxc\_sdk.telephony.callqueue.policies module
============================================

.. automodule:: wxc_sdk.telephony.callqueue.policies
   :members:
   :undoc-members:
   :show-inheritance:
