wxc\_sdk.people package
=======================

.. automodule:: wxc_sdk.people
   :members:
   :undoc-members:
   :show-inheritance:
