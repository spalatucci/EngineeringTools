wxc\_sdk.memberships package
============================

.. automodule:: wxc_sdk.memberships
   :members:
   :undoc-members:
   :show-inheritance:
