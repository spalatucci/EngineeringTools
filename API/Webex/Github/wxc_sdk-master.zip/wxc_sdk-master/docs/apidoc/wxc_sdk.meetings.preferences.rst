wxc\_sdk.meetings.preferences package
=====================================

.. automodule:: wxc_sdk.meetings.preferences
   :members:
   :undoc-members:
   :show-inheritance:
