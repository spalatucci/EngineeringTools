wxc\_sdk.telephony.forwarding module
====================================

.. automodule:: wxc_sdk.telephony.forwarding
   :members:
   :undoc-members:
   :show-inheritance:
