wxc\_sdk.person\_settings.forwarding module
===========================================

.. automodule:: wxc_sdk.person_settings.forwarding
   :members:
   :undoc-members:
   :show-inheritance:
