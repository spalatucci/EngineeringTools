wxc\_sdk.workspace\_personalization package
===========================================

.. automodule:: wxc_sdk.workspace_personalization
   :members:
   :undoc-members:
   :show-inheritance:
