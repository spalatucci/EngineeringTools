wxc\_sdk.telephony.jobs package
===============================

.. automodule:: wxc_sdk.telephony.jobs
   :members:
   :undoc-members:
   :show-inheritance:
