wxc\_sdk.telephony.announcements\_repo package
==============================================

.. automodule:: wxc_sdk.telephony.announcements_repo
   :members:
   :undoc-members:
   :show-inheritance:
