wxc\_sdk.telephony.prem\_pstn.dial\_plan module
===============================================

.. automodule:: wxc_sdk.telephony.prem_pstn.dial_plan
   :members:
   :undoc-members:
   :show-inheritance:
