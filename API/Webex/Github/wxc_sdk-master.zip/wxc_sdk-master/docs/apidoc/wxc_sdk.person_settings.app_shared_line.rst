wxc\_sdk.person\_settings.app\_shared\_line module
==================================================

.. automodule:: wxc_sdk.person_settings.app_shared_line
   :members:
   :undoc-members:
   :show-inheritance:
