wxc\_sdk.scopes module
======================

.. automodule:: wxc_sdk.scopes
   :members:
   :undoc-members:
   :show-inheritance:
