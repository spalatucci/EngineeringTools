wxc\_sdk.telephony.vm\_rules module
===================================

.. automodule:: wxc_sdk.telephony.vm_rules
   :members:
   :undoc-members:
   :show-inheritance:
