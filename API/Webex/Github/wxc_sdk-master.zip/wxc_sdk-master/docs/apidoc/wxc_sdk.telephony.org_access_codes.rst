wxc\_sdk.telephony.org\_access\_codes package
=============================================

.. automodule:: wxc_sdk.telephony.org_access_codes
   :members:
   :undoc-members:
   :show-inheritance:
