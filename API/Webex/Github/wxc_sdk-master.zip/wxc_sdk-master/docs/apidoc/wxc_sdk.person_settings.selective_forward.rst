wxc\_sdk.person\_settings.selective\_forward module
===================================================

.. automodule:: wxc_sdk.person_settings.selective_forward
   :members:
   :undoc-members:
   :show-inheritance:
