wxc\_sdk.telephony.prem\_pstn.route\_list module
================================================

.. automodule:: wxc_sdk.telephony.prem_pstn.route_list
   :members:
   :undoc-members:
   :show-inheritance:
