. .\Functions\Find-CallQueueAndAutoAttendantUserLinks.ps1

. Find-CallQueueAndAutoAttendantUserLinks -SearchScope All