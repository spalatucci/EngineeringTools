wxc\_sdk.person\_settings.barge module
======================================

.. automodule:: wxc_sdk.person_settings.barge
   :members:
   :undoc-members:
   :show-inheritance:
