wxc\_sdk.workspace\_settings package
====================================

.. automodule:: wxc_sdk.workspace_settings
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   wxc_sdk.workspace_settings.devices
   wxc_sdk.workspace_settings.numbers
