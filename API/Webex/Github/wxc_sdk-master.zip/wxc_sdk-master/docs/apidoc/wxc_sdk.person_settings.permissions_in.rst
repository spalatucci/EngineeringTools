wxc\_sdk.person\_settings.permissions\_in module
================================================

.. automodule:: wxc_sdk.person_settings.permissions_in
   :members:
   :undoc-members:
   :show-inheritance:
