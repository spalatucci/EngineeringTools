wxc\_sdk.telephony.prem\_pstn.route\_group module
=================================================

.. automodule:: wxc_sdk.telephony.prem_pstn.route_group
   :members:
   :undoc-members:
   :show-inheritance:
