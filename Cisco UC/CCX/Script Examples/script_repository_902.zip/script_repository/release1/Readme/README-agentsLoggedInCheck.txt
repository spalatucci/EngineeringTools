agentsLoggedInCheck.aef
***********************
Description:
============
This script is designed to be a subflow called from an icd application such as
"MusicianSupply.aef".  This subflow checks the Overall IPCC Express to see if 
any agents are currently logged into the system.  That way, the calling script
can handle the incoming callers appropriately, such as passing them on to voicemail
instead of having them wait in the queue unnecessarily.

How it works:
=============
(1) Uses "Get Reporting Statistic" step to find out how many agents are logged in
(2) If the number logged in is less than or equal to 0 (<=) then set the boolean variable
	"hasAgents" to false, otherwise set it to true.
(3) return to the calling application


Instructions:
=============
When inserting this as a subflow in another script, be sure to map the input and output
from the calling script to agentsLoggedInCheck.aef.  
(1) Map the String variable identifying the CSQ being used in the calling app to "CSQ" on the input side
(2) Map "hasAgents" to a boolean variable that will be used to identify whether or not agents are logged in
