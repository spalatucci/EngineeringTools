var obj = [{"legend": "Deployment", "options": [{"first_version": 9.0, "formOptions": [{"selected": true, "value": "on-premises", "innerHTML": "On-Premises"}, {"value": "cloud-hybrid", "innerHTML": "Cloud-Hybrid"}, {"value": "cloud-based", "innerHTML": "Cloud-Based"}], "description": "Infrastructure", "formInput": {"onchange": "hDeploymentType(this);"}, "url": null, "last_version": 11.0, "field": "deploymenttype", "formType": "select", "help": "Select the deployment model you plan to introduce Jabber to.<br/><br/><b>On-Premises</b><br/>In most environments, Cisco Jabber for Windows does not require any configuration. You should create a configuration file for Cisco Jabber for Windows only if:<br/><ol><li>You do not install Cisco Jabber for Windows on a workstation that is registered to an Active Directory domain. Cisco Jabber for Windows uses Enhanced Directory Integration by default. If you install Cisco Jabber for Windows on a workstation that is registered to an Active Directory domain, Cisco Jabber for Windows automatically discovers the directory service and connects to a Global Catalog in the domain.</li><li>You plan to connect to Cisco Unified Communications Manager User Data Service or another supported LDAP directory instead of EDI.</li><li>Attribute mappings.</li><li>Connection settings.</li><li>Contact photo retrieval settings.</li><li>Directory search settings.</li><li>Intradomain federation settings.</li><li>Scripts that allow users to submit problem reports.</li><li>Files that enable automatic updates.</li><li>Custom embedded tabs for displaying HTML content.</li><li>URLs that enable users to reset or retrieve forgotten passwords.</li><li>Disabling screen captures.</li><li>Disabling file transfers.</li><li>Disabling video calls.</li></ol><br/><b>Cloud-Hybrid</b><br/>In most hybrid environments, Cisco Jabber for Windows does not require any configuration. You should create a configuration file for Cisco Jabber for Windows only if:<br/><br/>You plan to deploy with custom content such as the following:<ol><li>Scripts that allow users to submit problem reports.</li><li>Custom embedded tabs for displaying HTML content.</li><li>Disabling video calls.</li><li>Voicemail credentials.</li></ol><br/><b>Cloud-Based</b><br/>In a cloud-based deployment, you perform all configuration for Cisco Jabber for Windows using the Cisco WebEx Administration Tool."}, {"first_version": 9.0, "formOptions": [{"value": "9.0", "innerHTML": "9.0(x)"}, {"value": "9.1", "innerHTML": "9.1(x)"}, {"value": "9.2", "innerHTML": "9.2(x)"}, {"value": "9.6", "innerHTML": "9.6(x)"}, {"value": "9.7", "innerHTML": "9.7(x)"}, {"value": "10.5", "innerHTML": "10.5(x)"}, {"value": "10.6", "innerHTML": "10.6(x)"}, {"selected": true, "value": "11.0", "innerHTML": "11.0(x)"}], "description": "Version", "formInput": {"onchange": "hVersion(this);"}, "url": null, "last_version": 11.0, "field": "version_select", "formType": "select", "help": "Select the Jabber Client version being deployed with this XML file."}]}, {"legend": "Platforms", "options": [{"first_version": 9.6, "formOptions": [{"value": "false", "innerHTML": "false"}, {"selected": true, "value": "true", "innerHTML": "true"}], "description": "Google Android", "formInput": {"onchange": "hPlatformAndroid(this);"}, "url": null, "last_version": 11.0, "field": "j4a", "formType": "select", "help": "Select if the Jabber for Android will be using this XML file."}, {"first_version": 9.6, "formOptions": [{"value": "false", "innerHTML": "false"}, {"selected": true, "value": "true", "innerHTML": "true"}], "description": "Apple iOS", "formInput": {"onchange": "hPlatformIos(this);"}, "url": null, "last_version": 11.0, "field": "j4i", "formType": "select", "help": "Select if the Jabber for iOS (iPhone/iPad) will be using this XML file."}, {"first_version": 9.2, "formOptions": [{"value": "false", "innerHTML": "false"}, {"selected": true, "value": "true", "innerHTML": "true"}], "description": "Apple OSX", "formInput": {"onchange": "hPlatformMac(this);"}, "url": null, "last_version": 11.0, "field": "j4m", "formType": "select", "help": "Select if the Jabber for Mac will be using this XML file."}, {"first_version": 9.0, "formOptions": [{"value": "false", "innerHTML": "false"}, {"selected": true, "value": "true", "innerHTML": "true"}], "description": "Microsoft Windows", "formInput": {"onchange": "hPlatformWindows(this);"}, "url": null, "last_version": 11.0, "field": "j4w", "formType": "select", "help": "Select if the Jabber for Windows will be using this XML file."}]}, {"node": "CUCM", "legend": "Phone Credentials Configuration", "options": [{"first_version": 9.0, "formOptions": [{"value": "presence", "innerHTML": "true"}, {"selected": true, "value": "", "innerHTML": "false"}], "description": "Synch Credentials with Presence Services", "url": null, "last_version": 9.0, "field": "PhoneService_UseCredentialsFrom", "formType": "select", "help": "Specifies that Cisco Jabber for Windows uses the sign in credentials to access phone services on Cisco Unified Communications Manager.<br/><br/>You should ensure that the sign in credentials and phone service credentials are the same for the Cisco Jabber for Windows users. If you set this parameter, the Phone services section is not available on the Phone accounts tab in the Options window for the appropriate users. As a result, users are not able to specify phone service credentials."}]}, {"node": "Client", "legend": "Client", "options": [{"first_version": 10.6, "description": "Autosave Chats Location", "formInput": {"onblur": "validAbsPath(this);"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_C5ACE26A_00", "last_version": 11.0, "field": "AutosaveChatsLocation", "formType": "input", "help": "Defines the path where instant messages are saved automatically each time a\n\t\t\t\t\t\tuser closes a conversation. Use the absolute path on the local file system."}, {"first_version": 11.0, "description": "Chat Telephony Escalation Limit", "formInput": {"onblur": "validInteger(this);", "value": "25"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "ChatTelephonyEscalationLimit", "formType": "input", "help": "Cisco\n\t\t\t\t\t\tJabber for Windows only. \n\t\t\t\t\t \n \n\t\t\t\t\t \n\t\t\t\t\t\tDefines the maximum number of participants allowed when telephony escalations\n\t\t\t\t\t\tare enabled for group chats and persistent chat. \n\t\t\t\t\t \n \n\t\t\t\t\t Default value is 25 participants. 0 disables the parameter, and\n\t\t\t\t\t\tthere is no maximum limit."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Display Contact Card on Hover", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "ContactCardonHover", "formType": "select", "help": "Applies to Cisco Jabber for Windows only. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies whether users contact cards are displayed when you\n\t\t\t\t\t\thover over their names in your Contacts list. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The contact card is enabled. It is displayed if\n\t\t\t\t\t\t\t you hover over contacts' names or when you press the SPACE key over contacts'\n\t\t\t\t\t\t\t names in the hub window. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The contact card is not displayed when you hover over\n\t\t\t\t\t\t\t names in the Contacts list."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Disable Local IM History", "url": null, "last_version": 11.0, "field": "Disable_IM_History", "formType": "select", "help": "Disable the chat history within a Jabber session (by disable i mean: you are in a chat with john doe and exchange some messages , you close the chat tab and then immediately start chat with john doe again: your previous conversation has dissappeared)."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Expose Autosave chat User Preference", "url": null, "last_version": 11.0, "field": "EnableAutosave", "formType": "select", "help": "Specifies whether users can save instant messages automatically each time they close a conversation.<br><br>To actually enable the feature, EnableAutosaveUserPref must be set to TRUE"}, {"first_version": 10.6, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Autosave chat", "url": null, "last_version": 11.0, "field": "EnableAutosaveUserPref", "formType": "select", "help": "Specifies if instant messages are saved automatically each time a user closes a conversation; saving to the value specified in EnableSaveChatToFile."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Far-End-Camera-Control (FECC)", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "EnableFecc", "formType": "select", "help": "Applies to all clients. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies whether the ability to control far-end cameras is\n\t\t\t\t\t\tenabled in the client. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094Far-end camera control is enabled. The \n\t\t\t\t\t\t\t Far-End Camera Control button is enabled on the call\n\t\t\t\t\t\t\t video window. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094Far-end camera control is disabled. The \n\t\t\t\t\t\t\t Far-End Camera Control button is disabled on the\n\t\t\t\t\t\t\t call video window, even if the endpoint is capable of far-end camera control."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable PRT", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "EnablePrt", "formType": "select", "help": "Applies to Cisco Jabber for Windows and Cisco Jabber for Mac. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The \n\t\t\t\t\t\t\t Report a problem menu item is enabled in the \n\t\t\t\t\t\t\t Help menu in the client. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The Jabber menu item option \n\t\t\t\t\t\t\t Report a problem is removed from the \n\t\t\t\t\t\t\t Help menu in the client. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n\n \n\t\t\t\t\t \n \n\t\t\t\t\t If you\n\t\t\t\t\t\tdisable this parameter, users can still manually use the \n\t\t\t\t\t\tStart\n\t\t\t\t\t\t\t Menu > Cisco Jabber directory, or the Program\n\t\t\t\t\t\tfiles directory and launch the Problem Report Tool manually. If a user manually\n\t\t\t\t\t\tcreates a PRT, and this parameter value is set to false, then the zip file\n\t\t\t\t\t\tcreated from the PRT has no content."}, {"first_version": 11.0, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable PRT Encryption", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "EnablePrtEncryption", "formType": "select", "help": "Applies to Cisco Jabber for Windows and Cisco Jabber for Mac. \n\t\t\t\t\t \n \n\t\t\t\t\t Enables problem report encryption. You must configure this\n\t\t\t\t\t\tparameter with the \n\t\t\t\t\t\tPRTCertificateName parameter. \n\t\t\t\t\t \n\t\t\t\t\t\t true\u00e2\u0080\u0094PRT files sent by Jabber clients are encrypted. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false (default)\u00e2\u0080\u0094PRT files sent by Jabber clients are not\n\t\t\t\t\t\t\t encrypted. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n\n \n\t\t\t\t\t \n \n\t\t\t\t\t PRT\n\t\t\t\t\t\tencryption requires a public/private key pair to encrypt and decrypt the Cisco\n\t\t\t\t\t\tJabber problem report."}, {"first_version": 9.0, "description": "Reset Password URL", "formInput": {"onblur": "validURL(this);"}, "url": null, "last_version": 11.0, "field": "Forgot_Password_URL", "formType": "input", "help": "Specifies the URL of your web page for users to reset or retrieve forgotten passwords to authenticate to Cisco Jabber."}, {"first_version": 11.0, "formOptions": [{"value": "enable", "innerHTML": "true"}, {"selected": true, "value": "disabled", "innerHTML": "false"}], "description": "Hide Call Control Strip", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "HideCallControlStrip", "formType": "select", "help": "Cisco\n\t\t\t\t\t\tJabber for Windows only. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies whether the call control strip in the calling window\n\t\t\t\t\t\tis displayed. \n\t\t\t\t\t \n\t\t\t\t\t\t enable\u00e2\u0080\u0094Displays the call control strip during calls using Cisco\n\t\t\t\t\t\t\t Jabber. On the top bar of the window, users have a new option during calls to\n\t\t\t\t\t\t\t allow them to show or hide the call control strip for that call. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t disable (default)\u00e2\u0080\u0094Hides the call control strip during calls\n\t\t\t\t\t\t\t using Cisco Jabber. Users see a video-only window without the call control\n\t\t\t\t\t\t\t strip."}, {"first_version": 10.6, "description": "Max Number of Bookmarks", "formInput": {"onblur": "validInteger(this);", "value": "30"}, "url": null, "last_version": 11.0, "field": "MaxNumberOfBookmarks", "formType": "input", "help": "Specifies the maximum number of bookmarks allowed in persistent chat rooms."}, {"first_version": 10.5, "formOptions": [{"value": "false", "innerHTML": "false"}, {"selected": true, "value": "true", "innerHTML": "true"}], "description": "Mentions in Group Chat", "url": null, "last_version": 11.0, "field": "Mention_GroupChat", "formType": "select", "help": "Specifies whether mentions are enabled in group chat.  The default value is true."}, {"first_version": 9.7, "formOptions": [{"value": "false", "innerHTML": "false"}, {"selected": true, "value": "true", "innerHTML": "true"}], "description": "Mentions in P2P Chat", "url": null, "last_version": 11.0, "field": "Mention_P2Pchat", "formType": "select", "help": "Specifies whether mentions are enabled in person to person chat.  The default value is true."}, {"first_version": 10.5, "formOptions": [{"value": "false", "innerHTML": "false"}, {"selected": true, "value": "true", "innerHTML": "true"}], "description": "Mentions in Persistent Chat", "url": null, "last_version": 11.0, "field": "Mention_PersistentChat", "formType": "select", "help": "Specifies whether mentions are enabled in persistent chat.  The default value is true."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Persistent Chat Telephony", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "PersistentChatTelephonyEnabled", "formType": "select", "help": "Cisco\n\t\t\t\t\t\tJabber for Windows only. \n\t\t\t\t\t \n \n\t\t\t\t\t \n\t\t\t\t\t\tApplies only to persistent chat conversations. \n\t\t\t\t\t \n \n\t\t\t\t\t \n\t\t\t\t\t true (default)\u00e2\u0080\u0094Enables\n\t\t\t\t\t\t the \n\t\t\t\t\t\t Call button in persistent chat, which allows users\n\t\t\t\t\t\t to click on it to initiate a phone call. \n\t\t\t\t\t\t\nfalse\u00e2\u0080\u0094The \n\t\t\t\t\t\t Call button won't be displayed in persistent chat,\n\t\t\t\t\t\t so users can't initiate a conference."}, {"first_version": 9.7, "formOptions": [{"selected": true, "value": "false", "innerHTML": "false"}, {"value": "true", "innerHTML": "true"}], "description": "Persistent Chat", "url": null, "last_version": 11.0, "field": "Persistent_Chat_Enabled", "formType": "select", "help": "Specifies whether the Persistent Chat feature is available in the client.  The default value is false."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "Default", "innerHTML": "Default"}, {"value": "Phone_Mode", "innerHTML": "Phone_Mode"}], "description": "Phone Mode", "formInput": {"onchange": "hPhoneMode(this);"}, "url": null, "last_version": 9.2, "field": "ProductMode", "formType": "select", "help": "Specifies the Cisco Jabber for Windows product mode. Set one of the following values:<br><b>Default</b><br>Set this value if Cisco Jabber for Windows users authenticate to a presence server as the primary login.<br><br>You should choose this value if you want to provision users with instant messaging and presence as base functionality.<br><br><b>Phone_Mode</b><br>Set this value if Cisco Jabber for Windows users authenticate to Cisco Unified Communications Manager as the primary login.<br><br>You should choose this value if you plan to provision users with audio devices as base functionality."}, {"first_version": 11.0, "description": "PRT Certificate Name", "formInput": {"onblur": "validCertificateName();"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "PrtCertificateName", "formType": "input", "help": "Applies to Cisco Jabber for Windows and Cisco Jabber for Mac. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies the name of a certificate with a public key in the\n\t\t\t\t\t\tEnterprise Trust or Trusted Root Certificate Authorities certificate store. The\n\t\t\t\t\t\tcertificate public key is used to encrypt Jabber Problem reports. You must\n\t\t\t\t\t\tconfigure this parameter with the \n\t\t\t\t\t\tEnablePrtEncryption parameter."}, {"first_version": 10.6, "description": "PRT Log Server URL", "formInput": {"onblur": "validURL(this);"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_C5ACE26A_00", "last_version": 11.0, "field": "PrtLogServerURL", "formType": "input", "help": "Specifies the custom script for submitting problem reports."}, {"first_version": 9.0, "description": "PRT Log Server URL", "formInput": {"onblur": "validURL(this);"}, "url": null, "last_version": 10.5, "field": "PrtLogServerUrl", "formType": "input", "help": "Specifies the custom script for submitting problem reports.<br/><br/>Setting up problem reporting enables users to send a summary of issues that they encounter while using Cisco Jabber. There are two methods for submitting problem reports. Users can submit the problem report directly through Cisco Jabber or save locally and upload the problem report at a later time.<br/><br/>Cisco Jabber uses an HTTP POST method to submit problem reports with the file form set to 'zipFileName'. Create a custom script to accept the POST request and specify the URL of the script on your HTTP server as a configuration parameter. Because users can save problem reports locally, you should also create an HTML page with a form to enable users to upload problem reports.<br/><br/>An example script can be found <a href='https://supportforums.cisco.com/docs/DOC-25008' target='_blank'>here</a>"}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Show Recents Tab", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_C5ACE26A_00", "last_version": 11.0, "field": "ShowRecentsTab", "formType": "select", "help": "Cisco\n\t\t\t\t\t\tJabber for Windows only. \n\t\t\t\t\t \n \n\t\t\t\t\t Specify whether you want to show or hide users' call history\n\t\t\t\t\t\tfrom the \n\t\t\t\t\t\tRecents tab on the Cisco Jabber hub window. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The \n\t\t\t\t\t\t\t Recents tab is shown. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The \n\t\t\t\t\t\t\t Recents tab is hidden."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Swap Display Name Order", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_C5ACE26A_00", "last_version": 11.0, "field": "SwapDisplayNameOrder", "formType": "select", "help": "Cisco\n\t\t\t\t\t\tJabber for Windows only. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies that for certain locales, when the \n\t\t\t\t\t\tdisplayname directory field is empty or not\n\t\t\t\t\t\tavailable, users' own display names and the display names of their contacts can\n\t\t\t\t\t\tbe changed to \n\t\t\t\t\t\tLastname, Firstname format. \n\t\t\t\t\t \n \n\t\t\t\t\t \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094In the following locales: Chinese (Hong Kong),\n\t\t\t\t\t\t\t Chinese (People's Republic of China), Chinese (Taiwan), Japanese, Korean; the\n\t\t\t\t\t\t\t format for users' own display names and the display names of their contacts is\n\t\t\t\t\t\t\t in the \n\t\t\t\t\t\t\t Lastname, Firstname format. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094This feature is not available."}, {"first_version": 10.6, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "System Idle During Calls", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_C5ACE26A_00", "last_version": 11.0, "field": "SystemIdleDuringCalls", "formType": "select", "help": "Cisco\n\t\t\t\t\t\tJabber for Windows only. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the screen saver or computer lock function\n\t\t\t\t\t\tactivates during a Cisco Jabber call if the user is inactive and if the\n\t\t\t\t\t\tfunction is enabled on your Windows computer. This parameter does not control\n\t\t\t\t\t\tany behavior for incoming calls when the screen is already locked or the screen\n\t\t\t\t\t\tsaver is already on. \n\t\t\t\t\t \n\t\t\t\t\t\t true\u00e2\u0080\u0094Screen saver can activate during calls. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false (default)\u00e2\u0080\u0094Screen saver cannot activate during calls or\n\t\t\t\t\t\t\t when users receive a new incoming call alert. When the call ends or the new\n\t\t\t\t\t\t\t incoming call alert is accepted or rejected, then the screen saver or screen\n\t\t\t\t\t\t\t lock is enabled again."}, {"first_version": 10.6, "description": null, "formInput": {"onblur": "validURL(this);"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_C5ACE26A_00", "last_version": 11.0, "field": "UpdateURL", "formType": "input", "help": "Specifies the URL to the automatic updates XML definition\n\t\t\t\t\t\tfile on your HTTP server. The client uses this URL to retrieve the update XML\n\t\t\t\t\t\tfile."}, {"first_version": 9.0, "description": "Auto Update URL", "formInput": {"onblur": "validURL(this);"}, "url": null, "last_version": 10.5, "field": "UpdateUrl", "formType": "input", "help": "Specifies the XML file for automatic updates.<br/><br/>Cisco Jabber uses this URL to retrieve the update XML file from your HTTP server. You create an XML file that contains the information for the most recent version, including the URL of the installation package on the HTTP server. Cisco Jabber retrieves the XML file when users sign in, resume their computer from sleep mode, or perform a manual update request from the Help menu.<br/><br/>The XML file for automatic updates uses the following format:<br/><br/>&lt;JabberUpdate><br/>&nbsp;&nbsp;&nbsp;&lt;LatestBuildNum>value&lt;/LatestBuildNum><br/>&nbsp;&nbsp;&nbsp;&lt;LatestVersion>value&lt;/LatestVersion><br/>&nbsp;&nbsp;&nbsp;&lt;Message>value&lt;/Message><br/>&nbsp;&nbsp;&nbsp;&lt;DownloadURL>value&lt;/DownloadURL><br/>&lt;/JabberUpdate>"}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Persistent Chat Meeting", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "pChatMeeting", "formType": "select", "help": "Cisco Jabber for Windows only.\n\t\t\t\t\t \n\n\t\t\t\t\t Defines whether the \n\t\t\t\t\t\tMeet Now option is enabled in\n\t\t\t\t\t\tpersistent chat rooms.\n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094WebEx meeting capabilities are enabled\n\t\t\t\t\t\t\t for users in persistent chat rooms. Users see the \n\t\t\t\t\t\t\t Meet Now option displayed.\n\t\t\t\t\t\t \n\n\t\t\t\t\t\t\n\n\t\t\t\t\t\t false\u00e2\u0080\u0094WebEx meeting capabilities are disabled for users\n\t\t\t\t\t\t\t in persistent chat rooms. Users do not see the \n\t\t\t\t\t\t\t Meet Now option displayed."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Persistent Chat Share", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_CE6A1997_00", "last_version": 11.0, "field": "pChatShare", "formType": "select", "help": "Cisco Jabber for Windows only.\n\t\t\t\t\t \n\n\t\t\t\t\t Defines whether screen sharing capabilities are enabled in\n\t\t\t\t\t\tpersistent chat rooms.\n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094Screen sharing capabilities are enabled\n\t\t\t\t\t\t\t for users in persistent chat rooms. Users see the \n\t\t\t\t\t\t\t Share screen option displayed.\n\t\t\t\t\t\t \n\n\t\t\t\t\t\t\n\n\t\t\t\t\t\t false\u00e2\u0080\u0094Screen sharing capabilities are disabled for users\n\t\t\t\t\t\t\t in persistent chat rooms. Users do not see the \n\t\t\t\t\t\t\t Share screen option displayed."}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "false", "innerHTML": "false"}, {"value": "true", "innerHTML": "true"}], "description": "Enable Spell Check", "url": null, "last_version": 11.0, "field": "spell_check_enabled", "formType": "select", "help": "Specifies whether spell check is enabled in the client. Spell check supports autocorrect, allows users to select the correct word from a list of suggestions, and add the word to a dictionary.  The default value is false."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "", "innerHTML": "system default"}, {"value": 1030, "innerHTML": "dansk (DK)"}, {"value": 1031, "innerHTML": "Deutsh (DE)"}, {"value": 2057, "innerHTML": "English (UK)"}, {"value": 1033, "innerHTML": "English (US)"}, {"value": 3082, "innerHTML": "espanol (ES)"}, {"value": 1036, "innerHTML": "francais (FR)"}, {"value": 1043, "innerHTML": "Nederlands (NL)"}, {"value": 1045, "innerHTML": "polski (PL)"}, {"value": 1046, "innerHTML": "Portugues (BR)"}, {"value": 2070, "innerHTML": "Portugues (PT)"}, {"value": 1049, "innerHTML": "pyccknn (RU)"}, {"value": 1053, "innerHTML": "svenska (SE)"}], "description": "Default Spell Check Language", "url": null, "last_version": 11.0, "field": "spell_check_language", "formType": "select", "help": "Specifies the default spell check language for users. By default, the client uses the Jabber language as the default spell check language. You can define the default language dictionary that you want to set the client to use. From the conversation windows, users may select different default languages for each user they IM with<br><br>Use the <a target='_new' href='http://msdn.microsoft.com/en-us/goglobal/bb964664.aspx'>HexLCID Dec</a> value for the language in question."}]}, {"node": "jabber-plugin-config1", "pageIndex": 1, "options": [{"field": "refresh1", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Refresh Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab refreshes. Specify one of the following values:<br/><br/><b>true</b>: The content refreshes each time the user selects the embedded tab.<br/><br/><b>false</b>: The content refreshes only if users restart Cisco Jabber for Windows or sign out and sign in again. This is the default value.<br/><br/>Refresh is an attribute of the page element."}, {"field": "preload1", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Pre-Load Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab loads. Specify one of the following values:<br/><br/><b>true</b>:The content loads when Cisco Jabber for Windows starts.<br/><br/><b>false</b>:The content loads when users select the embedded tab. This is the default value.<br/><br/>preload is an attribute of the page element."}, {"first_version": 9.0, "description": "Tooltip Text", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "tooltip1", "formType": "input", "help": "Defines the text that displays when users hover their cursors over the embedded tab.<br/><br/>This parameter is optional."}, {"first_version": 9.0, "description": "Icon URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "icon1", "formType": "input", "help": "Specifies the URL of the icon for the embedded tab.<br/><br/>The default icon size is 32 by 21 pixels. If the icon you specify exceeds the default size, Cisco Jabber for Windows scales the icon to the default size.<br/><br/>Cisco Jabber for Windows supports any icon that Microsoft Internet Explorer can render, including jpeg, png, and gif.<br/><br/>This parameter is optional. If you do not specify an icon, or if the icon you specify does not load successfully, Cisco Jabber for Windows loads a default icon.<br/><br/>Icons for custom embedded tabs contain ten frames for each state within a single image file.<br/><br/>Each frame is 20 by 20 pixels in dimension. Provide 1 pixel of padding between each frame. 1 pixel of padding results in a working icon space of 19 by 19 pixels.<br/><br/>The background color of the image is transparent.<br/><br/>Each frame represents one of the following states in the following sequence:<ol><li>Normal</li><li>Pressed</li><li>Hover</li><li>Disabled</li><li>Focused</li><li>Selected and normal</li><li>Selected and pressed</li><li>Selected and hover</li><li>Selected and disabled</li><li>Selected and focused</li></ol>The following is an example of an icon for a custom embedded tab:<img src='http://www.cisco.com/en/US/i/300001-400000/340001-350000/343001-344000/343700.jpg'>"}, {"first_version": 9.0, "description": "Page URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "url1", "formType": "input", "help": "Specifies the URL of the content that displays in the embedded tab.<br/><br/>Cisco Jabber for Windows uses the Internet Explorer rendering engine to display the content of the embedded tab. For this reason, you can specify the URL of any content that Internet Explorer supports. However, Cisco Jabber for Windows supports Internet Explorer version 9 or earlier. If a later version of Internet Explorer is installed on a workstation, Cisco Jabber for Windows uses Internet Explorer in version 9 mode.<br/><br/>This parameter is required."}, {"ignore": true, "field": "jabberplugindelete1", "first_version": 9.0, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Jabber Plugin 1", "onclick": "hDeleteJabberPlugin(\"1\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured plugin."}], "className": "jabberplugin", "showOnLoad": false, "legend": "Jabber Plugins 1"}, {"node": "jabber-plugin-config2", "pageIndex": 2, "options": [{"field": "refresh2", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Refresh Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab refreshes. Specify one of the following values:<br/><br/><b>true</b>: The content refreshes each time the user selects the embedded tab.<br/><br/><b>false</b>: The content refreshes only if users restart Cisco Jabber for Windows or sign out and sign in again. This is the default value.<br/><br/>Refresh is an attribute of the page element."}, {"field": "preload2", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Pre-Load Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab loads. Specify one of the following values:<br/><br/><b>true</b>:The content loads when Cisco Jabber for Windows starts.<br/><br/><b>false</b>:The content loads when users select the embedded tab. This is the default value.<br/><br/>preload is an attribute of the page element."}, {"first_version": 9.0, "description": "Tooltip Text", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "tooltip2", "formType": "input", "help": "Defines the text that displays when users hover their cursors over the embedded tab.<br/><br/>This parameter is optional."}, {"first_version": 9.0, "description": "Icon URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "icon2", "formType": "input", "help": "Specifies the URL of the icon for the embedded tab.<br/><br/>The default icon size is 32 by 21 pixels. If the icon you specify exceeds the default size, Cisco Jabber for Windows scales the icon to the default size.<br/><br/>Cisco Jabber for Windows supports any icon that Microsoft Internet Explorer can render, including jpeg, png, and gif.<br/><br/>This parameter is optional. If you do not specify an icon, or if the icon you specify does not load successfully, Cisco Jabber for Windows loads a default icon.<br/><br/>Icons for custom embedded tabs contain ten frames for each state within a single image file.<br/><br/>Each frame is 20 by 20 pixels in dimension. Provide 1 pixel of padding between each frame. 1 pixel of padding results in a working icon space of 19 by 19 pixels.<br/><br/>The background color of the image is transparent.<br/><br/>Each frame represents one of the following states in the following sequence:<ol><li>Normal</li><li>Pressed</li><li>Hover</li><li>Disabled</li><li>Focused</li><li>Selected and normal</li><li>Selected and pressed</li><li>Selected and hover</li><li>Selected and disabled</li><li>Selected and focused</li></ol>The following is an example of an icon for a custom embedded tab:<img src='http://www.cisco.com/en/US/i/300001-400000/340001-350000/343001-344000/343700.jpg'>"}, {"first_version": 9.0, "description": "Page URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "url2", "formType": "input", "help": "Specifies the URL of the content that displays in the embedded tab.<br/><br/>Cisco Jabber for Windows uses the Internet Explorer rendering engine to display the content of the embedded tab. For this reason, you can specify the URL of any content that Internet Explorer supports. However, Cisco Jabber for Windows supports Internet Explorer version 9 or earlier. If a later version of Internet Explorer is installed on a workstation, Cisco Jabber for Windows uses Internet Explorer in version 9 mode.<br/><br/>This parameter is required."}, {"ignore": true, "field": "jabberplugindelete2", "first_version": 9.0, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Jabber Plugin 2", "onclick": "hDeleteJabberPlugin(\"2\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured plugin."}], "className": "jabberplugin", "showOnLoad": false, "legend": "Jabber Plugins 2"}, {"node": "jabber-plugin-config3", "pageIndex": 3, "options": [{"field": "refresh3", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Refresh Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab refreshes. Specify one of the following values:<br/><br/><b>true</b>: The content refreshes each time the user selects the embedded tab.<br/><br/><b>false</b>: The content refreshes only if users restart Cisco Jabber for Windows or sign out and sign in again. This is the default value.<br/><br/>Refresh is an attribute of the page element."}, {"field": "preload3", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Pre-Load Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab loads. Specify one of the following values:<br/><br/><b>true</b>:The content loads when Cisco Jabber for Windows starts.<br/><br/><b>false</b>:The content loads when users select the embedded tab. This is the default value.<br/><br/>preload is an attribute of the page element."}, {"first_version": 9.0, "description": "Tooltip Text", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "tooltip3", "formType": "input", "help": "Defines the text that displays when users hover their cursors over the embedded tab.<br/><br/>This parameter is optional."}, {"first_version": 9.0, "description": "Icon URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "icon3", "formType": "input", "help": "Specifies the URL of the icon for the embedded tab.<br/><br/>The default icon size is 32 by 21 pixels. If the icon you specify exceeds the default size, Cisco Jabber for Windows scales the icon to the default size.<br/><br/>Cisco Jabber for Windows supports any icon that Microsoft Internet Explorer can render, including jpeg, png, and gif.<br/><br/>This parameter is optional. If you do not specify an icon, or if the icon you specify does not load successfully, Cisco Jabber for Windows loads a default icon.<br/><br/>Icons for custom embedded tabs contain ten frames for each state within a single image file.<br/><br/>Each frame is 20 by 20 pixels in dimension. Provide 1 pixel of padding between each frame. 1 pixel of padding results in a working icon space of 19 by 19 pixels.<br/><br/>The background color of the image is transparent.<br/><br/>Each frame represents one of the following states in the following sequence:<ol><li>Normal</li><li>Pressed</li><li>Hover</li><li>Disabled</li><li>Focused</li><li>Selected and normal</li><li>Selected and pressed</li><li>Selected and hover</li><li>Selected and disabled</li><li>Selected and focused</li></ol>The following is an example of an icon for a custom embedded tab:<img src='http://www.cisco.com/en/US/i/300001-400000/340001-350000/343001-344000/343700.jpg'>"}, {"first_version": 9.0, "description": "Page URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "url3", "formType": "input", "help": "Specifies the URL of the content that displays in the embedded tab.<br/><br/>Cisco Jabber for Windows uses the Internet Explorer rendering engine to display the content of the embedded tab. For this reason, you can specify the URL of any content that Internet Explorer supports. However, Cisco Jabber for Windows supports Internet Explorer version 9 or earlier. If a later version of Internet Explorer is installed on a workstation, Cisco Jabber for Windows uses Internet Explorer in version 9 mode.<br/><br/>This parameter is required."}, {"ignore": true, "field": "jabberplugindelete3", "first_version": 9.0, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Jabber Plugin 3", "onclick": "hDeleteJabberPlugin(\"3\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured plugin."}], "className": "jabberplugin", "showOnLoad": false, "legend": "Jabber Plugins 3"}, {"node": "jabber-plugin-config4", "pageIndex": 4, "options": [{"field": "refresh4", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Refresh Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab refreshes. Specify one of the following values:<br/><br/><b>true</b>: The content refreshes each time the user selects the embedded tab.<br/><br/><b>false</b>: The content refreshes only if users restart Cisco Jabber for Windows or sign out and sign in again. This is the default value.<br/><br/>Refresh is an attribute of the page element."}, {"field": "preload4", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Pre-Load Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab loads. Specify one of the following values:<br/><br/><b>true</b>:The content loads when Cisco Jabber for Windows starts.<br/><br/><b>false</b>:The content loads when users select the embedded tab. This is the default value.<br/><br/>preload is an attribute of the page element."}, {"first_version": 9.0, "description": "Tooltip Text", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "tooltip4", "formType": "input", "help": "Defines the text that displays when users hover their cursors over the embedded tab.<br/><br/>This parameter is optional."}, {"first_version": 9.0, "description": "Icon URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "icon4", "formType": "input", "help": "Specifies the URL of the icon for the embedded tab.<br/><br/>The default icon size is 32 by 21 pixels. If the icon you specify exceeds the default size, Cisco Jabber for Windows scales the icon to the default size.<br/><br/>Cisco Jabber for Windows supports any icon that Microsoft Internet Explorer can render, including jpeg, png, and gif.<br/><br/>This parameter is optional. If you do not specify an icon, or if the icon you specify does not load successfully, Cisco Jabber for Windows loads a default icon.<br/><br/>Icons for custom embedded tabs contain ten frames for each state within a single image file.<br/><br/>Each frame is 20 by 20 pixels in dimension. Provide 1 pixel of padding between each frame. 1 pixel of padding results in a working icon space of 19 by 19 pixels.<br/><br/>The background color of the image is transparent.<br/><br/>Each frame represents one of the following states in the following sequence:<ol><li>Normal</li><li>Pressed</li><li>Hover</li><li>Disabled</li><li>Focused</li><li>Selected and normal</li><li>Selected and pressed</li><li>Selected and hover</li><li>Selected and disabled</li><li>Selected and focused</li></ol>The following is an example of an icon for a custom embedded tab:<img src='http://www.cisco.com/en/US/i/300001-400000/340001-350000/343001-344000/343700.jpg'>"}, {"first_version": 9.0, "description": "Page URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "url4", "formType": "input", "help": "Specifies the URL of the content that displays in the embedded tab.<br/><br/>Cisco Jabber for Windows uses the Internet Explorer rendering engine to display the content of the embedded tab. For this reason, you can specify the URL of any content that Internet Explorer supports. However, Cisco Jabber for Windows supports Internet Explorer version 9 or earlier. If a later version of Internet Explorer is installed on a workstation, Cisco Jabber for Windows uses Internet Explorer in version 9 mode.<br/><br/>This parameter is required."}, {"ignore": true, "field": "jabberplugindelete4", "first_version": 9.0, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Jabber Plugin 4", "onclick": "hDeleteJabberPlugin(\"4\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured plugin."}], "className": "jabberplugin", "showOnLoad": false, "legend": "Jabber Plugins 4"}, {"node": "jabber-plugin-config5", "pageIndex": 5, "options": [{"field": "refresh5", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Refresh Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab refreshes. Specify one of the following values:<br/><br/><b>true</b>: The content refreshes each time the user selects the embedded tab.<br/><br/><b>false</b>: The content refreshes only if users restart Cisco Jabber for Windows or sign out and sign in again. This is the default value.<br/><br/>Refresh is an attribute of the page element."}, {"field": "preload5", "first_version": 9.0, "formOptions": [{"selected": true, "innerHTML": "false", "value": "false"}, {"innerHTML": "true", "value": "true"}], "description": "Pre-Load Page", "formInput": {"onchange": "validPageURL(this);"}, "last_version": null, "formType": "select", "help": "Controls when the content of the embedded tab loads. Specify one of the following values:<br/><br/><b>true</b>:The content loads when Cisco Jabber for Windows starts.<br/><br/><b>false</b>:The content loads when users select the embedded tab. This is the default value.<br/><br/>preload is an attribute of the page element."}, {"first_version": 9.0, "description": "Tooltip Text", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "tooltip5", "formType": "input", "help": "Defines the text that displays when users hover their cursors over the embedded tab.<br/><br/>This parameter is optional."}, {"first_version": 9.0, "description": "Icon URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "icon5", "formType": "input", "help": "Specifies the URL of the icon for the embedded tab.<br/><br/>The default icon size is 32 by 21 pixels. If the icon you specify exceeds the default size, Cisco Jabber for Windows scales the icon to the default size.<br/><br/>Cisco Jabber for Windows supports any icon that Microsoft Internet Explorer can render, including jpeg, png, and gif.<br/><br/>This parameter is optional. If you do not specify an icon, or if the icon you specify does not load successfully, Cisco Jabber for Windows loads a default icon.<br/><br/>Icons for custom embedded tabs contain ten frames for each state within a single image file.<br/><br/>Each frame is 20 by 20 pixels in dimension. Provide 1 pixel of padding between each frame. 1 pixel of padding results in a working icon space of 19 by 19 pixels.<br/><br/>The background color of the image is transparent.<br/><br/>Each frame represents one of the following states in the following sequence:<ol><li>Normal</li><li>Pressed</li><li>Hover</li><li>Disabled</li><li>Focused</li><li>Selected and normal</li><li>Selected and pressed</li><li>Selected and hover</li><li>Selected and disabled</li><li>Selected and focused</li></ol>The following is an example of an icon for a custom embedded tab:<img src='http://www.cisco.com/en/US/i/300001-400000/340001-350000/343001-344000/343700.jpg'>"}, {"first_version": 9.0, "description": "Page URL", "formInput": {"onblur": "validPageURL(this);"}, "last_version": null, "field": "url5", "formType": "input", "help": "Specifies the URL of the content that displays in the embedded tab.<br/><br/>Cisco Jabber for Windows uses the Internet Explorer rendering engine to display the content of the embedded tab. For this reason, you can specify the URL of any content that Internet Explorer supports. However, Cisco Jabber for Windows supports Internet Explorer version 9 or earlier. If a later version of Internet Explorer is installed on a workstation, Cisco Jabber for Windows uses Internet Explorer in version 9 mode.<br/><br/>This parameter is required."}, {"ignore": true, "field": "jabberplugindelete5", "first_version": 9.0, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Jabber Plugin 5", "onclick": "hDeleteJabberPlugin(\"5\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured plugin."}], "className": "jabberplugin", "showOnLoad": false, "legend": "Jabber Plugins 5"}, {"node": "Client", "legend": "Jabber Plugins", "options": [{"first_version": 9.0, "formOptions": [{"type": "button"}], "description": "Add Jabber Plugin", "formInput": {"style": "width: 300px;", "onclick": "hAddJabberPlugin(this);", "value": "Add New Jabber Plugin", "class": "f-btn-CTA"}, "url": null, "last_version": 11.0, "field": "AddJabberPlugin", "formType": "input", "help": "Custom embedded tabs display HTML content in Cisco Jabber for Windows using the Microsoft Internet Explorer rendering engine.<br/><br/>Cisco Jabber supports up to five custom embedded tabs to display any content that Microsoft Internet Explorer supports. For example, you can create a custom embedded tab to display a web page that provides details on corporate policies or an XML file hosted on your HTTP server."}]}, {"node": "Options", "legend": "Options", "options": [{"first_version": 9.2, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Allow User Custom Tabs", "url": null, "last_version": 11.0, "field": "AllowUserCustomTabs", "formType": "select", "help": "Specifies if the calls that users send start with video.<br/><br/>False is the default value."}, {"first_version": 10.6, "formOptions": [{"innerHTML": "Disable", "value": "0"}, {"selected": true, "innerHTML": "Microsoft Outlook", "value": "1"}, {"innerHTML": "IBM Lotus Notes", "value": "2"}, {"innerHTML": "Google Calendar", "value": "3"}], "description": "Enable Calendar Integration Type", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_O491D912_00", "last_version": 11.0, "field": "CalendarIntegrationType", "formType": "select", "help": "This\n\t\t\t\t\t\tparameter works with the \n\t\t\t\t\t\tMeetings_Enabled parameter. \n\t\t\t\t\t \n\t\t\t\t\t\t 0\u00e2\u0080\u0094Disables calendar integration in the Meetings tab of the client user\n\t\t\t\t\t\t\t interface. If you disable this parameter, the Meetings tab in the client is\n\t\t\t\t\t\t\t empty, but the Meetings tab remains on the hub window.\n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t 1\u00e2\u0080\u0094Enables Microsoft Outlook calendar integration in the Meetings tab of the client user\n\t\t\t\t\t\t\t interface.\n \n\t\t\t\t\t\t\n2\u00e2\u0080\u0094Enables IBM Lotus Notes calendar integration in the Meetings tab of the client user\n\t\t\t\t\t\t\t interface.\n\n3\u00e2\u0080\u0094Enables Google Calendar integration in the Meetings tab of the client user\n\t\t\t\t\t\t\t interface.\n\n\n \n\t\t\t\t\t \nRestart Cisco Jabber to apply the changes."}, {"first_version": 10.5, "description": "Number of days to keep Call History", "formInput": {"onblur": "validInteger(this);", "value": "180"}, "url": null, "last_version": 11.0, "field": "Callhistory_Expire_Days", "formType": "input", "help": "Sets the number of days before the call history is deleted.  If the value is 0 or not specified in the configuration file the call history is not deleted until the count exceeds the maximum number of store calls."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "", "innerHTML": "None"}, {"value": "BridgeOnly", "innerHTML": "via SIP"}, {"value": "WebExOnly", "innerHTML": "via Cisco WebEx"}], "description": "Cisco Collaboration Meeting Rooms", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_OB8D83D0_00", "last_version": 11.0, "field": "ConfMediaType", "formType": "select", "help": "Specifies the conference invitation type for Cisco Collaboration\n\t\t\t\t\t\tMeeting Rooms. \n\t\t\t\t\t \n\t\t\t\t\t\t BridgeOnly\u00e2\u0080\u0094 The join button joins the conference using SIP. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t WebExOnly\u00e2\u0080\u0094The join button joins the conference using Cisco\n\t\t\t\t\t\t\t WebEx. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t \n\t\t\t\t\t\t\t Nothing defined\u00e2\u0080\u0094The join button joins the conference using SIP and the link\n\t\t\t\t\t\t\t joins the conference using Cisco WebEx."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "TopCenter", "innerHTML": "Top Center"}, {"value": "TopLeft", "innerHTML": "Top Left"}, {"value": "TopRight", "innerHTML": "Top Right"}], "description": "Docked Window Position", "url": null, "last_version": 11.0, "field": "DockedWindowPosition", "formType": "select", "help": "Sets the position of the docked window on the users screen..<br/><br/>Top Center is the default value."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Docked Window Visible", "url": null, "last_version": 11.0, "field": "DockedWindowVisible", "formType": "select", "help": "Specifies if the docked window displays when the client starts.<br/><br/>True is the default value."}, {"first_version": 11.0, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Bridge Conferencing", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_OB8D83D0_00", "last_version": 11.0, "field": "EnableBridgeConferencing", "formType": "select", "help": "Specifies if the client shows the bridge escalation options. \n\t\t\t\t\t \n\t\t\t\t\t\t true\u00e2\u0080\u0094Bridge escalations options are shown in the client. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false(default)\u00e2\u0080\u0094No bridge escalations options are shown in the\n\t\t\t\t\t\t\t client."}, {"first_version": 11.0, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Load Address Book", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_OB8D83D0_00", "last_version": 11.0, "field": "EnableLoadAddressBook", "formType": "select", "help": "Specifies if native contacts in the phone are loaded on\n\t\t\t\t\t\tCisco Jabber's contact's list.\n\t\t\t\t\t \n\n\t\t\t\t\t \n\t\t\t\t\t\t true\u00e2\u0080\u0094Loading native contacts on the Cisco Jabber's\n\t\t\t\t\t\t\t contact's list is enabled. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false(default)\u00e2\u0080\u0094Loading native contacts on the Cisco\n\t\t\t\t\t\t\t Jabber's contact's list is disabled."}, {"first_version": 10.6, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Save Chat History to Exchange", "url": null, "last_version": 11.0, "field": "EnableSaveChatHistoryToExchange", "formType": "select", "help": "Enables the client to automatically save chat histories to a Cisco Jabber Chats folder in users Microsoft Outlook application.<br><br>true \u2014 Enables saving chat history to an Outlook folder.<br><br>false (default) \u2014 Does not save chat history to an Outlook folder."}, {"first_version": 10.6, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Authenticate to Exchange with System Account", "url": null, "last_version": 11.0, "field": "ExchangeAuthenticateWithSystemAccount", "formType": "select", "help": "Authentication method to Exchange server. To save chat history to an Outlook folder, enables the client to use the Operating System account details of the logged in user to authenticate with the Exchange server. This authentication method uses the Windows NT Lan Manager (NTLM) security protocol.<br><br>true \u2014 The client uses the Operating System account details of the user to authenticate to the Exchange server.<br><Br>false (default) \u2014 The client does not use the users Operating System account details to authenticate to the Exchange server."}, {"first_version": 10.6, "description": "Auto-discover Exchange Domain", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "ExchangeAutodiscoverDomain", "formType": "input", "help": "Method of specifying server address. To save chat history to an Outlook folder, enables the client to automatically discover the Exchange servers based on users domain from their credentials.<br><br>Define the value of the parameter as the domain to discover the Exchange server. The client uses the domain to search for the Exchange server at one of the following Web addresses:<br><br>https://<domain>/autodiscover/autodiscover.svc<br><br>https://autodiscover.<domain>/ autodiscover/autodiscover.svc"}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "", "innerHTML": ""}, {"value": "CUCM", "innerHTML": "CUCM"}, {"value": "CUPS", "innerHTML": "CUPS"}, {"value": "WEBEX", "innerHTML": "WEBEX"}], "description": "Exchange User Credentials From", "url": null, "last_version": 11.0, "field": "Exchange_UseCredentialsFrom", "formType": "select", "help": "Authentication method to Exchange server. To save chat history to an Outlook folder, synchronizes the Exchange credentials with another set of credentials for users, such as the Cisco Unified Presence credentials, to authenticate to the Exchange server."}, {"first_version": 10.6, "description": "External Exchange Server address", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "ExternalExchangeServer", "formType": "input", "help": "Method of specifying server address. To save chat history to an Outlook folder, manually defines the external Exchange server."}, {"first_version": 10.6, "description": "Internal Exchange Server address", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "InternalExchangeServer", "formType": "input", "help": "Method of specifying server address. To save chat history to an Outlook folder, manually defines the internal Exchange server."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "MacAddressOnly", "innerHTML": "MacAddress Only"}, {"value": "MacAddressWithSubnet", "innerHTML": "MacAddress With Subnet"}], "description": null, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_O491D912_00", "last_version": 11.0, "field": "LOCATION_MATCHING_MODE", "formType": "select", "help": "Determines how the client detects the current network locations\n\t\t\t\t\t\tfor the Location feature. \n\t\t\t\t\t \n\t\t\t\t\t\t MacAddressOnly (default) - The client uses the Mac address of\n\t\t\t\t\t\t\t the network default gateway. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t MacAddressWithSubnet - The client uses a unique pair of subnet\n\t\t\t\t\t\t\t addresses and Mac address of the default gateway."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Location Feature", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_O491D912_00", "last_version": 11.0, "field": "Location_Enabled", "formType": "select", "help": "Specifies whether the Location tab is available in the client. \n\t\t\t\t\t \n \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The Location tab is shown in the client. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The Location tab is not shown in the client."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "ENABLED", "innerHTML": "ENABLED"}, {"value": "DISABLED", "innerHTML": "DISABLED"}, {"value": "ENABLEDNOPROMPT", "innerHTML": "ENABLEDNOPROMPT"}], "description": "Location Mode", "url": null, "last_version": 11.0, "field": "Location_Mode", "formType": "select", "help": "Specifies whether the Location feature is turned on and whether users are notified when new locations are detected.<br><br>ENABLED (default)\u2014Location feature is turned on. Users are notified when new locations are detected.<br><br>DISABLED\u2014Location feature is turned off. Users are not notified when new locations are detected.<br><br>ENABLEDNOPROMPT\u2014Location feature is turned on. Users are not notified when new locations are detected."}, {"first_version": 9.1, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Set Status to Away when inactive", "url": null, "last_version": 11.0, "field": "Set_Status_Away_On_Inactive", "formType": "select", "help": "Specifies if the availability status changes to <b>Away</b> when users are inactive.<br/><br/>True is the default value."}, {"first_version": 9.1, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Set Status to Away on OS Lock", "url": null, "last_version": 11.0, "field": "Set_Status_Away_On_Lock_OS", "formType": "select", "help": "Specifies if the availability status changes to <b>Away</b> when users lock their computers.<br/><br/>True is the default value."}, {"first_version": 9.1, "description": "Minutes of inactivity before setting status to Away", "formInput": {"onblur": "validInteger(this);", "value": "15"}, "url": null, "last_version": 11.0, "field": "Set_Status_Inactive_Timeout", "formType": "input", "help": "Specifies the amount of time, in minutes, before the availability status changes to <b>Away</b> if users are inactive.<br/><br/>15 is the default value.."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Show Contact Pictures", "url": null, "last_version": 11.0, "field": "ShowContactPictures", "formType": "select", "help": "Specifies if contact pictures display in the contact list.<br/><br/>True is the default value."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Show Offline Contacts", "url": null, "last_version": 11.0, "field": "ShowOfflineContacts", "formType": "select", "help": "Specifies if offline contacts display in the contact list.<br/><br/>True is the default value."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Start Calls with Video", "url": null, "last_version": 11.0, "field": "StartCallWithVideo", "formType": "select", "help": "Specifies if the calls that users send start with video.<br/><br/>True is the default value."}, {"first_version": 9.1, "formOptions": [{"selected": true, "value": "video", "innerHTML": "true"}, {"value": "audio", "innerHTML": "false"}], "description": "Start Calls with Video", "url": null, "last_version": 9.1, "field": "Start_Calls_With", "formType": "select", "help": "Specifies if the calls that users send start with video.<br/><br/>false shows up as 'audio' in the XML<br>true shows up as 'video' in the XML<br><br>True is the default value."}, {"first_version": 9.1, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Auto Launch Jabber on OS Start", "url": null, "last_version": 11.0, "field": "Start_Client_On_Start_OS", "formType": "select", "help": "Specifies if Cisco Jabber for Windows starts automatically when users start their computers.<br/><br/>False is the default value."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Use Bridge For Conference Calls", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_OB8D83D0_00", "last_version": 11.0, "field": "UseBridgeForConferenceCalls", "formType": "select", "help": "Specifies if users can use the conference bridge to make conference calls. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094Users see \n\t\t\t\t\t\t\t Use My Conference Service is enabled. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094Users see \n\t\t\t\t\t\t\t Use My Conference Service is disabled."}, {"first_version": 11.0, "description": null, "formInput": {"onblur": "validBridgeUri(this);"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_OB8D83D0_00", "last_version": 11.0, "field": "UserBridgeUriAdmin", "formType": "input", "help": "Specifies a pattern for the bridge uri in the client. If there\n\t\t\t\t\t\tis a value entered, the field in the client displays the value as read only."}]}, {"node": "Phone", "legend": "Phone Mode", "options": [{"first_version": 9.2, "description": "Primary CCMCIP Server", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "CcmcipServer1", "formType": "input", "help": "Specifies the address of the primary Cisco Unified Communications Manager CCMCIP service where device configuration files reside. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)<br>You should set this parameter in the client configuration only if:<br>You deploy the client in phone mode."}, {"first_version": 9.2, "description": "Secondary CCMCIP Server", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "CcmcipServer2", "formType": "input", "help": "Specifies the address of the primary Cisco Unified Communications Manager CCMCIP service where device configuration files reside. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)<br>You should set this parameter in the client configuration only if:<br>You deploy the client in phone mode."}, {"first_version": 9.2, "description": "Primary CTI Server", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "CtiServer1", "formType": "input", "help": "Specifies the address of the primary Cisco Unified Communications Manager CTIManager service where device configuration files reside. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)<br>You should set this parameter in the client configuration only if:<br>You deploy the client in phone mode."}, {"first_version": 9.2, "description": "Secondary CTI Server", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "CtiServer2", "formType": "input", "help": "Specifies the address of the primary Cisco Unified Communications Manager CTIManager service where device configuration files reside. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)<br>You should set this parameter in the client configuration only if:<br>You deploy the client in phone mode."}, {"first_version": 9.6, "description": "Backup UCM", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 9.7, "field": "DeviceAuthenticationBackupServer", "formType": "input", "help": "Specifies the address of the backup Cisco Unified Communications Manager to which users authenticate in phone mode deployments. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)"}, {"first_version": 9.6, "description": "Primary UCM", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 9.7, "field": "DeviceAuthenticationPrimaryServer", "formType": "input", "help": "Specifies the address of the primary Cisco Unified Communications Manager to which users authenticate in phone mode deployments. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)"}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Call Park", "url": null, "last_version": 11.0, "field": "EnableCallPark", "formType": "select", "help": "Specifies whether the call park feature is available in the client. To access the call park feature. choose the More option in the call window"}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "false", "innerHTML": "false"}, {"value": "true", "innerHTML": "true"}], "description": "Enable DSCP Packet Marking", "url": null, "last_version": 11.0, "field": "EnableDSCPPacketMarking", "formType": "select", "help": "Specifies if DSCP marking is applied to the packets.  The default is false."}, {"first_version": 9.6, "description": "Cisco WebEx Meeting Site URL (primary)", "formInput": {"onblur": "validURL(this);"}, "url": null, "last_version": 11.0, "field": "Meeting_Server_Address", "formType": "input", "help": "Specifies the primary Cisco WebEx meeting site URL for users.<br>The client populates this meeting site in the user's host account on the Options window. Users must then enter their credentials to set up the host account and access their Cisco WebEx meetings.<br><br>Important:<br>If you specify an invalid meeting site, users cannot add, or edit, any meetings sites in the client user interface.<br><br>This parameter is optional."}, {"first_version": 9.6, "description": "Cisco WebEx Meeting Site URL (secondary)", "formInput": {"onblur": "validURL(this);"}, "url": null, "last_version": 11.0, "field": "Meeting_Server_Address_Backup", "formType": "input", "help": "Specifies the secondary Cisco WebEx meeting site URL for users.<br><br>This parameter is optional."}, {"first_version": 9.6, "description": "Cisco WebEx Meeting Site URL (tertiary)", "formInput": {"onblur": "validURL(this);"}, "url": null, "last_version": 11.0, "field": "Meeting_Server_Address_Backup2", "formType": "input", "help": "Specifies the tertiary Cisco WebEx meeting site URL for users.<br><br>This parameter is optional."}, {"first_version": 9.2, "description": "Primary TFTP Server", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "TftpServer1", "formType": "input", "help": "Specifies the address of the primary Cisco Unified Communications Manager TFTP service where device configuration files reside. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)<br>You should set this parameter in the client configuration only if:<br>You deploy the client in phone mode.<br><br>The TFTP server address for the device configuration is different to the TFTP server address for the client configuration. During installation, you should set the address of the TFTP server where the client configuration file resides with the following argument: TFTP."}, {"first_version": 9.2, "description": "Secondary TFTP Server", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "TftpServer2", "formType": "input", "help": "Specifies the address of the primary Cisco Unified Communications Manager TFTP service where device configuration files reside. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)<br>You should set this parameter in the client configuration only if:<br>You deploy the client in phone mode.<br><br>The TFTP server address for the device configuration is different to the TFTP server address for the client configuration. During installation, you should set the address of the TFTP server where the client configuration file resides with the following argument: TFTP."}, {"first_version": 9.6, "formOptions": [{"selected": true, "value": "false", "innerHTML": "false"}, {"value": "true", "innerHTML": "true"}], "description": "Enable Group CTI load balancing", "url": null, "last_version": 11.0, "field": "useCUCMGroupForCti", "formType": "select", "help": "Specifies if the Cisco Unified CM Group handles load balancing for CTI servers. Set one of the following values:<br>true<br>The Cisco Unified CM Group handles CTI load balancing.<br><br>You should set this value in phone mode deployments only. In full UC mode, the presence server automatically handles CTI load balancing.<br><br>false<br>The Cisco Unified CM Group does not handle CTI load balancing. This is the default value."}]}, {"node": "Policies", "legend": "Policies", "options": [{"first_version": 9.6, "formOptions": [{"innerHTML": "Disable", "value": "0"}, {"selected": true, "innerHTML": "Enable", "value": "1"}], "description": "Enable Calendar Integration Type", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_O491D912_00", "last_version": 10.5, "field": "CalendarIntegrationType", "formType": "select", "help": "Enables meetings capabilities in the client. Works in conjunction with the CalendarIntegrationType parameter.\ntrue (default)\n\t\tEnables meetings capabilities, allowing you to create meetings and get reminders to join meetings.\nfalse\n\t\tDisables meetings capabilities and user interface."}, {"first_version": 11.0, "description": "Add Contact Protocol RateL imit", "formInput": {"onblur": "validInteger100(this);", "value": "3"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "AddContactProtocolRateLimit", "formType": "input", "help": "Set\n\t\t\t\t\t\trate limit for invocations of add contact protocol. This parameter is supported\n\t\t\t\t\t\tfor Synergy devices only. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value ofAddContactProtocolRateLimit within the range 1-100.\n\t\t\t\t\t\tThe default value is 3."}, {"first_version": 11.0, "description": "Add Contact Protocol Time Limit", "formInput": {"onblur": "validInteger300(this);", "value": "15"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "AddContactProtocolTimeLimit", "formType": "input", "help": "Set\n\t\t\t\t\t\ttime limit for invocations of add contact protocol. This parameter is supported\n\t\t\t\t\t\tfor Synergy devices only. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value of \n\t\t\t\t\t\t AddContactProtocolTimeLimit within the range 1s-\n\t\t\t\t\t\t300s. The default value is 15s."}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Alert On Available", "url": null, "last_version": 11.0, "field": "AlertOnAvailableEnabled", "formType": "select", "help": "Enables users to add contacts to their availability watch list.  The default is true."}, {"first_version": 10.5, "description": "BDI Directory URI Attribute", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_5/CJAB_BK_D6497E98_00_deployment-installation-guide-ciscojabber/CJAB_BK_D6497E98_00_deployment-installation-guide-ciscojabber_chapter_01001.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "BDIDirectoryURI", "formType": "input", "help": "Specifies the directory\n\t\t\t\t\t\tattribute that holds the SIP URI for users. \n\t\t\t\t\t On-Premises Deployments \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t Set one of the following as the value: \n\t\t\t\t\t\t\t \n\t\t\t\t\t\t\t\t mail \n\t\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t\t\n \n\t\t\t\t\t\t\t\t msRTCSIP-PrimaryUserAddress \n\t\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t\t\n\n \n\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t \nCloud-Based Deployments \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t Set one of the following as the value: \n\t\t\t\t\t\t\t \n\t\t\t\t\t\t\t\t mail \n\t\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t\t\n \n\t\t\t\t\t\t\t\t imaddress \n\t\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t\t\n \n\t\t\t\t\t\t\t\t workphone \n\t\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t\t\n \n\t\t\t\t\t\t\t\t homephone \n\t\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t\t\n \n\t\t\t\t\t\t\t\t mobilephone \n\t\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t\t\n\n \n\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t \n\n \n\t\t\t\t\t \n \n\t\t\t\t\t The\n\t\t\t\t\t\tmail attribute is used by default. \n\t\t\t\t\t \n \n\t\t\t\t\t \n\t\t\t\t\t\tImportant: \n\t\t\t\t\t\t The value you specify must match the directory URI setting for\n\t\t\t\t\t\t\t users in \n\t\t\t\t\t\t\t Cisco Unified\n\t\t\t\t Communications Manager\n\t\t\t\t\t\t\t or the \n\t\t\t\t\t\t\t Cisco WebEx Administration\n\t\t\t\t Tool."}, {"first_version": 9.2, "description": "Disable 3rd Party Plugins", "formInput": {"onchange": "hBlockAccessoriesManagerPlugins(this);"}, "url": null, "last_version": 11.0, "field": "BlockAccessoriesManagerPlugins", "formType": "input", "help": "Disables specific Accessories Manager plugins from third party vendors such as Jabra or Logitech. You should set the name of the plugin DLL file as the value. Use a comma to separate multiple values, for example, on Microsoft Windows:<br><br>Example:<br>JabraJabberPlugin.dll,lucpcisco.dll<br><br>There is no default value."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "OnCall", "innerHTML": "OnCall"}, {"value": "Never", "innerHTML": "Never"}], "description": null, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "CTIWindowBehaviour", "formType": "select", "help": "Applies to Cisco Jabber for Mac. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies the behavior of the conversation window when the user\n\t\t\t\t\t\thas answered a call in deskphone control mode (CTI mode). \n\t\t\t\t\t \n\t\t\t\t\t\t OnCall (defalut)\u00e2\u0080\u0094Conversation window is always displayed when a\n\t\t\t\t\t\t\t call is answered. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t Never\u00e2\u0080\u0094Conversation window is never displayed when a call is\n\t\t\t\t\t\t\t answered. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n\n \n\t\t\t\t\t \n \n\t\t\t\t\t If you\n\t\t\t\t\t\tconfigured this parameter for earlier versions of Cisco Jabber for Windows, it\n\t\t\t\t\t\tcan still be used for this release. However, we recommend using the \n\t\t\t\t\t\tDeskPhoneModeWIndowBehavior parameter instead."}, {"first_version": 10.6, "description": "Calendar Auto Refresh Time", "formInput": {"onblur": "validInteger(this);", "value": "0"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 10.6, "field": "CalendarAutoRefreshTime", "formType": "input", "help": "Cisco Jabber for Windows only.\n\t\t\t\t\t \n\n\t\t\t\t\t Specifies the number of minutes after which IBM Lotus Notes\n\t\t\t\t\t\tor Google calendars refresh.\n\t\t\t\t\t \n\n\t\t\t\t\t The default value is 0."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "CrossLaunch back notification after call ends", "url": null, "last_version": 11.0, "field": "CiscoTelProtocolCrossLaunchBackNotificationEnabled", "formType": "select", "help": "Specifies that a dialog box is enabled that provides a choice for you to go back to another application when a call ends, or to stay in Jabber.<br><br>true (default) \u2014 Dialog box is enabled.<br><br>false \u2014 Dialog box is disabled, and:<br><br>If CiscoTelProtocolCrossLaunchBackSchema contains the parameter CrossLaunchBackSchema, you cross launch back directly to the previous application.<br><br>If CiscoTelProtocolCrossLaunchBackSchema does not contains the parameter CrossLaunchBackSchema, you stay in Jabber."}, {"first_version": 10.6, "description": "CrossLaunch white list for back notifications", "formInput": {"onblur": "validCrossLaunchBackSchema(this);"}, "url": null, "last_version": 11.0, "field": "CiscoTelProtocolCrossLaunchBackSchema", "formType": "input", "help": "Specifies a white list of applications that can be cross launched back to when a call is ended.<br><br>none (default) \u2014 No list.<br><br>schema_names \u2014 Contains the schema white list. Separate by ; character."}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Confirmation when clicking on ciscotel:uri", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_5/CJAB_BK_D6497E98_00_deployment-installation-guide-ciscojabber/CJAB_BK_D6497E98_00_deployment-installation-guide-ciscojabber_chapter_01001.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "CiscoTelProtocolPermissionEnabled", "formType": "select", "help": "Specifies whether the\n\t\t\t\t\t\tpop-up window is enabled or disabled which asks users to confirm if they want\n\t\t\t\t\t\tto make a call after they click on a ciscotel:uri enabled number. \n\t\t\t\t\t true (default) \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t \n\t\t\t\t\t\t\t\tPop-up window is enabled and users are asked to confirm that they want to place\n\t\t\t\t\t\t\t\tthe call. \n\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t \nfalse \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t \n\t\t\t\t\t\t\t\tPop-up window is disabled and the call is made without requesting confirmation\n\t\t\t\t\t\t\t\tfirst. This may cause accidental or unwanted calls. \n\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t \n\n \n\t\t\t\t\t Note\u00c2\u00a0\u00c2\u00a0\u00c2\u00a0\n \n \n\t\t\t\t\t\tThe \n\t\t\t\t\t\t CiscoTelProtocolPermissionEnabled parameter replaces\n\t\t\t\t\t\t the \n\t\t\t\t\t\t EnableTelProtocolPopupWindow parameter. Both\n\t\t\t\t\t\t parameters are supported in the client, however the pop-up window is disabled\n\t\t\t\t\t\t if either parameter is set to false."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Confirmation when clicking on ciscotel:uri", "url": null, "last_version": 11.0, "field": "CiscoTelProtocolPopupWindowEnabled", "formType": "select", "help": "Specifies whether the pop-up window is enabled or disabled which asks users to confirm if they want to make a call after they click on a ciscotel:uri enabled number.  The default is true."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Click-To-Call Protocol Permission Enabled", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "ClickToCallProtocolPermissionEnabled", "formType": "select", "help": "Specifies whether a dialog box is enabled or disabled which asks\n\t\t\t\t\t\tusers to confirm if they want to make a call using Cisco Jabber, after they\n\t\t\t\t\t\tclick on a clicktocall: uri link. \n\t\t\t\t\t \n\t\t\t\t\t\t true(default)\u00e2\u0080\u0094Dialog box is enabled and users are asked to\n\t\t\t\t\t\t\t confirm that they want to use Cisco Jabber to place the call. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094Dialog box is disabled and the call is made without\n\t\t\t\t\t\t\t requesting confirmation first."}, {"first_version": 10.6, "description": "CrossLaunch AppName", "formInput": {"onblur": "validAttribute(this);"}, "url": null, "last_version": 11.0, "field": "CrossLaunchBackAppName", "formType": "input", "help": "Specifies the name of an application, displayed in a dialog box, that Jabber cross launches back to when a call is ended.<br><br>none (default) \u2014 No application in the dialog box.<br><br>app_name \u2014 The application name that is displayed in the dialog box."}, {"first_version": 10.6, "description": "CrossLaunch Back Schema", "formInput": {"onblur": "validAttribute(this);"}, "url": null, "last_version": 11.0, "field": "CrossLaunchBackSchema", "formType": "input", "help": "Specifies the name of the application that Jabber cross launches back to when a call is ended.<br><br>none (default) \u2014 You stay in Jabber.<br><br>app_name \u2014 The application you cross launch back to."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Customize Phone Server", "url": null, "last_version": 11.0, "field": "Customize_Phone_Server", "formType": "select", "help": "Allows users to change their phone server settings in the client in on-premises deployments. Do not set this parameter to true if you are deploying SAML SSO, as changing phone server settings could interfere with SSO working properly.  The default is false."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Customize Voicemail Server", "url": null, "last_version": 11.0, "field": "Customize_Voicemail_Server", "formType": "select", "help": "Allows users to change their voicemail server settings in the client in on-premises deployments. Do not set this parameter to true if you are deploying SAML SSO, as changing voicemail server settings could interfere with SSO working properly.  The default is false."}, {"first_version": 11.0, "formOptions": [{"value": "OnVideo", "innerHTML": "OnVideo"}, {"selected": true, "value": "OnCall", "innerHTML": "OnCall"}, {"value": "Never", "innerHTML": "Never"}], "description": "Deskphone Mode Window Behavior", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "DeskPhoneModeWindowBehavior", "formType": "select", "help": "Applies to Cisco Jabber for Windows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies the behavior of the conversation window when the user\n\t\t\t\t\t\thas answered a call in deskphone control mode (CTI mode). \n\t\t\t\t\t \n\t\t\t\t\t\t OnVideo\u00e2\u0080\u0094Conversation window is only displayed for video calls. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t OnCall (default)\u00e2\u0080\u0094Conversation window is always displayed when a\n\t\t\t\t\t\t\t call is answered. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t Never\u00e2\u0080\u0094Conversation window is never displayed when a call is\n\t\t\t\t\t\t\t answered."}, {"first_version": 11.0, "description": "Log Duration on Disk (Desktop)", "formInput": {"onblur": "validInteger(this);"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "DetailedLogDurationDesktop", "formType": "input", "help": "If you\n\t\t\t\t\t\tconfigure the \n\t\t\t\t\t\tLogWritingDesktop parameter with the value \n\t\t\t\t\t UserCanEnable, then this parameter defines how long the\n\t\t\t\t\t desktop client writes logs to the disc. After the defined period expires, all\n\t\t\t\t\t logs are cleared from the disc."}, {"first_version": 11.0, "description": "Log Duration on Disk (Mobile)", "formInput": {"onblur": "validInteger(this);"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "DetailedLogDurationMobile", "formType": "input", "help": "If you\n\t\t\t\t\t\tconfigure the \n\t\t\t\t\t\tLogWritingMobile parameter with the value \n\t\t\t\t\t UserCanEnable, then this parameter defines how long the\n\t\t\t\t\t mobile client writes logs to the disc. After the defined period expires, all\n\t\t\t\t\t logs are cleared from the disc."}, {"first_version": 9.6, "description": "Directory URI Attribute", "url": null, "last_version": 11.0, "field": "DirectoryURI", "formType": "input", "help": "Specifies the directory attribute that holds the SIP URI for users.<b>On-Premises Deployments</b><br>Set one of the following as the 'value':<br> mail<br> msRTCSIP-PrimaryUserAddress<br><b>Cloud-Based Deployments</b><br>Set one of the following as the 'value':<br> mail<br> imaddress<br> workphone<br> homephone<br> mobilephone<br>The mail attribute is used by default.<br><br>Important:<br>The value you specify must match the directory URI setting for users in Cisco Unified Communications Manager or the Cisco WebEx Administration Tool."}, {"first_version": 10.6, "formOptions": [{"value": "P2P", "innerHTML": "P2P"}, {"value": "GroupChat", "innerHTML": "GroupChat"}, {"value": "PersistentChat", "innerHTML": "PersistentChat"}], "description": "Disable Managed File Transfer for", "url": null, "last_version": 11.0, "field": "DisableMFTForConversationTypes", "formType": "checkbox", "help": "When the Managed File Transfer option is available, this parameter specifies the conversation types that disable the setting. Use a semicolon to delimit multiple conversation types, for example P2P;GroupChat;PersistentChat."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Disable File Transfer On Mobile", "url": null, "last_version": 11.0, "field": "Disallow_File_Transfer_On_Mobile", "formType": "select", "help": "Specifies whether the user can send or receive files on mobile."}, {"first_version": 9.0, "description": "Prevent transfer of files with extensions", "url": null, "last_version": 11.0, "field": "Disallowed_File_Transfer_Types", "formType": "input", "help": "Enables you to restrict users from transferring certain file types. You can specify one or more file extensions as the value.<br/><br/>Specify the file extension in the following format: .suffixFor example, .exe<br/><br/>Use a semicolon to delimit multiple file extensions.For example, .exe;.msi;.rar;.zip"}, {"first_version": 9.2, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Accessories Manager", "url": null, "last_version": 11.0, "field": "EnableAccessoriesManager", "formType": "select", "help": "Enables the accessory manager API in the client. This API lets accessory vendors create plugins to enable call management functionality for devices such as headsets.<br><br>true - Enable the accessory manager API.<br>false - Disable the accessory manager API. This is the default value."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable BFCP Desktop Share", "url": null, "last_version": 11.0, "field": "EnableBFCPVideoDesktopShare", "formType": "select", "help": "Enables BFCP video desktop sharing capabilities. BFCP video desktop sharing is enabled by default."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Call Pickup", "url": null, "last_version": 11.0, "field": "EnableCallPickup", "formType": "select", "help": "Specifies if a user can pickup a call in their call pickup group.  The default is false."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Cisco Chat Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableCiscoChatProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android and iOS \n\t\t\t\t\t \n \n\t\t\t\t\t Enables the protocol handler for ciscochat://addbody?contactid. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default) \u00e2\u0080\u0094 Enables CiscoChat protocol \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false \u00e2\u0080\u0094 Disables CiscoChat protocol"}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Cisco IM Group Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableCiscoIMGroupProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Windows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe ciscoimgroupprotocol: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the ciscoimgroupprotocol: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the ciscoimgroupprotocol: URI."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Cisco IM Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableCiscoIMProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android, iPhone and iPad, and\n\t\t\t\t\t\tWindows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe ciscoimprotocol: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the ciscoimprotocol: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the ciscoimprotocol: URI."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Cisco Tel Conf Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableCiscoTelConfProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Windows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe ciscotelconfprotocol: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the ciscotelconfprotocol: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the ciscotelconfprotocol: URI."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Cisco Tel Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableCiscoTelProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android, iPhone and iPad, and\n\t\t\t\t\t\tWindows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe ciscotel: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the ciscotel: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the ciscotel: URI."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Click-To-Call Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableClickToCallProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android, iPhone and iPad, and\n\t\t\t\t\t\tWindows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe clicktocall: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the clicktocall: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the clicktocall: URI."}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Contact Forensics", "url": null, "last_version": 11.0, "field": "EnableForensicsContactData", "formType": "select", "help": "Specifies whether users' Contacts folder is collected by the Problem Reporting Tool (PRT) when reporting a problem that is related to their contacts."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Group Call Pickup", "url": null, "last_version": 11.0, "field": "EnableGroupCallPickup", "formType": "select", "help": "Specifies if a user can pickup incoming calls in another call pickup group, by entering the call pickup group number. The default is false."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Hunt Group", "url": null, "last_version": 11.0, "field": "EnableHuntGroup", "formType": "select", "help": "Specifies if a user can log into a hunt group. The default is false."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable IM Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableIMProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android, iPhone and iPad, and\n\t\t\t\t\t\tWindows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe improtocol: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the improtocol: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the improtocol: URI."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable IM: Protocol Handler", "url": null, "last_version": 11.0, "field": "EnableIMProtocolHandler", "formType": "select", "help": "Specifies if the client registers as the protocol handler for the IM: URI.<br><b>true</b><br>The client registers as the protocol handler for the IM: URI. This is the default value.<br><br><b>false</b><br>The client does not register as the protocol handler for the IM: URI."}, {"first_version": 10.6, "formOptions": [{"value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": null, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 10.6, "field": "EnableLoadAddressBook", "formType": "select", "help": "Specifies whether users can search and view the native contacts\n\t\t\t\t\t\tstored in their iOS device on the \n\t\t\t\t\t\tSearch or call window in Cisco Jabber for iPhone and\n\t\t\t\t\t\tiPad. \n\t\t\t\t\t\tNote\u00c2\u00a0\u00c2\u00a0\u00c2\u00a0\n \n \n\t\t\t\t\t\t This parameter is only applicable in Phone Only mode. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t \n\t\t\t\t\t\t true (default) \u00e2\u0080\u0094 Native contacts in the iOS device can be\n\t\t\t\t\t\t\t searched from the \n\t\t\t\t\t\t\t Search or call window in Cisco Jabber for iPhone and\n\t\t\t\t\t\t\t iPad. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false \u00e2\u0080\u0094 Native contacts in the iOS device cannot be searched\n\t\t\t\t\t\t\t from the \n\t\t\t\t\t\t\t Search or call window in Cisco Jabber for iPhone and\n\t\t\t\t\t\t\t iPad. \n\t\t\t\t\t\t\t Note\u00c2\u00a0\u00c2\u00a0\u00c2\u00a0\n \n \n\t\t\t\t\t\t\t\tThe users can always search the native contacts on the keypad\n\t\t\t\t\t\t\t\t window of the iOS device."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Local Address Book Search", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableLocalAddressBookSearch", "formType": "select", "help": "Lets\n\t\t\t\t\t\tusers search for and add local Microsoft Outlook contacts to their contact\n\t\t\t\t\t\tlists. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default) \u00e2\u0080\u0094 Users can search for and add local contacts to\n\t\t\t\t\t\t\t their contact lists. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false \u00e2\u0080\u0094 Users cannot search for or add local contacts to their\n\t\t\t\t\t\t\t contact lists."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "ON", "innerHTML": "ON"}, {"value": "OFF", "innerHTML": "OFF"}], "description": "Enable viewing of Media Statistics", "url": null, "last_version": 11.0, "field": "EnableMediaStatistics", "formType": "select", "help": "Allows viewing of real-time audio and video statistics when on a call.<br><br>ON (default) \u2014 EnableMediaStatistics=ON<br><br>OFF \u2014 EnableMediaStatistics=OFF"}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Other Call Pickup", "url": null, "last_version": 11.0, "field": "EnableOtherCallPickup", "formType": "select", "help": "Specifies if a user can pickup an incoming call in a group that is associated with their own call pickup group. The default is false."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable Other Group Pickup", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_5/CJAB_BK_D6497E98_00_deployment-installation-guide-ciscojabber/CJAB_BK_D6497E98_00_deployment-installation-guide-ciscojabber_chapter_01001.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableOtherGroupPickup", "formType": "select", "help": "Specifies if a user can\n\t\t\t\t\t\tpickup an incoming call in a group that is associated with their own call\n\t\t\t\t\t\tpickup group. \n\t\t\t\t\t true \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t Enables other group call pickup \n\t\t\t\t\t\t\t \n \n\t\t\t\t\t\t \n\n \n\t\t\t\t\t false (default) \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\t Disables other group call pickup"}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Allow Desktop Share without Telephony call", "url": null, "last_version": 11.0, "field": "EnableP2PDesktopShare", "formType": "select", "help": "Allows users to share their screen if not on a call. The default is true."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Profile Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableProfileProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android and iOS \n\t\t\t\t\t \n \n\t\t\t\t\t Enables the protocol handler for showing a contact's Profile\n\t\t\t\t\t\tscreen from other applications. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default) \u00e2\u0080\u0094 Enables Profile protocol \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false \u00e2\u0080\u0094 Disables Profile protocol"}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Provision Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableProvisionProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android and iOS \n\t\t\t\t\t \n \n\t\t\t\t\t Enables the protocol handler for URL provision. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default) \u00e2\u0080\u0094 Enables Provision protocol \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false \u00e2\u0080\u0094 Disables Provision protocol"}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable SIP Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableSIPProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android, iPhone and iPad, and\n\t\t\t\t\t\tWindows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe sipprotocol: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the sipprotocol: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the sipprotocol: URI."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable SIP: Protocol Handler", "url": null, "last_version": 11.0, "field": "EnableSIPProtocolHandler", "formType": "select", "help": "Specifies if the client registers as the protocol handler for the SIP: URI.<br><b>true</b><br>The client registers as the protocol handler for the SIP: URI. This is the default value.<br><br><b>false</b><br>The client does not register as the protocol handler for the SIP: URI."}, {"first_version": 9.6, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable URI Dialling", "url": null, "last_version": 11.0, "field": "EnableSIPURIDialling", "formType": "select", "help": "Enables URI dialing with Cisco Jabber and allows users to make calls with URIs.<br><b>true</b><br>Users can make calls with URIs.<br><br><b>false</b><br>Users cannot make calls with URIs. This is the default value."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable save chat to file", "url": null, "last_version": 11.0, "field": "EnableSaveChatToFile", "formType": "select", "help": "Allows users to save their chats to the file system as HTML files.<br><b>true</b><br>Users can save their chats to file. This is the default value.<br><br><b>false</b><br>Users cannot save their chats to file."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Share Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableShareProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android and iOS \n\t\t\t\t\t \n \n\t\t\t\t\t Enables the protocol handler for sharing files or messages from\n\t\t\t\t\t\tother applications to a contact through Cisco Jabber. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default) \u00e2\u0080\u0094 Enables Share protocol \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false \u00e2\u0080\u0094 Disables Share protocol"}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Status Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableStatusProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android and iOS \n\t\t\t\t\t \n \n\t\t\t\t\t Enables the protocol handler for showing the Presence or Edit\n\t\t\t\t\t\tPresence screen from other applications. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default) \u00e2\u0080\u0094 Enables Status protocol \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false \u00e2\u0080\u0094 Disables Status protocol"}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Tel Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableTelProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android, iPhone and iPad, and\n\t\t\t\t\t\tWindows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe tel: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the tel: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the tel: URI."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable tel: Protocol Handler", "url": null, "last_version": 11.0, "field": "EnableTelProtocolHandler", "formType": "select", "help": "Specifies if the client registers as the protocol handler for the tel: URI.<br><b>true</b><br>The client registers as the protocol handler for the tel: URI. This is the default value.<br><br><b>false</b><br>The client does not register as the protocol handler for the tel: URI."}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Confirmation when clicking on ciscotel:uri", "url": null, "last_version": 10.5, "field": "EnableTelProtocolPopupWindow", "formType": "select", "help": "Specifies whether the pop-up window is enabled or disabled which asks users to confirm if they want to make a call after they click on a ciscotel:uri enabled number.  The default is true."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Video", "url": null, "last_version": 11.0, "field": "EnableVideo", "formType": "select", "help": "Enables or disables Video capabilities.<br><br>True is the default value."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable XMPP Protocol", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "EnableXMPPProtocol", "formType": "select", "help": "Applicable to Cisco Jabber for Android, iPhone and iPad, and\n\t\t\t\t\t\tWindows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies if the client registers as the protocol handler for\n\t\t\t\t\t\tthe xmppprotocol: URI. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094The client registers as the protocol handler for\n\t\t\t\t\t\t\t the xmppprotocol: URI. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094The client does not register as the protocol handler for\n\t\t\t\t\t\t\t the xmppprotocol: URI."}, {"first_version": 9.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable File Transfer", "formInput": {"onchange": "hEnableFileTransfer(this);"}, "url": null, "last_version": 11.0, "field": "File_Transfer_Enabled", "formType": "select", "help": "Specifies whether users can transfer files to each other.<br><br>True is the default value."}, {"first_version": 9.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Force C2X Directory Resolution", "url": null, "last_version": 11.0, "field": "ForceC2XDirectoryResolution", "formType": "select", "help": "Specifies if the client queries the directory to resolve contact information when users perform click-to-x actions.<br><b>true</b><br>The client queries the directory when users perform click-to-x actions. This is the default value.<br><br><b>false</b><br>The client does not query the directory for click-to-x actions."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Force Font Smoothing", "url": null, "last_version": 11.0, "field": "ForceFontSmoothing", "formType": "select", "help": "Specifies if the client applies anti-aliasing to smooth text.<br><br>true - The client applies anti-aliasing to text. This is the default value.<br>false - The operating system applies anti-aliasing to text."}, {"first_version": 9.2, "formOptions": [{"value": "deskphone", "innerHTML": "Deskphone"}, {"selected": true, "value": "softphone", "innerHTML": "Softphone"}], "description": "Initial Phone Selection", "url": null, "last_version": 11.0, "field": "InitialPhoneSelection", "formType": "select", "help": "Sets the phone type for users when the client starts for the first time. Users can change their phone type after the initial start. The client then saves the user preference and uses it for subsequent starts.<br><br>deskphone - Use the desk phone device for calls.<br>softphone - Use the software phone device for calls. This is the default value.<br><br>The client selects devices in the following order:<br>Software phone devices<br>Desk phone devices<br><br>If you do not provision users with software phone devices, the client automatically selects desk phone devices."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "Always", "innerHTML": "Always"}, {"value": "UserCanEnable", "innerHTML": "Defer to user"}, {"value": "Never", "innerHTML": "Never"}], "description": "LogWriting Desktop", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "LogWritingDesktop", "formType": "select", "help": "Defines the level of security for PRT logging by specifying whether logs are\n\t\t\t\t\t\twritten to disc for desktop clients. \n\t\t\t\t\t \n\t\t\t\t\t\t Always (default)\u00e2\u0080\u0094Logs are always written to disc. No option\n\t\t\t\t\t\t\t appears in the client Help menu. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t UserCanEnable\u00e2\u0080\u0094Allows users to decide whether logs are written to\n\t\t\t\t\t\t\t disc or not. Setting this value creates an \n\t\t\t\t\t\t\t Enable Detailed Logging option in the \n\t\t\t\t\t\t\t Help menu of the client that the user can enable or\n\t\t\t\t\t\t\t disable. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t Never\u00e2\u0080\u0094Logs are never written to disc. When a PRT is manually\n\t\t\t\t\t\t\t generated, in-memory logs are flushed to a temporary file that is deleted as\n\t\t\t\t\t\t\t soon as the PRT is generated."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "Always", "innerHTML": "Always"}, {"value": "UserCanEnable", "innerHTML": "Defer to user"}, {"value": "Never", "innerHTML": "Never"}], "description": "Log Writing Mobile", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "LogWritingMobile", "formType": "select", "help": "Defines the level of security for PRT logging by specifying whether logs are\n\t\t\t\t\t\twritten to disc for mobile clients. \n\t\t\t\t\t \n\t\t\t\t\t\t Always (default)\u00e2\u0080\u0094Logs are always written to disc. No option\n\t\t\t\t\t\t\t appears in the client Help menu. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t UserCanEnable\u00e2\u0080\u0094Allows users to decide whether logs are written to\n\t\t\t\t\t\t\t disc or not. Setting this value creates a button in the mobile client called \n\t\t\t\t\t\t\t Detailed Logging that users can enable or disable. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t Never\u00e2\u0080\u0094Logs are never written to disc. When a PRT is manually\n\t\t\t\t\t\t\t generated, in-memory logs are flushed to a temporary file that is deleted as\n\t\t\t\t\t\t\t soon as the PRT is generated."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Meetings", "url": null, "last_version": 11.0, "field": "Meetings_Enabled", "formType": "select", "help": "Enables meetings capabilities and user interface in the client.<br><b>true</b><br>Enables meetings capabilities and user interface. This is the default value.<br><br><b>false</b><br>Disables meetings capabilities and user interface."}, {"first_version": 10.6, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Prefer P2P over video desktop share", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "PreferP2PDesktopShare", "formType": "select", "help": "Specifies that person to person screen sharing is preferred over\n\t\t\t\t\t\tvideo sharing. \n\t\t\t\t\t \n\t\t\t\t\t\t true \u00e2\u0080\u0094 Person to person screen sharing is preferred. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false (default) \u00e2\u0080\u0094 Video sharing is preferred."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "", "innerHTML": "use CUPS config"}, {"value": "MFT", "innerHTML": "Managed"}, {"value": "P2P", "innerHTML": "Peer-to-peer"}], "description": "Preferred File Transfer", "url": null, "last_version": 11.0, "field": "PreferredFT", "formType": "select", "help": "When Cisco Unified Communications Manager IM & Presence server provides both Managed File Transfer and Peer-to-Peer File Transfer, this parameter specifies the preferred method of transferring files in the client.<br><br>MFT \u2014 Files are transferred using the managed file transfer option.<br><br>P2P \u2014 Files are transferred using peer to peer file transfer.<br><br>If the parameter is not defined, the client checks Cisco Unified Communications Manager IM and Presence node and when managed file transfer is available the client uses this option, otherwise it uses peer to peer file transfer."}, {"first_version": 11.0, "description": "Presence Protocol Rate Limit", "formInput": {"onblur": "validInteger100(this);", "value": "3"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "PresenceProtocolRateLimit", "formType": "input", "help": "Specifies the number of times for invocations of launching the Presence or Edit\n\t\t\t\t\t\tPresence screen from other applications. This parameter is supported for\n\t\t\t\t\t\tSynergy devices only. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value ofPresenceProtocolRateLimit within the range 1-100. The\n\t\t\t\t\t\tdefault value is 3."}, {"first_version": 11.0, "description": "Presence Protocol Time Limit", "formInput": {"onblur": "validInteger300(this);", "value": "15"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "PresenceProtocolTimeLimit", "formType": "input", "help": "Sets\n\t\t\t\t\t\tthe time limit for invocations of launching the Presence or Edit Presence\n\t\t\t\t\t\tscreen from other applications. This parameter is supported for Synergy devices\n\t\t\t\t\t\tonly. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value ofPresenceProtocolTimeLimit within the range 1s- 300s.\n\t\t\t\t\t\tThe default value is 15s."}, {"first_version": 10.5, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Prevent Decline on Hunt Group", "url": null, "last_version": 11.0, "field": "PreventDeclineOnHuntCall", "formType": "select", "help": "Specifies if the Decline button is displayed for an incoming call in a hunt group. The default is false."}, {"first_version": 11.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Allow user to print chats", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "PrintIMEnabled", "formType": "select", "help": "Cisco Jabber for Windows\n\t\t\t\t\t \n\n\t\t\t\t\t Specifies whether users have the ability to print\n\t\t\t\t\t\tconversations from the chat window.\n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094Users can print conversations from the\n\t\t\t\t\t\t\t chat window by right-clicking and selecting \n\t\t\t\t\t\t\t Print.\n\t\t\t\t\t\t \n\n\t\t\t\t\t\t\n\n\t\t\t\t\t\t false\u00e2\u0080\u0094Users cannot print conversations from the chat\n\t\t\t\t\t\t\t window. If they right-click inside the window, the \n\t\t\t\t\t\t\t Print option is not in the menu."}, {"first_version": 11.0, "description": "Profile Protocol Rate Limit", "formInput": {"onblur": "validInteger100(this);", "value": "3"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "ProfileProtocolRateLimit", "formType": "input", "help": "Sets\n\t\t\t\t\t\tthe rate limit for invocations of showing the contact's Profile screen from\n\t\t\t\t\t\tother applications. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value of \n\t\t\t\t\t\t ProfileProtocolRateLimit within the range 1-100. The\n\t\t\t\t\t\tdefault value is 3."}, {"first_version": 11.0, "description": "Profile Protocol Time Limit", "formInput": {"onblur": "validInteger300(this);", "value": "15"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "ProfileProtocolTimeLimit", "formType": "input", "help": "Sets\n\t\t\t\t\t\tthe limit for invocations of showing the contact's Profile screen from other\n\t\t\t\t\t\tapplications. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value of \n\t\t\t\t\t\t ProfileProtocolTimeLimit within the range 1s- 300s.\n\t\t\t\t\t\tThe default value is 15s."}, {"first_version": 11.0, "description": "Provision Protocol Rate Limit", "formInput": {"onblur": "validInteger100(this);", "value": "3"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "ProvisionProtocolRateLimit", "formType": "input", "help": "Sets\n\t\t\t\t\t\tthe rate limit for invocations of URL provision protocol. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value of \n\t\t\t\t\t\tProvisionProtocolRateLimit within the range 1-100.\n\t\t\t\t\t\tThe default value is 3."}, {"first_version": 11.0, "description": "Provision Protocol Time Limit", "formInput": {"onblur": "validInteger300(this);", "value": "15"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "ProvisionProtocolTimeLimit", "formType": "input", "help": "Sets\n\t\t\t\t\t\tthe time limit for invocations of URL provision protocol. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value of \n\t\t\t\t\t\tProvisionProtocolTimeLimit within the range 1s- 300s.\n\t\t\t\t\t\tThe default value is 15s."}, {"first_version": 9.6, "formOptions": [{"selected": true, "value": "ON", "innerHTML": "ON"}, {"value": "OFF", "innerHTML": "OFF"}], "description": "Mobile and Remote Access", "url": null, "last_version": 11.0, "field": "RemoteAccess", "formType": "select", "help": "Enable/disable Mobile and Remote Access, ON by default."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Single Sign-On", "url": null, "last_version": 11.0, "field": "SSO_Enabled", "formType": "select", "help": "Specifies whether users sign in by using single sign-on (SSO).<br><br>TRUE (default) \u2014 Users sign in by using SSO.<br><Br>FALSE \u2014 Users do not use SSO to sign in."}, {"first_version": 9.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Screen Capture", "url": null, "last_version": 11.0, "field": "Screen_Capture_Enabled", "formType": "select", "help": "Specifies whether users can take screen captures.<br><br>True is the default value."}, {"first_version": 9.7, "formOptions": [{"value": "WEBEX", "innerHTML": "WEBEX"}, {"value": "CUCM", "innerHTML": "CUCM"}, {"value": "CUP", "innerHTML": "CUP"}], "description": "Exclude Service Discovery", "url": null, "last_version": 11.0, "field": "ServiceDiscoveryExcludedServices", "formType": "checkbox", "help": "Specifies whether to exclude certain services from Service Discovery."}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "ON", "innerHTML": "ON"}, {"value": "OFF", "innerHTML": "OFF"}], "description": "Prompt for SSO", "url": null, "last_version": 11.0, "field": "ServicesDomainSsoEmailPrompt", "formType": "select", "help": "Specifies whether the user is shown the email prompt for the purposes of determining their home cluster. The default is ON."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "OFF", "innerHTML": "OFF"}, {"value": "ON", "innerHTML": "ON"}], "description": "Show Email Prompt", "url": null, "last_version": 11.0, "field": "ServicesDomainSsoEmailPrompt", "formType": "select", "help": "Specifies whether the user is shown the email prompt for the purposes of determining their home cluster.<br><br>ON \u2014 The prompt is shown.<br><br>OFF (default) \u2014 The prompt is not shown."}, {"first_version": 10.6, "description": "Share Port Range Size", "formInput": {"onblur": "validInteger(this);"}, "url": null, "last_version": 11.0, "field": "SharePortRangeSize", "formType": "input", "help": "Specifies the size of the port range, when used with the SharePortRangeStart parameter. For more information on port ranges, see the topic on Ports and Protocols for Cisco Jabber for Windows and Cisco Jabber for Mac in the Cisco Jabber 10.5 Deployment and Installation Guide or the Cisco Jabber 10.6 Planning Guide"}, {"first_version": 10.6, "description": "Share Port Range Start", "formInput": {"onblur": "validInteger(this);"}, "url": null, "last_version": 11.0, "field": "SharePortRangeStart", "formType": "input", "help": "Defines a specific port range for the Cisco Jabber for Windows client to use when users share their screen from a chat window when used with the SharePortRangeSize parameter. If you do not configure these parameters, the client uses the default port range for IM screen share."}, {"first_version": 11.0, "description": "Share Protocol Rate Limit", "formInput": {"onblur": "validInteger100(this);", "value": "3"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "ShareProtocolRateLimit", "formType": "input", "help": "Sets\n\t\t\t\t\t\tthe rate limit for invocations of sharing files or messages. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value ofShareProtocolRateLimit within the range 1-100. The\n\t\t\t\t\t\tdefault value is 3."}, {"first_version": 11.0, "description": "Share Protocol Time Limit", "formInput": {"onblur": "validInteger300(this);", "value": "15"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "ShareProtocolTimeLimit", "formType": "input", "help": "Sets\n\t\t\t\t\t\tthe time limit for invocations of sharing files or messages. \n\t\t\t\t\t \n \n\t\t\t\t\t Set\n\t\t\t\t\t\tthe value of \n\t\t\t\t\t\tShareProtocolTimeLimit within the range 1s- 300s. The\n\t\t\t\t\t\tdefault value is 15s."}, {"first_version": 11.0, "formOptions": [{"value": "OnVideo", "innerHTML": "OnVideo"}, {"selected": true, "value": "OnCall", "innerHTML": "OnCall"}, {"value": "Never", "innerHTML": "Never"}], "description": "Softphone Mode Window Behavior", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "SoftPhoneModeWindowBehavior", "formType": "select", "help": "Applies to Cisco Jabber for Windows. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies the behavior of the conversation window when the user\n\t\t\t\t\t\thas answered a call in softphone control mode. \n\t\t\t\t\t \n\t\t\t\t\t\t OnVideo \u00e2\u0080\u0094 Conversation window is only displayed for video calls.\n\t\t\t\t\t\t\t \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t OnCall (default) \u00e2\u0080\u0094 Conversation window is always displayed when\n\t\t\t\t\t\t\t a call is answered. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t Never \u00e2\u0080\u0094 Conversation window is never displayed when a call is\n\t\t\t\t\t\t\t answered."}, {"first_version": 10.5, "description": "Aggregate Telemetry Label", "url": null, "last_version": 11.0, "field": "TelemetryCustomerID", "formType": "input", "help": "Specifies the aggregate source of analytic information. This can be a string that explicitly identifies an individual customer or a string that identifies a common source without identifying the customer. Cisco recommends using a reverse domain name (e.g. com.cisco.config_sample)."}, {"first_version": 10.5, "formOptions": [{"type": "button"}], "description": "Generate Telemetry Label Suggestion", "formInput": {"style": "width: 300px;", "onclick": "fnSuggestTelemetryCustomerIdByOrder();", "value": "Generate Suggestion", "class": "f-btn-CTA"}, "url": null, "last_version": 11.0, "field": "TelemetryCustomerIDSuggestion", "formType": "input", "help": "By inspecting data already inserted into this form, generate a suggestion of what to use as the Telemetry Label."}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Anonymous Telemetry Data", "url": null, "last_version": 11.0, "field": "TelemetryEnabled", "formType": "select", "help": "Specifies whether analytics data will be gathered.  The default is true."}, {"first_version": 10.5, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Send Telemetry data on WiFi and Cellular Networks", "url": null, "last_version": 11.0, "field": "TelemetryEnabledOverCellularData", "formType": "select", "help": "Specifies whether analytics will be sent over Wi-Fi and mobile data connections.  The default is true."}, {"first_version": 11.0, "description": "Telephony Protocol Rate Limit", "formInput": {"onblur": "validInteger100(this);", "value": "2"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "TelephonyProtocolRateLimit", "formType": "input", "help": "Applicable to Cisco Jabber for Windows, Android, and iPhone and\n\t\t\t\t\t\tiPad. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies the number of times a call can be initiated from one\n\t\t\t\t\t\tof the telephony protocol handlers (tel: ciscotel, sip). Configure this\n\t\t\t\t\t\tparameter with \n\t\t\t\t\t\tTelephonyProtocolRateLimit. The default value for the\n\t\t\t\t\t\trate limit and time limit are 2 attempts every 10 seconds. \n\t\t\t\t\t \n \n\t\t\t\t\t Value\n\t\t\t\t\t\trange is 1-100. The default value is 2. \n\t\t\t\t\t \n \n\t\t\t\t\t Note:\n\t\t\t\t\t\tOnly one protocol handler can be processed at one time. Any others arriving\n\t\t\t\t\t\twhen the user already has a call alert are either discarded or queued."}, {"first_version": 11.0, "description": "Telephony Protocol Time Limit", "formInput": {"onblur": "validInteger300(this);", "value": "10"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/11_0/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110/CJAB_BK_D657A25F_00_deployment-installation-guide-jabber-110_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "TelephonyProtocolTimeLimit", "formType": "input", "help": "Applicable to Cisco Jabber for Windows, Android, and iPhone and\n\t\t\t\t\t\tiPad. \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies the number of seconds in which a user can initiate a\n\t\t\t\t\t\tcall from one of the telephony protocol handlers (sip, tel, ciscotel) before\n\t\t\t\t\t\tthe \n\t\t\t\t\t\tTelephonyProtocolRateLimit is hit or reset. \n\t\t\t\t\t \n \n\t\t\t\t\t For\n\t\t\t\t\t\texample, if the \n\t\t\t\t\t\tTelephonyProtocolRateLimit is 2 and the \n\t\t\t\t\t\tTelephonyProtocolTimeLimit is 10 seconds, then a user\n\t\t\t\t\t\tcan initiate a call from one of the telephony protocol handlers 2 times every\n\t\t\t\t\t\t10 seconds. \n\t\t\t\t\t \n \n\t\t\t\t\t Value\n\t\t\t\t\t\trange is 1-300. The default value is 10."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Audio & Video", "url": null, "last_version": 11.0, "field": "Telephony_Enabled", "formType": "select", "help": "Enables audio & video capabilities and user interface in the client.<br><b>true</b><br>Enables audio & video capabilities and user interface. This is the default value.<br><br><b>false</b><br>Disables audio & video capabilities and user interface."}, {"first_version": 9.2, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "User Defined Remote Destinations", "url": null, "last_version": 11.0, "field": "UserDefinedRemoteDestinations", "formType": "select", "help": "Lets users add, edit, and delete remote destinations through the client interface.<br><br>true - Users can add, edit, and delete remote destinations.<br>false - Users cannot add, edit, and delete remote destinations. This is the default value.<br><br>Set the value of this parameter to true if you provision users with CTI remote devices only. This parameter does not take effect if users have software phone devices or desk phone devices as well as CTI remote devices."}, {"first_version": 9.1, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "User Defined Remote Destination", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/Windows/9_1/JABW_BK_CA48EE46_00_cisco-jabber-for-windows-administration/JABW_BK_CA48EE46_00_cisco-jabber-for-windows-administration_chapter_0101.html#JABW_RF_P720C0CF_00", "last_version": 9.1, "field": "User_Defined_Remote_Destination", "formType": "select", "help": "Lets users add, edit, and delete remote destinations through the client interface. Use this parameter to change the default behavior when you provision Extend and Connect capabilities.\nBy default, if a user's device list contains only a CTI remote device, the client does not let that user add, edit, or delete remote destinations. This occurs to prevent users from modifying dedicated remote devices that you assign. However, if the user's device list contains a software phone device or a desk phone device, the client lets users add, edit, and delete remote destinations.\ntrue\nUsers can add, edit, and delete remote destinations.\n\nfalse\nUsers cannot add, edit, and delete remote destinations. This is the default value."}, {"first_version": 9.0, "formOptions": [{"selected": true, "value": "false", "innerHTML": "true"}, {"value": "true", "innerHTML": "false"}], "description": "Enable Video Calls", "url": null, "last_version": 9.1, "field": "Video_Disabled", "formType": "select", "help": "Specifies whether users can make video calls.<br><br>True is the default value.<br><br>This is an inverted key, so false shows up as 'true' in the XML<br>true shows up as 'false' in the XML<br><br>"}, {"first_version": 9.7, "description": "Voice Services Domain", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "VoiceServicesDomain", "formType": "input", "help": "Specifies the Fully Qualified Domain Name that represents the DNS domain where the DNS SRV records for _collab-edge and _cisco-uds are configured."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Voicemail", "url": null, "last_version": 11.0, "field": "Voicemail_Enabled", "formType": "select", "help": "Enables voicemail capabilities and user interface in the client.<br><b>true</b><br>Enables voicemail capabilities and user interface. This is the default value.<br><br><b>false</b><br>Disables voicemail capabilities and user interface."}, {"first_version": 10.5, "formOptions": [{"value": "OnVideo", "innerHTML": "OnVideo"}, {"selected": true, "value": "OnCall", "innerHTML": "OnCall"}, {"value": "Never", "innerHTML": "Never"}], "description": "Deskphone Control Behavior", "url": null, "last_version": 10.6, "field": "ctiwindowbehaviour", "formType": "select", "help": "Specifies the behavior of the notification window that is displayed for incoming calls when the user is in deskphone control mode (CTI mode).  The default is OnCall."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Local AddressBook Search", "url": null, "last_version": 10.5, "field": "enableLocalAddressBookSearch", "formType": "select", "help": "Lets users search for and add local Microsoft Outlook contacts to their contact lists.<br><br>true - Users can search for and add local Microsoft Outlook contacts to their contact lists. This is the default value.<br>false - Users cannot search for or add local Microsoft Outlook contacts to their contact lists."}, {"first_version": 10.6, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Allow users to print chats", "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 10.6, "field": "printchat_enabled", "formType": "select", "help": "Cisco\n\t\t\t\t\t\tJabber for Windows \n\t\t\t\t\t \n \n\t\t\t\t\t Specifies whether users have the ability to print conversations\n\t\t\t\t\t\tfrom the chat window. \n\t\t\t\t\t \n\t\t\t\t\t\t true (default)\u00e2\u0080\u0094Users can print conversations from the chat\n\t\t\t\t\t\t\t window by right-clicking and selecting \n\t\t\t\t\t\t\t Print. \n\t\t\t\t\t\t \n \n\t\t\t\t\t\t\n \n\t\t\t\t\t\t false\u00e2\u0080\u0094Users cannot print conversations from the chat window. If\n\t\t\t\t\t\t\t they right-click inside the window, the \n\t\t\t\t\t\t\t Print option is not in the menu."}, {"first_version": 10.6, "description": "Self Care Portal FQDN", "formInput": {"onblur": "validHostname(this);"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and_chapter_01010.html#CJAB_RF_P665C309_00", "last_version": 11.0, "field": "selfcareURL", "formType": "input", "help": "Value:\n\t\t\t\t\t\tThe fully qualified domain name (FQDN) of CUCM service. \n\t\t\t\t\t \n \n\t\t\t\t\t Defines the URL for the Self Care Portal when no default service\n\t\t\t\t\t\tprofile is selected in Cisco Unified Communications Manager."}]}, {"node": "instant-message-label1", "pageIndex": 1, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(1);"}, "last_version": null, "field": "selector1", "formType": "input", "help": ""}, {"field": "fgcolor1", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(1);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor1", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(1);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(1);"}, "last_version": null, "field": "displaymarking1", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample1", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete1", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 1", "onclick": "hDeleteInstantMessageLabel(\"1\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 1"}, {"node": "instant-message-label2", "pageIndex": 2, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(2);"}, "last_version": null, "field": "selector2", "formType": "input", "help": ""}, {"field": "fgcolor2", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(2);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor2", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(2);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(2);"}, "last_version": null, "field": "displaymarking2", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample2", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete2", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 2", "onclick": "hDeleteInstantMessageLabel(\"2\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 2"}, {"node": "instant-message-label3", "pageIndex": 3, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(3);"}, "last_version": null, "field": "selector3", "formType": "input", "help": ""}, {"field": "fgcolor3", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(3);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor3", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(3);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(3);"}, "last_version": null, "field": "displaymarking3", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample3", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete3", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 3", "onclick": "hDeleteInstantMessageLabel(\"3\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 3"}, {"node": "instant-message-label4", "pageIndex": 4, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(4);"}, "last_version": null, "field": "selector4", "formType": "input", "help": ""}, {"field": "fgcolor4", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(4);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor4", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(4);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(4);"}, "last_version": null, "field": "displaymarking4", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample4", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete4", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 4", "onclick": "hDeleteInstantMessageLabel(\"4\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 4"}, {"node": "instant-message-label5", "pageIndex": 5, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(5);"}, "last_version": null, "field": "selector5", "formType": "input", "help": ""}, {"field": "fgcolor5", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(5);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor5", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(5);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(5);"}, "last_version": null, "field": "displaymarking5", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample5", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete5", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 5", "onclick": "hDeleteInstantMessageLabel(\"5\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 5"}, {"node": "instant-message-label6", "pageIndex": 6, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(6);"}, "last_version": null, "field": "selector6", "formType": "input", "help": ""}, {"field": "fgcolor6", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(6);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor6", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(6);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(6);"}, "last_version": null, "field": "displaymarking6", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample6", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete6", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 6", "onclick": "hDeleteInstantMessageLabel(\"6\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 6"}, {"node": "instant-message-label7", "pageIndex": 7, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(7);"}, "last_version": null, "field": "selector7", "formType": "input", "help": ""}, {"field": "fgcolor7", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(7);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor7", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(7);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(7);"}, "last_version": null, "field": "displaymarking7", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample7", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete7", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 7", "onclick": "hDeleteInstantMessageLabel(\"7\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 7"}, {"node": "instant-message-label8", "pageIndex": 8, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(8);"}, "last_version": null, "field": "selector8", "formType": "input", "help": ""}, {"field": "fgcolor8", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(8);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor8", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(8);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(8);"}, "last_version": null, "field": "displaymarking8", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample8", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete8", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 8", "onclick": "hDeleteInstantMessageLabel(\"8\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 8"}, {"node": "instant-message-label9", "pageIndex": 9, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(9);"}, "last_version": null, "field": "selector9", "formType": "input", "help": ""}, {"field": "fgcolor9", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(9);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor9", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(9);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(9);"}, "last_version": null, "field": "displaymarking9", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample9", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete9", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 9", "onclick": "hDeleteInstantMessageLabel(\"9\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 9"}, {"node": "instant-message-label10", "pageIndex": 10, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(10);"}, "last_version": null, "field": "selector10", "formType": "input", "help": ""}, {"field": "fgcolor10", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(10);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor10", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(10);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(10);"}, "last_version": null, "field": "displaymarking10", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample10", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete10", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 10", "onclick": "hDeleteInstantMessageLabel(\"10\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 10"}, {"node": "instant-message-label11", "pageIndex": 11, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(11);"}, "last_version": null, "field": "selector11", "formType": "input", "help": ""}, {"field": "fgcolor11", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(11);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor11", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(11);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(11);"}, "last_version": null, "field": "displaymarking11", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample11", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete11", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 11", "onclick": "hDeleteInstantMessageLabel(\"11\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 11"}, {"node": "instant-message-label12", "pageIndex": 12, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(12);"}, "last_version": null, "field": "selector12", "formType": "input", "help": ""}, {"field": "fgcolor12", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(12);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor12", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(12);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(12);"}, "last_version": null, "field": "displaymarking12", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample12", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete12", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 12", "onclick": "hDeleteInstantMessageLabel(\"12\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 12"}, {"node": "instant-message-label13", "pageIndex": 13, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(13);"}, "last_version": null, "field": "selector13", "formType": "input", "help": ""}, {"field": "fgcolor13", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(13);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor13", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(13);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(13);"}, "last_version": null, "field": "displaymarking13", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample13", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete13", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 13", "onclick": "hDeleteInstantMessageLabel(\"13\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 13"}, {"node": "instant-message-label14", "pageIndex": 14, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(14);"}, "last_version": null, "field": "selector14", "formType": "input", "help": ""}, {"field": "fgcolor14", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(14);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor14", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(14);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(14);"}, "last_version": null, "field": "displaymarking14", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample14", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete14", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 14", "onclick": "hDeleteInstantMessageLabel(\"14\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 14"}, {"node": "instant-message-label15", "pageIndex": 15, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(15);"}, "last_version": null, "field": "selector15", "formType": "input", "help": ""}, {"field": "fgcolor15", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(15);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor15", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(15);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(15);"}, "last_version": null, "field": "displaymarking15", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample15", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete15", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 15", "onclick": "hDeleteInstantMessageLabel(\"15\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 15"}, {"node": "instant-message-label16", "pageIndex": 16, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(16);"}, "last_version": null, "field": "selector16", "formType": "input", "help": ""}, {"field": "fgcolor16", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(16);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor16", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(16);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(16);"}, "last_version": null, "field": "displaymarking16", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample16", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete16", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 16", "onclick": "hDeleteInstantMessageLabel(\"16\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 16"}, {"node": "instant-message-label17", "pageIndex": 17, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(17);"}, "last_version": null, "field": "selector17", "formType": "input", "help": ""}, {"field": "fgcolor17", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(17);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor17", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(17);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(17);"}, "last_version": null, "field": "displaymarking17", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample17", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete17", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 17", "onclick": "hDeleteInstantMessageLabel(\"17\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 17"}, {"node": "instant-message-label18", "pageIndex": 18, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(18);"}, "last_version": null, "field": "selector18", "formType": "input", "help": ""}, {"field": "fgcolor18", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(18);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor18", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(18);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(18);"}, "last_version": null, "field": "displaymarking18", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample18", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete18", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 18", "onclick": "hDeleteInstantMessageLabel(\"18\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 18"}, {"node": "instant-message-label19", "pageIndex": 19, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(19);"}, "last_version": null, "field": "selector19", "formType": "input", "help": ""}, {"field": "fgcolor19", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(19);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor19", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(19);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(19);"}, "last_version": null, "field": "displaymarking19", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample19", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete19", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 19", "onclick": "hDeleteInstantMessageLabel(\"19\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 19"}, {"node": "instant-message-label20", "pageIndex": 20, "options": [{"first_version": 10.6, "description": "Dropdown Selection Text", "formInput": {"onblur": "hIMLabel(20);"}, "last_version": null, "field": "selector20", "formType": "input", "help": ""}, {"field": "fgcolor20", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"selected": true, "value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Text Color", "formInput": {"onchange": "hIMLabel(20);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Text color in of text when label is applied."}, {"field": "bgcolor20", "first_version": 10.6, "formOptions": [{"value": "Aqua", "innerHTML": "Aqua"}, {"selected": true, "value": "Black", "innerHTML": "Black"}, {"value": "Blue", "innerHTML": "Blue"}, {"value": "Fuchsia", "innerHTML": "Fuchsia"}, {"value": "Gray", "innerHTML": "Gray"}, {"value": "Green", "innerHTML": "Green"}, {"value": "Lime", "innerHTML": "Lime"}, {"value": "Maroon", "innerHTML": "Maroon"}, {"value": "Navy", "innerHTML": "Navy"}, {"value": "Olive", "innerHTML": "Olive"}, {"value": "Purple", "innerHTML": "Purple"}, {"value": "Red", "innerHTML": "Red"}, {"value": "Silver", "innerHTML": "Silver"}, {"value": "Teal", "innerHTML": "Teal"}, {"value": "White", "innerHTML": "White"}, {"value": "Yellow", "innerHTML": "Yellow"}, {"value": "Orange", "innerHTML": "Orange"}], "description": "Background Color", "formInput": {"onchange": "hIMLabel(20);"}, "alwaysInclude": true, "last_version": null, "formType": "select", "help": "Background color of text when label is applied."}, {"first_version": 10.6, "description": "Label Text", "formInput": {"onblur": "hIMLabel(20);"}, "last_version": null, "field": "displaymarking20", "formType": "input", "help": ""}, {"ignore": true, "field": "imlabelsample20", "first_version": 10.6, "description": "Sample Color", "formInput": {"class": "sample-box"}, "last_version": null, "formType": "div", "help": "Example of what this label will look like in the client."}, {"ignore": true, "field": "imlabeldelete20", "first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Remove Label", "formInput": {"style": "width: 300px;", "value": "Delete Instant Message Label 20", "onclick": "hDeleteInstantMessageLabel(\"20\");", "class": "f-btn-delete"}, "last_version": null, "formType": "input", "help": "Delete the current configured label."}], "className": "instantmessagelabel", "showOnLoad": false, "legend": "Instant Message Label 20"}, {"node": "InstantMessageLabels", "legend": "Instant Message Labels", "options": [{"first_version": 10.6, "formOptions": [{"type": "button"}], "description": "Add Instant Message Label", "formInput": {"style": "width: 300px;", "onclick": "hAddInstantMessageLabel(this);", "value": "Add New Instant Message Label", "class": "f-btn-CTA"}, "url": null, "last_version": 11.0, "field": "AddInstantMessageLabels", "formType": "input", "help": "Add configuration of Instant Message Labels.  You may configure up to 20 unique labels."}]}, {"node": "Presence", "legend": "Presence", "options": [{"first_version": 10.6, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Enable 'In a WebEx meeting' status from Outlook", "url": null, "last_version": 11.0, "field": "CalendarWebExMeetingPresence", "formType": "select", "help": "Enables users presence to change to 'In a WebEx meeting' even if they do not join the WebEx session link but the meeting is in their Microsoft Outlook calendar.<br><br>true - Users presence changes to 'In a WebEx meeting' even if they do not join the WebEx session link.<br><br>false (default) - Users must join the WebEx session link for their presence to change to 'In a WebEx meeting'. Otherwise, their presence remains 'Available', even if the meeting is in their Microsoft Outlook calendar."}, {"first_version": 9.6, "formOptions": [{"selected": true, "value": "multiResource", "innerHTML": "multiResource"}, {"value": "wbxconnect", "innerHTML": "wbxconnect"}, {"value": "mutualExclusion", "innerHTML": "mutualExclusion"}], "description": "Login Resource", "url": null, "last_version": 11.0, "field": "LoginResource", "formType": "select", "help": "Controls user log in to multiple client instances.<br><b>multiResource</b><br>Users can log in to multiple instances of the client at the same time. This is the default value.<br><br><b>wbxconnect</b><br>Users can log in to one instance of the client at a time.<br><br>The client appends the wbxconnect suffix to the user's JID. Users cannot log in to any other Cisco Jabber client that uses the wbxconnect suffix.<br><br><b>mutualExclusion</b><br>Users can log in to one instance of the client at a time, but can log in to other Cisco Jabber clients at the same time.<br><br>Each instance of the client appends the user's JID with a unique suffix."}, {"first_version": 9.2, "description": "Domain", "formInput": {"onblur": "validHostname(this);"}, "url": "http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/Windows/9_2/JABW_BK_C9731738_00_jabber-windows-install-config/JABW_BK_C9731738_00_jabber-windows-install-config_chapter_0101.html#JABW_RF_GFECBAA8_00", "last_version": 9.2, "field": "PresenceDomain", "formType": "input", "help": "Identifies the domain name of the presence server. Specify the domain name as the value of this argument; for example, domain.com.\nYou must specify this argument if the domain of the presence server is not the same as the domain of the workstations on which the client is installed.\nYou can verify the domain of your presence server as follows:Do one of the following:Cisco Unified Presence: Open the Cisco Unified Presence Administration interface.\n\nCisco Unified\n\t\t\t Communications IM and Presence: Open the Cisco Unified CM IM and Presence Administration interface.\n\n\n\n Select System > Cluster Topology.\nSelect Settings.\nNote the domain name as the value of the Domain Name field."}, {"first_version": 9.2, "description": "Server Address", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 9.2, "field": "PresenceServer", "formType": "input", "help": "Specifies the address of your presence server. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)<br>You must specify a value for this argument if your presence server does not support domain name system service records (DNS SRV). For example, Cisco Unified Presence 8.5.2 does not support DNS SRV."}, {"first_version": 9.6, "description": "Server Address", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "PresenceServerAddress", "formType": "input", "help": "Specifies the address of your presence server. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)<br>You must specify a value for this argument if your presence server does not support domain name system service records (DNS SRV). For example, Cisco Unified Presence 8.5.2 does not support DNS SRV."}, {"first_version": 9.2, "formOptions": [{"selected": true, "value": "CUP", "innerHTML": "CUP"}, {"value": "WebEx", "innerHTML": "WebEx"}], "description": "Server Type", "url": null, "last_version": 9.7, "field": "PresenceServerType", "formType": "select", "help": "Defines the type of presence server. Set one of the following values:<br><br>CUP - Cisco Unified Presence or Cisco Unified Communications IM and Presence<br>WebEx - Cisco WebEx Messenger"}, {"first_version": 9.6, "description": "CAS URL", "formInput": {"onblur": "validURL(this);"}, "url": null, "last_version": 11.0, "field": "PresenceServerURL", "formType": "input", "help": "Specifies the Central Authentication Service (CAS) URL for the Cisco WebEx Messenger service. The following is an example of a URL you can set as the 'value':<br> https://loginp.webexconnect.com/cas/sso/ex_org/orgadmin.app"}]}, {"node": "Voicemail", "legend": "Voicemail", "options": [{"first_version": 9.2, "description": "Polling Interval in Seconds", "formInput": {"onblur": "validInteger(this);"}, "url": null, "last_version": 9.2, "field": "VVM_Mailstore_PollingInterval", "formType": "input", "help": "Specifies the number of seconds between which the client polls the mailstore server for deleted messages.<br><br>0 - The client does not poll the mailstore server. The mailstore server does not notify the client when users delete voicemail messages. If you set 0 as the value, the client cannot detect when users delete voicemail messages. As a result, the client does not remove voicemail messages that users delete until the next time the users sign in.<br>1 or higher - he client polls the mailstore server at the interval you specify.<br><br>The default value is 60."}, {"first_version": 9.2, "description": "Primary Mailstore Address", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 9.7, "field": "VVM_Mailstore_Server_0", "formType": "input", "help": "Specifies the address of your mailstore server. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)"}, {"first_version": 9.0, "formOptions": [{"value": "phone", "innerHTML": "true"}, {"selected": true, "value": "", "innerHTML": "false"}], "description": "Synch Credentials with Phone Services", "url": null, "last_version": 11.0, "field": "VoiceMailService_UseCredentialsFrom", "formType": "select", "help": "Specifies that Cisco Jabber for Windows uses the sign in credentials to access voicemail services on Cisco Unity Connection.<br/<br/><b>Note</b> You should ensure that the sign in credentials and voicemail service credentials are the same for the Cisco Jabber for Windows users. If you set this parameter, the Voicemail section is not available on the Phone accounts tab in the Options window for the appropriate users. As a result, users are not able to specify voicemail service credentials."}, {"first_version": 10.5, "description": "Primary Mailstore Address", "formInput": {"onblur": "validHostname(this);"}, "url": null, "last_version": 11.0, "field": "VoicemailPrimaryServer", "formType": "input", "help": "Specifies the address of your voicemail server. Set one of the following as the 'value':<br><br>Hostname (hostname)<br>IP address (123.45.254.1)<br>FQDN (hostname.domain.com)"}]}, {"node": "Directory", "legend": "Directory", "options": [{"first_version": 9.0, "formOptions": [{"selected": true, "value": "EDI", "innerHTML": "EDI"}, {"value": "UDS", "innerHTML": "UDS"}, {"value": "BDI", "innerHTML": "BDI"}], "description": "Directory Service Type", "formInput": {"onchange": "hDirectoryServiceType(this);"}, "last_version": 11.0, "field": "DirectoryServerType", "formType": "select", "help": "Specifies the type of directory service for your deployment.<br/><br/><b>UDS</b>:Use Cisco Unified Communications Manager User Data Service as the directory service.<br/><br/><b>BDI</b>:For non-Windodws clients, ue LDAP as the directory service.<br/><br/><b>EDI</b>:One of the following:<ol><li>Use Enhanced Directory Integration as the directory service.</li><li>Connect to an LDAP directory using additional connection parameters that you specify in the configuration file.</li></ol>EDI is the default value."}, {"dirType": "edi", "formOptions": [{"selected": true, "value": "0", "innerHTML": "Global Catalog"}, {"value": "1", "innerHTML": "Domain Controller"}], "description": "Connection Type", "last_version": 11.0, "first_version": 9.0, "field": "ConnectionType", "formType": "select", "help": "Specifies whether Cisco Jabber for Windows connects to a Global Catalog (will show up as '0' in the XML) server or Domain Controller (will show up as '1' in the XML).  Connecting to a Global Catalog server typically results in quicker responses.<br><br>Global Catalog is the default value"}, {"dirType": "edi", "description": "Presence Server", "formInput": {"onblur": "validHostname(this);"}, "last_version": 9.7, "first_version": 9.7, "field": "PresenceServer", "formType": "input", "help": "Specifies the host address of the presence server."}, {"dirType": "bdi,uds", "description": "Presence Domain", "formInput": {"onblur": "validHostname(this);"}, "last_version": 11.0, "first_version": 9.7, "field": "PresenceDomain", "formType": "input", "help": "Required parameter. Specifies the domain of the presence server."}, {"dirType": "edi,bdi", "description": "Primary Directory Server", "formInput": {"onblur": "validHostname(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "PrimaryServerName", "formType": "input", "help": "Specifies the fully qualified domain name or IP address of the primary server connection for directory access.<br/><br/>You must specify this parameter if Cisco Jabber for Windows cannot automatically discover the primary AD/LDAP server from DNS."}, {"dirType": "edi,bdi", "description": "Primary TCP/UDP Port", "formInput": {"onblur": "validInteger(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "ServerPort1", "formType": "input", "help": "Specifies the primary server port.<br/><br/>You must specify this parameter if Cisco Jabber for Windows cannot automatically discover the primary AD/LDAP server from DNS."}, {"dirType": "edi,bdi", "description": "Secondary Directory Server", "formInput": {"onblur": "validHostname(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "SecondaryServerName", "formType": "input", "help": "Specifies the fully qualified domain name or IP address of the backup server connection for directory access.<br/><br/>You must specify this parameter if Cisco Jabber for Windows cannot automatically discover the backup AD/LDAP server from DNS."}, {"dirType": "edi,bdi", "description": "Secondary TCP/UDP Port", "formInput": {"onblur": "validInteger(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "ServerPort2", "formType": "input", "help": "Specifies the backup server port.<br/><br/>You must specify this parameter if Cisco Jabber for Windows cannot automatically discover the backup AD/LDAP server from DNS."}, {"dirType": "edi", "formOptions": [{"selected": true, "value": "1", "innerHTML": "Windows Credentials"}, {"value": "0", "innerHTML": "Specific Account"}], "description": "Directory Credentials", "formInput": {"onchange": "hUseWindowsCredentials(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "UseWindowsCredentials", "formType": "select", "help": "Specifies whether Cisco Jabber for Windows uses the authenticated Microsoft Windows username and password (will show up as '1' in the XML) or a specific read-only service account (will show up as '0' in the XML) for all the clients to use.<br><br>Windows Credentials is the default value."}, {"dirType": "edi,bdi", "description": "Directory Credentials Username", "formInput": {"onchange": "validConnectionUsername(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "ConnectionUsername", "formType": "input", "help": "Specifies the username to connect to the directory if you do not use Windows credentials.<br/><br/><b>Important:</b> Cisco Jabber for Windows does not encrypt the credentials that you specify in a configuration file and writes the credentials to a log file as plain text. If you specify credentials in a configuration file, you should use a shared, read-only directory account that all Cisco Jabber for Windows can use."}, {"dirType": "edi,bdi", "description": "Directory Credentials Password", "formInput": {"onblur": "validConnectionPassword(this);", "type": "password"}, "last_version": 11.0, "first_version": 9.0, "field": "ConnectionPassword", "formType": "input", "help": "Specifies the password that corresponds to the username to connect to the directory if you do not use Windows credentials.<br/><br/>Important: Cisco Jabber for Windows does not encrypt the credentials that you specify in a configuration file and writes the credentials to a log file as plain text. If you specify credentials in a configuration file, you should use a shared, read-only directory account that all Cisco Jabber for Windows can use."}, {"dirType": "edi,bdi", "formOptions": [{"selected": true, "value": "0", "innerHTML": "false"}, {"value": "1", "innerHTML": "true"}], "description": "Use SSL/TLS", "last_version": 11.0, "first_version": 9.0, "field": "UseSSL", "formType": "select", "help": "Specifies whether Cisco Jabber uses SSL/TLS for secure connections to the directory.<br><br>false shows up as '0' in the XML<br>true shows up as '1' in the XML<br><br>False is the default value."}, {"dirType": "edi,bdi", "formOptions": [{"value": "0", "innerHTML": "false"}, {"selected": true, "value": "1", "innerHTML": "true"}], "description": "Encrypt all data to Directory", "last_version": 11.0, "first_version": 9.0, "field": "UseSecureConnection", "formType": "select", "help": "Specifies whether Cisco Jabber for Windows encrypts all data including authentication and query data.<br><br>True is the default value"}, {"dirType": "bdi", "formOptions": [{"selected": true, "value": "AD", "innerHTML": "AD"}, {"value": "OpenLDAP", "innerHTML": "OpenLDAP"}], "description": "LDAP Server Type", "last_version": 11.0, "first_version": 9.2, "field": "LDAPServerType", "formType": "select", "help": "LDAP server type. Possible values are OpenLDAP or AD. Default is AD."}, {"dirType": "bdi", "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Use Jabber Credentials", "last_version": 11.0, "first_version": 9.2, "field": "UseJabberCredentials", "formType": "select", "help": "Default is False. If this is set to True, and credentials are not set in configuration or in Cisco Unified Presence, Cisco Jabber credentials will be used for login."}, {"dirType": "uds", "description": "UDS Server", "formInput": {"onblur": "validUdsServer(this);"}, "last_version": 11.0, "first_version": 9.7, "field": "UdsServer", "formType": "input", "help": "Specifies the address of the Cisco Unified Communications Manager User Data Service (UDS) server."}]}, {"node": "Directory", "dirType": "edi,bdi", "legend": "Directory Attribute Mapping", "options": [{"first_version": 9.0, "description": "Common Name", "formInput": {"onblur": "validAttribute(this);", "value": "cn"}, "last_version": 11.0, "field": "CommonName", "formType": "input", "help": "Directory attribute mapping for CommonName.<br/><br/>Default mapping is to cn."}, {"first_version": 9.0, "description": "Display Name", "formInput": {"onblur": "validAttribute(this);", "value": "displayName"}, "last_version": 11.0, "field": "DisplayName", "formType": "input", "help": "Directory attribute mapping for DisplayName.<br/><br/>Default mapping is to displayName."}, {"first_version": 9.0, "description": "First Name", "formInput": {"onblur": "validAttribute(this);", "value": "givenName"}, "last_version": 11.0, "field": "FirstName", "formType": "input", "help": "Directory attribute mapping for FirstName.<br/><br/>Default mapping is to givenName."}, {"first_version": 9.0, "description": "Last Name", "formInput": {"onblur": "validAttribute(this);", "value": "sn"}, "last_version": 11.0, "field": "LastName", "formType": "input", "help": "Directory attribute mapping for Last Name.<br/><br/>Default mapping is to sn."}, {"first_version": 9.0, "description": "Email Address", "formInput": {"onblur": "validAttribute(this);", "value": "mail"}, "last_version": 11.0, "field": "EmailAddress", "formType": "input", "help": "Directory attribute mapping for EmailAddress.<br/><br/>Default mapping is to mail."}, {"first_version": 9.0, "description": "Sip Uri", "formInput": {"onblur": "validSipUri(this);", "value": "msRTCSIP-PrimaryUserAddress"}, "last_version": 11.0, "field": "SipUri", "formType": "input", "help": "Directory attribute mapping for SipUri.<br/><br/>Default mapping is to msRTCSIP-PrimaryUserAddress"}, {"first_version": 9.0, "description": "Photograph Source", "formInput": {"onblur": "validPhoto(this);", "value": "thumbnailPhoto"}, "last_version": 11.0, "field": "PhotoSource", "formType": "input", "help": "Directory attribute mapping for PhotoSource.<br/><br/>Default mapping is to thumbnailPhoto."}, {"first_version": 9.0, "description": "Business Phone", "formInput": {"onblur": "validAttribute(this);", "value": "telephoneNumber"}, "last_version": 11.0, "field": "BusinessPhone", "formType": "input", "help": "Directory attribute mapping for BusinessPhone.<br/><br/>Default mapping is to telephoneNumber."}, {"first_version": 9.0, "description": "Mobile Phone", "formInput": {"onblur": "validAttribute(this);", "value": "mobile"}, "last_version": 11.0, "field": "MobilePhone", "formType": "input", "help": "Directory attribute mapping for MobilePhone.<br/><br/>Default mapping is to mobile."}, {"first_version": 9.0, "description": "Home Phone", "formInput": {"onblur": "validAttribute(this);", "value": "homePhone"}, "last_version": 11.0, "field": "HomePhone", "formType": "input", "help": "Directory attribute mapping for HomePhone.<br/><br/>Default mapping is to homePhone."}, {"first_version": 9.0, "description": "Other Phone", "formInput": {"onblur": "validAttribute(this);", "value": "otherTelephone"}, "last_version": 11.0, "field": "OtherPhone", "formType": "input", "help": "Directory attribute mapping for OtherPhone.<br/><br/>Default mapping is to otherTelephone."}, {"first_version": 9.0, "description": "Title", "formInput": {"onblur": "validAttribute(this);", "value": "title"}, "last_version": 11.0, "field": "Title", "formType": "input", "help": "Directory attribute mapping for Title.<br/><br/>Default mapping is to title."}, {"first_version": 9.0, "description": "Company Name", "formInput": {"onblur": "validAttribute(this);", "value": "company"}, "last_version": 11.0, "field": "CompanyName", "formType": "input", "help": "Directory attribute mapping for CompanyName.<br/><br/>Default mapping is to company."}, {"first_version": 9.0, "description": "User Account Name", "formInput": {"onblur": "validAttribute(this);", "value": "sAMAccountName"}, "last_version": 11.0, "field": "UserAccountName", "formType": "input", "help": "Directory attribute mapping for UserAccountName.<br/><br/>Default mapping is to sAMAccountName."}, {"first_version": 9.0, "description": "Domain Name", "formInput": {"onblur": "validAttribute(this);", "value": "userPrincipalName"}, "last_version": 11.0, "field": "DomainName", "formType": "input", "help": "Directory attribute mapping for DomainName.<br/><br/>Default mapping is to userPrincipalName."}, {"first_version": 9.0, "description": "Location", "formInput": {"onblur": "validAttribute(this);", "value": "co"}, "last_version": 11.0, "field": "Location", "formType": "input", "help": "Directory attribute mapping for Location.<br/><br/>Default mapping is to co."}, {"first_version": 9.0, "description": "Nick Name", "formInput": {"onblur": "validAttribute(this);", "value": "Nickname"}, "last_version": 11.0, "field": "Nickname", "formType": "input", "help": "Directory attribute mapping for Nickname.<br/><br/>Default mapping is to Nickname."}, {"first_version": 9.0, "description": "Postal Code", "formInput": {"onblur": "validAttribute(this);", "value": "postalCode"}, "last_version": 11.0, "field": "PostalCode", "formType": "input", "help": "Directory attribute mapping for PostalCode.<br/><br/>Default mapping is to postalCode."}, {"first_version": 9.1, "description": "City", "formInput": {"onblur": "validAttribute(this);", "value": "l"}, "last_version": 11.0, "field": "City", "formType": "input", "help": "Directory attribute mapping for City.<br/><br/>Default mapping is to l."}, {"first_version": 9.0, "description": "State", "formInput": {"onblur": "validAttribute(this);", "value": "st"}, "last_version": 11.0, "field": "State", "formType": "input", "help": "Directory attribute mapping for State.<br/><br/>Default mapping is to st."}, {"first_version": 9.0, "description": "Street Address", "formInput": {"onblur": "validAttribute(this);", "value": "streetAddress"}, "last_version": 11.0, "field": "StreetAddress", "formType": "input", "help": "Directory attribute mapping for StreetAddress.<br/><br/>Default mapping is to streetAddress."}]}, {"node": "Directory", "dirType": "edi,bdi", "legend": "Directory Search Parameters", "options": [{"first_version": 9.0, "description": "Base Filter", "formInput": {"onblur": "validBaseFilter(this);", "value": "(&(objectCategory=person))"}, "last_version": 11.0, "field": "BaseFilter", "formType": "input", "help": "Specifies a base filter for Active Directory queries.<br/><br/>Specify a directory subkey name only to retrieve objects other than user objects when you query Active Directory.<br/><br/>The default value is (&(objectCategory=person))."}, {"first_version": 9.0, "description": "Predictive Search Filter", "formInput": {"onblur": "validFilter(this);", "value": "anr="}, "last_version": 11.0, "field": "PredictiveSearchFilter", "formType": "input", "help": "Defines a search filter to apply to predictive search queries.<br/><br/>The default value is anr=."}, {"first_version": 9.0, "formOptions": [{"value": "1", "innerHTML": "false"}, {"selected": true, "value": "0", "innerHTML": "true"}], "description": "Enable Secondary Number Lookups", "last_version": 11.0, "field": "DisableSecondaryNumberLookups", "formType": "select", "help": "Specifies whether users can search for alternative contact numbers if the work number is not available, such as the mobile, home, or other number.<br><br>false shows up as '1' in the XML<br>true shows up as '0' in the XML<br><br>True is the default value."}, {"first_version": 9.0, "description": "Phone Number Mask", "formInput": {"onblur": "validPhoneMask(this);"}, "last_version": 11.0, "field": "PhoneNumberMasks", "formType": "input", "help": "Specifies masks to use when users search for phone numbers.<br/><br/>For example, a user receives a call from +14085550100. However, this number in Active Directory is +(1) 408 555 0100. The following mask ensures that the contact is found:<br/><br/><b>+14081+(#) ### ### ####</b><br/><br/>The length of mask strings cannot exceed the size restriction for registry subkey names."}, {"first_version": 9.0, "description": "Timout Period (seconds)", "formInput": {"onblur": "validInteger(this);", "value": "5"}, "last_version": 11.0, "field": "SearchTimeout", "formType": "input", "help": "Specifies the timeout period for queries in seconds.<br/><br/>The default value is 5."}, {"first_version": 9.0, "formOptions": [{"value": "1", "innerHTML": "true"}, {"selected": true, "value": "0", "innerHTML": "false"}], "description": "Enable Wildcard Searches", "last_version": 11.0, "field": "UseWildcards", "formType": "select", "help": "Specifies whether to enable wildcard searches.<br/><br/>If enabled, the speed of searches on the LDAP might be affected, especially if users search for directory attributes that are not indexed.<br/><br/>You can use phone number masks instead of wildcard searches.<br><br>false shows up as '0' in the XML<br>true shows up as '1' in the XML<br><br>False is the default value."}, {"first_version": 9.1, "description": "Minimum Character Query", "formInput": {"onblur": "validInteger(this);", "value": "3"}, "last_version": 11.0, "field": "MinimumCharacterQuery", "formType": "input", "help": "Specifies the minimum number of characters in a contact name needed to query the directory.<br><br>For example, if you set 2 as the value of this parameter, directory lookups occur when users enter at least two characters in the search field.<br><br>The default value is 3."}, {"first_version": 9.0, "description": "Search Base OU #1", "formInput": {"onblur": "validOU(this);"}, "last_version": 11.0, "field": "SearchBase1", "formType": "input", "help": "Specifies a location in Active Directory from which searches begin.<br/><br/>Set the value of SearchBase1 to the first searchable OU in the tree. Set the values of other search bases as appropriate.<br/><br/>The default value is the root of the tree."}, {"first_version": 9.0, "description": "Search Base OU #2", "formInput": {"onblur": "validOU(this);"}, "last_version": 11.0, "field": "SearchBase2", "formType": "input", "help": "Specifies a location in Active Directory from which searches begin.<br/><br/>Set the value of SearchBase1 to the first searchable OU in the tree. Set the values of other search bases as appropriate.<br/><br/>The default value is the root of the tree."}, {"first_version": 9.0, "description": "Search Base OU #3", "formInput": {"onblur": "validOU(this);"}, "last_version": 11.0, "field": "SearchBase3", "formType": "input", "help": "Specifies a location in Active Directory from which searches begin.<br/><br/>Set the value of SearchBase1 to the first searchable OU in the tree. Set the values of other search bases as appropriate.<br/><br/>The default value is the root of the tree."}, {"first_version": 9.0, "description": "Search Base OU #4", "formInput": {"onblur": "validOU(this);"}, "last_version": 11.0, "field": "SearchBase4", "formType": "input", "help": "Specifies a location in Active Directory from which searches begin.<br/><br/>Set the value of SearchBase1 to the first searchable OU in the tree. Set the values of other search bases as appropriate.<br/><br/>The default value is the root of the tree."}, {"first_version": 9.0, "description": "Search Base OU #5", "formInput": {"onblur": "validOU(this);"}, "last_version": 11.0, "field": "SearchBase5", "formType": "input", "help": "Specifies a location in Active Directory from which searches begin.<br/><br/>Set the value of SearchBase1 to the first searchable OU in the tree. Set the values of other search bases as appropriate.<br/><br/>The default value is the root of the tree."}, {"first_version": 9.0, "formOptions": [{"selected": true, "value": "true", "innerHTML": "true"}, {"value": "false", "innerHTML": "false"}], "description": "Enable Wildcard Searches", "last_version": 11.0, "field": "BDIUserANR", "formType": "select", "help": "Specifies if Cisco Jabber issues a query using Ambiguous Name Resolution (ANR) when it performs a predictive search.<br/><br/>You can use phone number masks instead of wildcard searches.<br><br>false shows up as '0' in the XML<br>true shows up as '1' in the XML<br><br>True is the default value."}]}, {"node": "Directory", "legend": "Contact Photographs", "options": [{"dirType": "edi,bdi", "formOptions": [{"value": "true", "innerHTML": "URI Subsitution"}, {"selected": true, "value": "false", "innerHTML": "Binary Object"}, {"value": "false", "innerHTML": "PhotoURL Attribute"}], "description": "Retrieval Method", "formInput": {"onblur": "validPhoto(this);", "onchange": "hRetrievalMethod(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "PhotoUriSubstitutionEnabled", "formType": "select", "help": "<b>URI substitution</b><br/>Cisco Jabber for Windows dynamically builds a URL to contact photos with a directory attribute and a URL template.<br/>To use this method, set the following values in your configuration file:<br/>Specify a directory attribute to use as a dynamic token as the value of the PhotoUriSubstitutionToken parameter.For example, sAMAccountName.<br/>Specify the URL and the dynamic token as the value of the PhotoUriWithToken parameter.For example, http://staffphoto.example.com/sAMAccountName.jpg.<br/>With the example values in the preceding steps, the sAMAccountName attribute might resolve to msmith in your directory. Cisco Jabber for Windows then takes this value and replaces the token to build the following URL: http://staffphoto.example.com/msmith.jpg.<br/><br/><br/><b>Binary objects</b><br/>Cisco Jabber for Windows retrieves the binary data for the photo from your database.<br/>To use this method to retrieve contact photos, specify the attribute that contains the binary data as the value of the PhotoSource parameter in the configuration. For example, jpegPhoto.<br/><br/><b>PhotoURL attribute</b><br/>Cisco Jabber for Windows retrieves a URL from a directory attribute.<br/>To use this method to retrieve contact photos, specify the attribute that contains the photo URL as the value of the PhotoSource parameter in the configuration. For example, photoUri."}, {"dirType": "edi,bid", "description": "Directory Attribute Token", "formInput": {"onblur": "validPhotoUri(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "PhotoUriSubstitutionToken", "formType": "input", "help": "Specifies a directory attribute to insert in the photo URI.<br/><br/>For example, sAMAccountName."}, {"dirType": "edi,bid", "description": "Photo Server URL with token", "formInput": {"onblur": "validPhotoUri(this);"}, "last_version": 11.0, "first_version": 9.0, "field": "PhotoUriWithToken", "formType": "input", "help": "Specifies a photo URI with a directory attribute as a variable value.<br/><br/>You set the directory attribute as the value of PhotoUriSubstitutionToken.<br/><br/>For example, http://staffphoto.example.com/sAMAccountName.jpg<br/><br/>UDS dynamically builds a URL to contact photos with a directory attribute and a URL template.<br/><br/>To resolve contact photos with UDS, you specify the format of the contact photo URL as the value of the PhotoUriWithToken parameter. You also include a %%uid%% token to replace the contact username in the URL. For example, <PhotoUriWithToken>http://server_name.domain/%%uid%%.jpg</PhotoUriWithToken>.<br/><br/>UDS substitutes the %%uid%% token with the value of the userName attribute in UDS. For example, a user named Mary Smith exists in your directory and the value of the userName attribute for Mary Smith is msmith. To resolve the contact photo for Mary Smith, Cisco Jabber for Windows takes the value of the userName attribute and replaces the %%uid%% token to build the following URL: http://staffphoto.example.com/msmith.jpg"}, {"dirType": "uds", "description": "Photo Server URL with token", "formInput": {"onblur": "validUdsPhotoUri(this);"}, "last_version": 11.0, "first_version": 9.7, "field": "UdsPhotoUriWithToken", "formType": "input", "help": "Specifies a photo URI with a directory attribute as a variable value; for example, http://www.photo/url/path/%%uid%%.jpg."}]}, {"node": "Directory", "dirType": "edi,bdi", "legend": "Intradomain Federation", "options": [{"first_version": 9.0, "formOptions": [{"value": "true", "innerHTML": "true"}, {"selected": true, "value": "false", "innerHTML": "false"}], "description": "Use SipUri to Resolve Contacts", "formInput": {"onblur": "validSipUri(this);", "onchange": "hSipUri(this);"}, "last_version": 11.0, "field": "UseSIPURIToResolveContacts", "formType": "select", "help": "Specifies whether Cisco Jabber for Windows retrieves contact information using the value of the attribute you specify in the SipUri Directory Attribute Mapping Parameters configuration parameter; the default is msRTCSIP-PrimaryUserAddress.<br/><br/>If enabled, Cisco Jabber will retrieve contact information using the value of the attribute you specify in the SipUri configuration parameter.<br/><br/>Set the value of this parameter to true if you are configuring intradomain federation and the contact usernames in your directory do not conform to the format that Cisco Unified Presence requires<br/><br/>To resolve contacts during contact search or retrieve contact information from your directory, Cisco Jabber for Windows requires the contact ID for each user. Cisco Unified Presence uses a specific format for resolving contact information that does not always match the format on other presence servers such as Microsoft Office Communications Server or Microsoft Live Communications Server.<br/><br/>Specify any text that prefixes each contact ID as the value of the UriPrefix configuration parameter. The prefix is any text that exists before the username in the contact ID. For example, you specify msRTCSIP-PrimaryUserAddress as the value of SipUri. In your directory the value of msRTCSIP-PrimaryUserAddress for each user has the following format: sip:username@domain<br/>Cisco Jabber for Windows uses this prefix as follows:<ol><li>Cisco Jabber for Windows connects to your directory to retrieve information for contacts, including telephone numbers and email addresses. If you set the UseSIPURIToResolveContacts configuration parameter to true, Cisco Jabber for Windows needs to match contact IDs with the exact value for the attribute specified for the SipUri configuration parameter. If a prefix exists for this value, Cisco Jabber for Windows appends the prefix to the value. For example, you set msRTCSIP-PrimaryUserAddress as the value of the SipUri configuration parameter. A Cisco Jabber for Windows user tries to retrieve contact information for a user named Mary Smith. sip:msmith@domain.com is the value of the msRTCSIP-PrimaryUserAddress attribute in your directory. When Cisco Unified Presence passes the contact information to Cisco Jabber for Windows, it provides msmith@domain.com and does not include the prefix. To match the value of the msRTCSIP-PrimaryUserAddress attribute, Cisco Unified Presence appends the prefix to match attribute value of sip:msmith@domain.com.</li><li>When Cisco Jabber for Windows users search for contacts, Cisco Jabber for Windows removes the prefix from the value of the attribute specified for the SipUri configuration parameter to get the contact ID.For example, you set msRTCSIP-PrimaryUserAddress as the value of the SipUri configuration parameter. sip:msmith@domain.com is the value of the msRTCSIP-PrimaryUserAddress attribute in your directory. To search for the contact, Cisco Jabber for Windows removes the prefix of sip: and uses msmith@domain.com.</li></ol>False is the default value."}, {"first_version": 9.0, "help": "Defines the prefix that applies to the value of the attribute you specify in the SipUri configuration parameter.<br/><br/>The prefix is any text that exists before the username of the contact ID. For example, you specify msRTCSIP-PrimaryUserAddress as the value of SipUri. In your directory the value of msRTCSIP-PrimaryUserAddress for each user has the following format: sip:username@domain.<br/><br/>The default value is blank.", "last_version": 11.0, "field": "UriPrefix", "formType": "input", "description": "URI Prefix"}, {"first_version": 10.5, "help": "TBD", "last_version": 11.0, "field": "IMAddresses", "formType": "input", "description": "IMAddresses"}, {"first_version": 10.5, "help": "TBD", "last_version": 11.0, "field": "IMAddress", "formType": "input", "description": "IMAddress"}]}];
/*
actions
*/
var gVersion = null

var selected_version = function() {
    if (gVersion == null) {
        var e = document.getElementById('version_select');
        gVersion = parseFloat(e.options[e.selectedIndex].value);
    }
    return gVersion;
}

var byId = function(name) {
    var _id = document.getElementsByClassName(name);
    for (var x=0;x<_id.length;x++) {
		if (parseFloat(_id[x].getAttribute('first_version')) <= selected_version() && parseFloat(_id[x].getAttribute('last_version')) >= selected_version()) {
			return _id[x];
		}
    }
    return document.getElementById(name)
}

var toggleConfigOption = function(id,bShow) {
	var o = document.getElementById(id);
	if (id == null || o == null) {
		//TODO: handle error
		return;
	}
	if (o.parentElement && o.parentElement.parentElement) {
	    var parent = o.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement
		if (o.selectedIndex) {
			//o.selectedIndex = -1;
		}
		if ((bShow === "true" || bShow === true) ) {
			// show row again and specify the default value if exists
			o.removeAttribute('disabled');
			o.parentElement.parentElement.removeAttribute('style');
			for (var f in obj) {
				for (var i in obj[f].options) {
					if (obj[f].options[i].field == id) {
						var frm = document.getElementById(obj[f].options[i].field);
						mixin(frm,obj[f].options[i].formInput);
                        switch(frm.tagName) {
                            case 'SELECT':
                                if (frm.selectedIndex != -1) {
                                    continue;
                                }
                                break;
                            case 'INPUT':
                            default:
                                if (frm.value != "") {
                                    continue;
                                }
                                break;
                        }
						setDefaultSelected(frm,obj[f].options[i]);
						break;
					}
				}
			}
		} else if (bShow === "false" || bShow === false) {
			// remove the row from visibility
			//o.setAttribute('value','');
			//o.value = '';
			o.setAttribute('disabled',true);
			o.parentElement.parentElement.setAttribute('style','display:none;');
		} else {
			bShow = (o.parentElement.parentElement.getAttribute('style') == null);
			toggleConfigOption(id,bShow);
		}
	}
}

var toggleFieldset = function(id,bShow) {
	// will only remove the fieldset if all the options are disabled already
	if (id.indexOf('section_') == 0) {
	  id = id.substr(8);
	}
	var v = document.getElementById('version_select'),
        ver = null,
        o = document.getElementById('section_'+id),
        nav = document.getElementById('nav_'+id);
	if (v === null || o === null || v.selectedIndex == -1) {
		//TODO: handle error
		return;
	}
    ver = parseFloat(v.options[v.selectedIndex].value);
	for (var i=0;i<obj.length;i++) {
		if (obj[i].legend === id) {
			if (bShow === "false" || !bShow) {
				o.setAttribute('style','display:none;');
				nav.setAttribute('style','display:none;');
			} else {
				o.removeAttribute('style');
				nav.removeAttribute('style');
			}
			for (var x=obj[i].options.length;x>-1;x--) {
				if (!obj[i].options[x]) {
					continue;
				}
				var e = document.getElementById(obj[i].options[x].field);
				var fv = (typeof(obj[i].options[x].first_version) != 'undefined' && obj[i].options[x].first_version) ? obj[i].options[x].first_version : 9.0;
				var lv = (typeof(obj[i].options[x].last_version) != 'undefined' && obj[i].options[x].last_version) ? obj[i].options[x].last_version : 100.0;
				if (e == null) {
					//TODO: handle error
					return;
				}
				if (bShow && fv <= ver && lv >= ver) {
					toggleConfigOption(e.id,bShow);
				} else {
					toggleConfigOption(e.id,'false');
				}
			}
			break;
		}
	}
}

// field selection functions
var hVersion = function(e) {
    if (e.selectedIndex === -1) {
        return;
    }
    var version = parseFloat(e.options[e.selectedIndex].value);
    for(var fs in obj) {
    if (obj[fs].legend === 'Deployment') {
        // skip over this one, since it's always present and will cause a loop if not skipped
        continue;
    }
    if (obj[fs].options) {
        var matches = 0;
        for(var o in obj[fs].options) {
            var bVal = (obj[fs].options[o].first_version <= version && (obj[fs].options[o].last_version === null || obj[fs].options[o].last_version >= version)) ? "true" : "false";
            toggleConfigOption(obj[fs].options[o].field,bVal);
            if (bVal === "true") {
                matches++;
            }
        }
        var bShow = (matches > 0);
        if (obj[fs].showOnLoad !== undefined && obj[fs].showOnLoad !== null) {
          bShow = fnDisplayDynamic(obj[fs].options);
        }
        toggleFieldset(obj[fs].legend,bShow);
    }
    }
    // update URL to point to correct path
    var a = document.getElementById('deploymenttype');
    //var tftp = document.getElementById('tftp_upload_instructions');
    var doc = document.getElementById('original_documentation');
    var new_doc = '';
    var new_tftp = '';
    switch(version) {
        case 9.0:
            new_doc = 'http://www.cisco.com/en/US/partner/docs/voice_ip_comm/jabber/Windows/9_0_1/b_jabber_win_icg.html';
            break;
        case 9.1:
            new_doc = 'http://www.cisco.com/en/US/partner/docs/voice_ip_comm/jabber/Windows/9_1/JABW_BK_CA48EE46_00_cisco-jabber-for-windows-administration.html';
            break;
        case 9.2:
            new_doc = 'http://www.cisco.com/en/US/partner/docs/voice_ip_comm/jabber/Windows/9_2/JABW_BK_C9731738_00_jabber-windows-install-config.html';
            break;
        case 9.6:
            new_doc = 'http://www.cisco.com/en/US/partner/docs/voice_ip_comm/jabber/Windows/9_6/InstallConfig/JABW_BK_CDFE9752_00_installation-and-configuration.html';
            break;
        case 9.7:
            new_doc = 'http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/Windows/9_7/JABW_BK_C4C679C9_00_cisco-jabber-for-windows-97/JABW_BK_C4C679C9_00_cisco-jabber-for-windows-97_chapter_0110.html';
            break;
        case 10.5:
            new_doc = 'http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_5/CJAB_BK_D6497E98_00_deployment-installation-guide-ciscojabber.html';
            break;
        case 10.6:
            new_doc = 'http://www.cisco.com/c/en/us/td/docs/voice_ip_comm/jabber/10_6/CJAB_BK_C56DE1AB_00_cisco-jabber-106-deployment-and-installation-guide.html';
            break;
        case 11.0:
            new_doc = '';
            break;
    }
    //new_tftp = new_doc;
    //tftp.setAttribute('href',new_tftp);
    doc.setAttribute('href',new_doc);
    //TODO: display dynamic fields if data is populated in them
    //hEnableJabberPlugins(document.getElementById('EnableJabberPlugins'));
    hPhoneMode(document.getElementById('ProductMode'));
	hDeploymentType(a);
}
var hPlatformIos = function(e) {
    if (e.selectedIndex === -1) {
        return;
    }
    var v = e.options[e.selectedIndex].value;
}
var hPlatformAndroid = function(e) {
    if (e.selectedIndex === -1) {
        return;
    }
    var v = e.options[e.selectedIndex].value;
}
var hPlatformWindows = function(e) {
    if (e.selectedIndex === -1) {
        return;
    }
    var v = e.options[e.selectedIndex].value;
}
var hPlatformMac = function(e) {
    if (e.selectedIndex === -1) {
        return;
    }
    var v = e.options[e.selectedIndex].value;
}
var hDeploymentType = function(e) {
    if (e.selectedIndex === -1) {
        return;
    }
	if (e.options[e.selectedIndex].value === 'cloud-based') {
		alert('To configure a cloud-based deployment, use the Cisco WebEx Administration Tool');
		return;
	}
	var v = document.getElementById('ProductMode');
    var pm = (v.selectedIndex > -1) ? v.options[v.selectedIndex].value : 'Default';
	var bOnPrem = (e.options[e.selectedIndex].value === 'on-premises') ? "true" : "false";
    toggleFieldset('Voicemail',(bOnPrem == 'true')?"false":'true'); //this only works in cloud-hybrid, not on-prem
    if (pm == 'Default') {
        toggleConfigOption('VVM_Mailstore_Server_0','false');
        toggleConfigOption('VVM_Mailstore_PollingInterval','false');
    }
	toggleFieldset('Directory',bOnPrem);
	toggleFieldset('Directory Attribute Mapping',bOnPrem);
	toggleFieldset('Directory Search Parameters',bOnPrem);
	toggleFieldset('Intradomain Federation',bOnPrem);
	toggleFieldset('Contact Photographs',bOnPrem);

	toggleConfigOption('UpdateUrl',bOnPrem);
	toggleConfigOption('Forgot_Password_URL',bOnPrem);
	toggleConfigOption('Screen_Capture_Enabled',bOnPrem);
	toggleConfigOption('File_Transfer_Enabled',bOnPrem);
    toggleConfigOption('PreferredFT',bOnPrem);
    toggleConfigOption('DisableMFTForConversationTypes',bOnPrem);
    toggleConfigOption('Disallowed_File_Transfer_Types',bOnPrem);
    toggleConfigOption('Customize_Phone_Server',bOnPrem);
    toggleConfigOption('Customize_Voicemail_Server',bOnPrem);

	if (bOnPrem == 'true') {
		toggleConfigOption('PhotoUriSubstitutionToken','false');
		toggleConfigOption('PhotoUriWithToken','false');
		toggleConfigOption('UriPrefix','false');
		//toggleConfigOption('Start_Calls_With','false');
	} else {
		//toggleConfigOption('Start_Calls_With','true');
	}
}

var setDefaultSelected = function(e,obj) {
	if (e && obj.formOptions) {
		for (var y=0;y<obj.formOptions.length;y++) {
			if (obj.formOptions[y].selected === true && typeof(e.options) !== 'undefined') {
				for (var z=0;z<e.options.length;z++) {
					if (e.options[z].value === obj.formOptions[y].value) {
						if (e.selectedIndex == -1) {
							e.options[z].selected = true;
							e.selectedIndex = z;
							if (e.disabled !== true && typeof(e.onchange) == "function") {
								if (document.createEventObject) {
									var evt = document.createEventObject();
									e.fireEvent('onchange');
								} else {
									var evt = document.createEvent('HTMLEvents');
									evt.initEvent('change',true,true);
									!e.dispatchEvent(evt);
								}
								//e.onchange();
							}
						}
						break;
					}
				}
			}
		}
	}
}

var fnReset = function() {
    var upload = document.getElementById('existingFileText'),
      download = document.getElementById('xmlContent');
    upload.value = '';
    download.innerHTML = '';
    fnHideDynamicValues();
	fnValidateAllFields();
	for (var i=0;i<obj.length;i++) {
		for (var x=0;x<obj[i].options.length;x++) {
			if (!obj[i].options[x]) {
				continue;
			}
			var e = document.getElementById(obj[i].options[x].field),
				v = '';
			if (obj[i].options[x].formInput && obj[i].options[x].formInput.value) {
				v = obj[i].options[x].formInput.value;
			}
      if (e !== null) {
  			e.setAttribute('value',v);
  			e.value = v;
  			setDefaultSelected(e,obj[i].options[x]);
      }
		}
	}
}

var fnError = function(e,msg) {
	if (e && e.parentElement && e.parentElement.parentElement) {
		for (c in e.parentElement.parentElement.childNodes) {
			if (e.parentElement.parentElement.childNodes[c].className !== undefined && e.parentElement.parentElement.childNodes[c].className.indexOf("entry-column-error") > -1) {
				for (i in e.parentElement.parentElement.childNodes[c].childNodes) {
					if (e.parentElement.parentElement.childNodes[c].childNodes[i].className === "error") {
						e.parentElement.parentElement.childNodes[c].childNodes[i].innerHTML = msg;
						return;
					}
				}
			}
		}
	}
	return;
}

var fnSuggestTelemetryCustomerIdByOrder = function() {
  var id = document.getElementById('TelemetryCustomerID'),
    hosts = [
      'VoiceServicesDomain',
      'PresenceDomain',
      'DeviceAuthenticationPrimaryServer',
      'TftpServer1',
      'CtiServer1',
      'CcmcipServer1',
      'PresenceServerAddress',
      'PresenceServer',
      'PrimaryServerName',
      'VVM_Mailstore_Server_0'
    ],
    urls = [
      'PresenceServerURL',
      'Meeting_Server_Address',
      'PrtLogServerUrl',
      'UpdateUrl',
      'Forgot_Password_URL'
    ];
    if (bAutoSuggestion == false || id == null) {
      return;
    }
    // iterate through HOSTS and take first match based on order
    for (var i=0;i<hosts.length;i++) {
      if (fnUpdateTelemetryCustomerID(fnExtractDomainFromHostnameById(hosts[i]))) {
        return;
      }
    }
    // iterate through URLS and take first match based on order
    for (var i=0;i<urls.length;i++) {
      if (fnUpdateTelemetryCustomerID(fnExtractDomainFromURLById(urls[i]))) {
        return;
      }
    }
    str = 'Unable to detect any information to generate a useful label.\n\nConsider filling out more fields in this form then try again.';
    alert(str);
}

var fnSuggestTelemetryCustomerId = function(strId,bHostname) {
  var id = document.getElementById('TelemetryCustomerID');
  // if it's already populated, don't do anything
  if (bAutoSuggestion == false || id == null || id.value !== '') {
    return;
  }
  // only look at the ID which was passed in and update accordingly
  if (bHostname) {
    if (fnUpdateTelemetryCustomerID(fnExtractDomainFromHostnameById(strId))) {
      return;
    }
  } else {
    if (fnUpdateTelemetryCustomerID(fnExtractDomainFromURLById(strId))) {
      return;
    }
  }
}

var fnUpdateTelemetryCustomerID = function(suggestion) {
  if (suggestion == '') {
    return false;
  }
  var id = document.getElementById('TelemetryCustomerID');
  //TODO: update suggestion and notify
  id.value = suggestion;
  return true;
}

var fnExtractDomainFromHostname = function(str) {
  var regex = /^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$/,
    matches = regex.exec(str),
    value = '',
    blacklist = [
      'com.cisco',
      'com.webex'
    ];
  if (matches == null || matches.length < 2 || matches[matches.length-1] == undefined || matches[matches.length-2] == undefined) {
    return value;
  }
  //TODO: when the last two domains are tiny (ie "uk.co") we should go one more deeper
  value = matches[matches.length-1]+'.'+matches[matches.length-2];
  // ignore common domains which may be discovered from URLs
  return (blacklist.indexOf(value) > -1) ? '' : value;
}

var fnExtractDomainFromHostnameById = function(id) {
  var dom = document.getElementById(id);
  if (dom == null || dom.value === '') {
    return '';
  }
  return fnExtractDomainFromHostname(dom.value)
}

var fnExtractDomainFromURLById = function(id) {
  var dom = document.getElementById(id);
  if (dom == null || dom.value === '') {
    return '';
  }
  var regex = /http[s]*:\/{2}([^\/\:]*)?.*/,
    matches = regex.exec(dom.value);
  if (matches == null || matches.length < 2 || matches[matches.length-1] == undefined) {
    return '';
  }
  return fnExtractDomainFromHostname(matches[matches.length-1]);
}

var fnIncludeBDI = function() {
  var b = false;
  for(o in obj) {
    if (obj[o].legend !== "Platforms") {
      continue;
    }
    for(a in obj[o].options) {
      if (obj[o].options[a].field === "j4w") {
        continue;
      }
      var j4 = document.getElementById(obj[o].options[a].field);
      if (!b && j4.value == "true") {
        b = true;
      }
    }
    break;
  }
  return b;
}

var fnValid = function() {
	//perform checks on the config parameters
	var tmp = document.getElementById('deploymenttype'),
    type = document.getElementById('DirectoryServerType'),
    edi = null,
    bdi = false,
    uds = false;
	fnValidateAllFields();
	if (type !== null && type.selectedIndex > -1 && type.options[type.selectedIndex]) {
    if (type.options[type.selectedIndex].value === 'EDI') {
  		// checks for EDI configuration
  		edi = byId('UseWindowsCredentials');
      if (edi !== null && edi.selectedIndex > -1 && edi.options[edi.selectedIndex] && edi.options[edi.selectedIndex].value === '0') {
        edi = true;
      } else {
        edi = false;
      }
    } else if (type.options[type.selectedIndex].value === 'UDS') {
      uds = true;
    } else if (type.options[type.selectedIndex].value === 'BDI') {
      bdi = true;
    }
	}
  if (bdi || uds) {
    tmp = byId('PresenceDomain');
    if (tmp.value === '') {
      fnError(tmp,'Invalid PresenceDomain, you must enter some text because you selected a directory type other than EDI.');
    }
  }
  if (bdi || edi) {
    tmp = byId('ConnectionUsername');
    if (tmp.value === '') {
      fnError(tmp,'Invalid username, you must enter some text because you want to use a service account.');
    }
    tmp = byId('ConnectionPassword');
    if (tmp.value === '') {
      fnError(tmp,'Invalid password, you must enter some text because you want to use a service account.');
    }
  }
  return !fnHasErrors();
}

var fnValidTelemetry = function() {
  // check if TelemetryCustomerID is populated, prompt if not
  var tmp = document.getElementById('TelemetryCustomerID');
  if (tmp.value.trim() === '' && confirm('There is nothing populated for the Aggregate Telemetry Label.\n\nPress OK and thsi script will attempt to auto-suggest one for this specific configuration.')) {
    fnSuggestTelemetryCustomerIdByOrder();
  }
	return true;
}


var fnHasErrors = function() {
  return fnScrollToFirstError();
}

var fnScrollToFirstError = function() {
  var content = document.getElementById('paramForm'),
    elem = null,
    total = null;
  if (content == null || content.childNodes == undefined) {
    return true;
  }
  for (var a in content.childNodes) {
    if (content.childNodes[a].style == undefined || content.childNodes[a].style.display == 'none') {
      continue;
    }
    elem = content.childNodes[a].getElementsByClassName('error');
    for (var b in elem) {
      if (elem[b].innerHTML == undefined || elem[b].innerHTML.trim().length == 0 || elem[b].parentElement.parentElement.style.display == "none") {
        continue;
      }
      if (elem[b].offsetParent == undefined || elem[b].offsetParent.offsetParent == undefined) {
        continue;
      }
      total = elem[b].offsetParent.offsetTop + elem[b].offsetParent.offsetParent.offsetTop - content.offsetTop;
      window.scrollTo(0,total);
      return true;
    }
  }
  return false;
}


/*
FieldValidators
*/

var fnValidateAllFields = function() {
  bAutoSuggestion = false;
	for (f in obj) {
		for (a in obj[f].options) {
			var e = byId(obj[f].options[a].field);
            if (e === null) {
                continue;
            }
            if (typeof(e.onblur) === 'function') {
                e.onblur();
            }
            if (typeof(e.onchange) === 'function') {
                e.onchange();
            }
            if (typeof(e.onclick) === 'function') {
                //e.onclick();
            }
		}
	}
  bAutoSuggestion = true;
}

var validURLRegExp = function(str) {
	return (str.match(/(http|https):\/\/[\w\-_\d]+(\.[\w\-_\d]+)+([\w\-\.,@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?/) !== null);
}
var isEdi = function() {
	var tmp = byId('DirectoryServerType');
	return tmp.selectedIndex > -1 ? (tmp.options[tmp.selectedIndex].value === 'EDI') : true;
}
var validPageURL = function(e) {
	var str = '',
		idx = e.id.replace(/[A-Z-a-z$-]/g,''),
		page = byId('url'+idx),
		tooltip = byId('tooltip'+idx),
		icon = byId('icon'+idx),
		refresh = byId('refresh'+idx),
		preload = byId('preload'+idx);
	// check other parameters to see if the user is attempting to use this fieldset
	if (fnFieldSetEnabled(e) === true) {
		if ((e.id === refresh.id && refresh.value === 'true') || (e.id === preload.id && preload.value === 'true')) {
			validPageURL(page);
		} else if (page.value === '' && tooltip.value === '' && icon.value === '' && refresh.value === 'false' && preload.value === 'false') {
			// no configuration, clear errors
			fnError(page,'');
		} else if (page.value === '') {
			// some setting is specified, but pageurl is invalid
			fnError(page,'The URL entered cannot be blank');
		}
    // validate URLs
		if (icon.value !== '') {
			validURL(icon);
		}
    if (page.value !== '') {
  		validURL(page);
    }
	}
	return (str === '');
}
var validURL = function(e) {
	var str = '';
	if (e.value != '' && !validURLRegExp(e.value)) {
		str = 'The URL entered is not a vaild path.';
	}
	fnError(e,str);
  //fnSuggestTelemetryCustomerId(e.id,false);
	return (str === '');
}
var validConnectionUsername = function(e) {
  var str = '';
  if (e.parentElement.parentElement.style.display === "none") {
    str = '';
  } else if (e === null || e.value.length < 1) {
    str = 'You must enter in a username!';
  }
  fnError(e,str);
  return (str === '');
}
var validConnectionPassword = function(e) {
  var str = '';
  if (e.parentElement.parentElement.style.display === "none") {
    str = '';
  } else if (e === null || e.value.length < 1) {
    str = 'You must enter in a password!';
  }
  fnError(e,str);
  return (str === '');
}
var validUdsServer = function(e) {
  // only trigger if UDS is selected
  var dirType = byId('DirectoryServerType').value;
  if (dirType != "UDS") {
    return true;
  }
  var b = validRequiredString(e);
  if (b) {
    b = validHostname(e);
  }
  return b;
}
var validRequiredString = function(e) {
  var str = '';
  if (e.value === '') {
    str = 'There must be an entry for this field.';
  }
//  fnError(e,str);
  return (str === '');
}
var validPhoto = function(e) {
	var str = '',
		e = byId('PhotoUriSubstitutionEnabled'),
		tmp = byId('PhotoSource');
	if (isEdi() || fnIncludeBDI()) {
		if (e.selectedIndex > -1 && e.options[e.selectedIndex] && e.options[e.selectedIndex].value === 'false') {
			if (!validAttribute(tmp)) {
				str = 'String contains invalid characters.'
			} else if (tmp.value === '') {
				str = 'PhotoSource cannot be empty.';
			}
			/*
			else if (e.options[e.selectedIndex].innerHTML.indexOf('PhotoURL') > -1 && !validURLRegExp(tmp.value)) {
				str = 'PhotoSource is not a valid URL.';
			}
			*/
		}
	}
	fnError(tmp,str);
	fnError(e,str);
	return (str === '');
}
var validPhotoUri = function(e) {
  return validPhotoUriGeneric(e,'PhotoUriWithToken');
}
var validUdsPhotoUri = function(e) {
  return validPhotoUriGeneric(e,'UdsPhotoUriWithToken');
}
var validPhotoUriGeneric = function(e,key) {
  var ret = true,
    tmp = null,
    str = '',
    token = '%%uid%%'; //default token for UID, if EDI we'll replace the token
  if (isEdi() || fnIncludeBDI()) {
    tmp = byId('PhotoUriSubstitutionToken');
    token = tmp.value;
    if (tmp.disabled !== true && token === '') {
      str = 'Invalid token, you must enter some text';
      ret = false;
    }
    fnError(tmp,str);
  }
  str = '';
  tmp = byId(key);
  if (tmp.disabled !== true && (tmp.value === '' || tmp.value.indexOf(token) == -1)) {
    str = 'Invalid URL, you must enter a path with the token '+token;
    ret = false;
  }
  fnError(tmp,str);
  return ret;
}
var validCrossLaunchBackSchema = function(e) {
    var str = '';
    if (e.value != '' && (e.value.indexOf(',') != -1 || e.value.indexOf(' ') != -1)) {
        str = 'Invalid delimter, you must use a semicolon ;';
    }
    fnError(e,str);
    return (str === '');
}
var validInteger = function(e) {
	var str = '';
	if (e.value !== '' && isNaN(parseInt(e.value))) {
		str = 'Value is not a valid integer.';
	} else if (e.value !== '') {
		e.value = parseInt(e.value);
		e.setAttribute('value',e.value);
		if (e.value <= 0 || e.value >= 65535) {
			str = 'Invalid integer, value must be between 0-65535';
		}
	}
	fnError(e,str);
	return (str === '');
}
var validAttribute = function(e) {
	var str = '';
	if (e.value !== '' && e.value.match(/[^\w-_]/g) !== null) {
		str = 'String contains invalid characters.';
	}
	fnError(e,str);
	return (str === '');
}
var validAbsPath = function(e) {
  var str = '',
  ValidPathRegex = /^(?:[\w]\:|\\)(\\[a-z_\-\s0-9\.]+)+\\$/;
  if (e.value !== '' && e.value.match(ValidPathRegex) == null) {
    str = 'Invalid Absolute Path. Make sure to include closing backslash after folder name (i.e. C:\\folder\\)';
  }
  fnError(e,str);
  return (str === '');
}
var validHostname = function(e) {
	var str = '',
		ValidIpAddressRegex = "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$",
		ValidHostnameRegex = /^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)+([A-Za-z]{2,})$/;
	if (e.value !== '' && (e.value.match(ValidIpAddressRegex) === null && e.value.match(ValidHostnameRegex) === null)) {
		str = 'Invalid Fully Qualified Domain Name (FQDN) entry.';
	}
	fnError(e,str);
  //fnSuggestTelemetryCustomerId(e.id,true);
	return (str === '');
}
var validBaseFilter = function(e) {
	var str = '';
	// count number of ( and ), according to documentation, the trailing ) should be omitted
	// http://www.cisco.com/en/US/docs/voice_ip_comm/jabber/Windows/9_0_1/b_jabber_win_icg_chapter_0100.html#reference_63061470ADA34F16BA1209D670C0E4C3
	// this is resolved in 9.0.4 CSCua39052
	if (e.value && e.value.match(/\(/g).length !== e.value.match(/\)/g).length) {
		str = "The open and close brackets do not match!";
	}
	fnError(e,str);
	return (str === '');
}
var validFilter = function(e) {
	var str = '';
	//TODO: not sure we'll be able to verify this is correct without viewing what's in AD
	fnError(e,str);
	return (str === '');
}
var validPhoneMask = function(e) {
	var str = '';
	//TODO: not sure we'll be able to verify this is correct without viewing what's in AD
	fnError(e,str);
	return (str === '');
}
var validOU = function(e) {
	var str = '';
	if (e.value !== '' && (e.value.match(/^(OU|CN)=.+,\s*(DC=).+/i) === null || e.value.match(/[^\w-_\s=,]/ig) !== null)) {
		str = 'Invalid OU string.';
	}
	fnError(e,str);
	return (str === '');
}
var validSipUri = function(e) {
	var str = '',
		tmp = byId('SipUri');
	e = byId('UseSIPURIToResolveContacts');
	if (!validAttribute(tmp) && e.selectedIndex > -1 && e.options[e.selectedIndex].value == 'true') {
		str = "Invalid SipUri Attribute.";
	}
	fnError(e,str);
	return (str === '');
}

var validCertificateName = function(e) {
	var str = '',
		tmp = byId('PrtCertificateName');
	//TODO: what is a valid name?
	fnError(e,str);
	return (str == '');
}

var validBridgeUri = function(e) {
	//TODO: what is valid?
	return true
}

var validInteger100 = function(e) {
	var str = '';
	if (e.value !== '' && isNaN(parseInt(e.value))) {
		str = 'Value is not a valid integer.';
	} else if (e.value !== '') {
		e.value = parseInt(e.value);
		e.setAttribute('value',e.value);
		if (e.value <= 0 || e.value >= 100) {
			str = 'Invalid integer, value must be between 0-65535';
		}
	}
	fnError(e,str);
	return (str === '');
}

var validInteger300 = function(e) {
	var str = '';
	if (e.value !== '' && isNaN(parseInt(e.value))) {
		str = 'Value is not a valid integer.';
	} else if (e.value !== '') {
		e.value = parseInt(e.value);
		e.setAttribute('value',e.value);
		if (e.value <= 0 || e.value >= 300) {
			str = 'Invalid integer, value must be between 0-65535';
		}
	}
	fnError(e,str);
	return (str === '');
}

/*
var validHTMLColor = function(e) {
  var str = '',
    pattern1 = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
  if (e.value !== '' && (e.value.match(pattern1) === null)) {
    str = 'Invalid HTML Hex Color Code.';
  }
  fnError(e,str);
  return (str === '');
}
*//*
GenerateDOM
*/

var fnHideDynamicValues = function() {
  for (var i=5;i>0;i--) {
    toggleFieldset('Jabber Plugins '+i,false);
  }
  for (var i=20;i>0;i--) {
    toggleFieldset('Instant Message Label '+i,false);
  }
}

var fnPopulateForm = function() {
    // fill in the form values with what was discovered in pasted input
    fnParseInputData();
    fnValid();
}/*
main
*/

var hBlockAccessoriesManagerPlugins = function(e) {
    return;
}

var fnDisplayDynamic = function(options) {
  if (options === undefined || options === null || options.length == undefined) {
      return false;
  }
  for (var i=0;i<options.length;i++) {
      // only look at 'input' fields for existing text
      if (options[i].field === undefined || options[i].formType === undefined || options[i].formType !== 'input') {
          continue;
      }
      var dom = document.getElementById(options[i].field);
      if (dom === undefined || dom === null) {
          continue;
      }
      if (dom.value.trim().length > 0 && typeof(dom.onclick) !== 'function') {
          return true;
      }
  }
  return false;
}

var fnHideDynamic = function() {

}

var hAddJabberPlugin = function(e) {
  var className = 'jabberplugin',
    arr = document.getElementsByClassName(className),
    count = 0;
  for (var i=0;i<arr.length;i++) {
    count++;
    if (arr[i].style.display === "none") {
      toggleFieldset(arr[i].id,true);
      break;
    }
  }
  if (arr.length == count) {
    e.setAttribute('class','f-btn-disabled');
    e.setAttribute('disabled',true);
  }
  return;
}
var hAddInstantMessageLabel = function(e) {
  var className = 'instantmessagelabel',
    arr = document.getElementsByClassName(className),
    count = 0;
  for (var i=0;i<arr.length;i++) {
    count++;
    if (arr[i].style.display === "none") {
      toggleFieldset(arr[i].id,true);
      break;
    }
  }
  if (arr.length == count) {
    e.setAttribute('class','f-btn-disabled');
    e.setAttribute('disabled',true);
  }
  return;
  /*
    parentDom = document.getElementById('formContent'),
    insertBeforeDom = document.getElementById('Options'),
    count = document.getElementsByClassName(className).length;

  // if we've reached limit, disable button
  if (parentDom == null || insertBeforeDom == null || !canAddLabel(className)) {
    return;
  }

  // else create new fieldset and append to page
  fieldset = generateNewLabelForm(count+1);
  fieldset.setAttribute('class',className);
  parentDom.insertBefore(fieldset,insertBeforeDom);
  toggleAddLabelButton(className);
  */
}
var canAddLabel = function(className) {
  return toggleAddLabelButton(className,true);
}
var toggleAddLabelButton = function(className,bTest) {
  if (className === 'undefined') {
    className = 'instantmessagelabel';
  }
  var limit = 20,
    className = 'instantmessagelabel',
    labels = document.getElementsByClassName(className),
    count = labels.length,
    id = document.getElementById('AddInstantMessageLabels');
  if (id == null) {
    return;
  }
  if (bTest !== 'undefined' && bTest == true) {
    return count < limit;
  }
  if (count >= limit) {
    id.setAttribute('class','f-btn-disabled');
    id.setAttribute('disabled','true');
    return false;
  } else {
    id.setAttribute('class','f-btn-CTA');
    id.removeAttribute('disabled');
    return true;
  }
}

var hDeleteJabberPlugin = function(n) {
  var label = 'Jabber Plugins ',
    r = document.getElementById('refresh'+n),
    p = document.getElementById('preload'+n),
    t = document.getElementById('tooltip'+n),
    i = document.getElementById('icon'+n),
    u = document.getElementById('url'+n),
    btn = document.getElementById('AddJabberPlugin');

  r.selectedIndex = 0; //TODO:
  r.value = 'false';
  p.selectedIndex = 0; //TODO:
  p.value = 'false';
  t.value = '';
  i.value = '';
  u.value = '';
  toggleFieldset(label+n,false);
  if (btn.getAttribute('disabled') == 'true') {
    className = btn.getAttribute('class');
    className = className.substr(0,className.indexOf('f-btn'));
    btn.setAttribute('class',className+' f-btn-CTA');
    btn.removeAttribute('disabled');
  }
}

var hDeleteInstantMessageLabel = function(n) {
  var label = 'Instant Message Label ',
    dd = document.getElementById('selector'+n),
    fg = document.getElementById('fgcolor'+n),
    bg = document.getElementById('bgcolor'+n),
    lb = document.getElementById('displaymarking'+n);
  dd.value = '';
  fg.value = '';
  bg.value = '';
  lb.value = '';
  toggleFieldset(label+n,false);
}
var hPhoneMode = function(e) {
  var bMode = (e.selectedIndex > -1) ? e.options[e.selectedIndex].value === 'Phone_Mode' : false,
    element = document.getElementById('version_select'),
    version = null;
  toggleFieldset('Voicemail',bMode);
  version = (element.selectedIndex > -1) ? parseFloat(element.options[element.selectedIndex].value) : 9999;
  if (version > 9.2) {
    bMode = true;
  }
  toggleFieldset('Phone Mode',bMode);
}
var hDirectoryServiceType = function(e) {
    if (e.selectedIndex === -1) {
        return;
    }
	var bEdi = (e.options[e.selectedIndex].value.indexOf('EDI') > -1);
	var bBdi = (e.options[e.selectedIndex].value.indexOf('BDI') > -1);
    var bUds = (e.options[e.selectedIndex].value.indexOf('UDS') > -1);
    var bNotUds = (bUds == false);

    toggleFieldset('Directory Attribute Mapping',bNotUds);
	toggleFieldset('Intradomain Federation',bNotUds);
	toggleConfigOption('ConnectionType',bEdi);
	toggleConfigOption('PrimaryServerName',bNotUds);
	toggleConfigOption('ServerPort1',bNotUds);
	toggleConfigOption('SecondaryServerName',bNotUds);
    toggleConfigOption('ServerPort2',bNotUds);
    toggleConfigOption('LDAPServerType',bBdi);
    toggleConfigOption('UseJabberCredentials',bBdi);
    toggleConfigOption('UseWindowsCredentials',bEdi);
	toggleConfigOption('ConnectionUsername',bBdi);
	toggleConfigOption('ConnectionPassword',bBdi);
	toggleConfigOption('UseSSL',bNotUds);
	toggleConfigOption('UseSecureConnection',bEdi);
	toggleConfigOption('PhotoUriSubstitutionToken',bNotUds);
	toggleConfigOption('PhotoUriWithToken',bNotUds);
	toggleConfigOption('PhotoUriSubstitutionEnabled',bNotUds);
    toggleConfigOption('PresenceDomain',(bUds||bBdi));
    toggleConfigOption('UdsServer',bUds);
    toggleConfigOption('UdsPhotoUriWithToken',bUds);
    //fnValidateAllFields();
}
var hUseWindowsCredentials = function(e) {
  if (e.selectedIndex === -1) {
    return;
  }
	var bServiceAcct = (e.options[e.selectedIndex].value === '0') ? "true" : "false",
    edi = document.getElementById('DirectoryServerType');
  // only toggle these if the deployment type is EDI
  if (edi !== null && edi.options && edi.options[edi.selectedIndex] && edi.options[edi.selectedIndex].value && edi.options[edi.selectedIndex].value.indexOf('EDI') > -1) {
  	toggleConfigOption('ConnectionUsername',bServiceAcct);
  	toggleConfigOption('ConnectionPassword',bServiceAcct);
  }
}
var hRetrievalMethod = function(e) {
  if (e.selectedIndex === -1) {
    return;
  }
	var bUri = e.options[e.selectedIndex].value;
	toggleConfigOption('PhotoUriSubstitutionToken',bUri);
	toggleConfigOption('PhotoUriWithToken',bUri);
	validPhoto(e);
}
var hSipUri = function(e) {
  if (e.selectedIndex === -1) {
    return;
  }
	toggleConfigOption('UriPrefix',e.options[e.selectedIndex].value);
	validSipUri(e);
}
var hEnableFileTransfer = function(e) {
  if (e.selectedIndex === -1) {
    return;
  }
	toggleConfigOption('Disallowed_File_Transfer_Types', e.options[e.selectedIndex].value);
}

// page operation functions
var fnRemoveAllChildren = function(node) {
	var cnt = node.childNodes.length;
	for (var i=cnt;i>-1;i--) {
		if (node.childNodes[i]) {
			if (node.childNodes[i].childElementCount > 1) {
				fnRemoveAllChildren(node.childNodes[i]);
			}
			node.removeChild(node.childNodes[i]);
		}
	}
}

var hideHelp = function() {
	var o = document.getElementById('helpWidget');
	if (o == null) {
		//TODO: report error
		return;
	}
	o.setAttribute('style','display:none;');
}

var fnHelp = function(id) {
	var o = document.getElementById('helpWidget'),
		h = null,
		d = 'dispaly: block;';
	if (o == null) {
		//TODO: report error
		return;
	}
	for (var i=0;i<obj.length;i++) {
		for (var x=0;x<obj[i].options.length;x++) {
			if (obj[i] && obj[i].options[x] && obj[i].options[x].field === id) {
				// IE stores the style attribute without the trailing ;, so we have to modify the getAttribute test here
				if (o.getAttribute('style').indexOf('block') > -1 && o.getAttribute('helpId') == id) {
					hideHelp();
					return;
				} else {
					h = createFieldSet({legend: obj[i].options[x].description+"<a onclick='hideHelp();' class='helpclose'>&nbsp;X&nbsp;</a>", help: obj[i].options[x].help});
					o.setAttribute('helpId',obj[i].options[x].field);
					break;
				}
			}
		}
	}
	fnRemoveAllChildren(o);
	o.appendChild(h);
	o.setAttribute('style',d);
	if (o.clientHeight >= document.documentElement.clientHeight) {
		d += 'height:'+(document.documentElement.clientHeight-50)+'px;';
	}
	o.setAttribute('style',d);
}


var mixin = function(dom,obj) {
	for (var p in obj) {
		if (obj.hasOwnProperty(p)) {
			switch(p) {
				case 'innerHTML':
					dom.innerHTML = obj[p];
					break;
				case 'value':
          // deligate this to the setDefault method instead
					//dom.value = obj[p];
				default:
					if (p == 'type' && obj[p] == 'password') {
						//TODO: IE doesn't like this for some reason
					} else {
						dom.setAttribute(p,obj[p]);
					}
					break;
			}
		}
	}
	return dom;
}

var isDefaultValue = function(obj,value) {
	if (obj == undefined) {
		return false;
	}
	if (obj.formOptions) {
		for (i in obj.formOptions) {
			if (obj.formOptions[i].selected == true) {
				return (obj.formOptions[i].value === value);
			}
		}
	} else if (obj.formInput) {
		return (obj.formInput.value === value);
	}
	return false;
}

var isEmpty = function(map) {
	for(var key in map) {
		if (map.hasOwnProperty(key)) {
			return false;
		}
	}
	return true;
}

var getIEVer = function() {
	var ua = window.navigator.userAgent;
	var ie = ua.indexOf("MSIE ");
	if (ie > 0) {
		return parseInt(ua.substring(ie+5,ua.indexOf(".",ie)));
	} else {
		return 0;
	}
}

var hIMLabel = function(n) {
  var fg = document.getElementById('fgcolor'+n),
    bg = document.getElementById('bgcolor'+n),
    selector = document.getElementById('selector'+n),
    label = document.getElementById('displaymarking'+n),
    sample = document.getElementById('imlabelsample'+n),
    s = null,
    l = null;
  if (!fnFieldSetEnabled(selector) || fg == null || bg == null || selector == null || label == null || sample == null) {
    return false;
  }
  if (selector.value == undefined || selector.value.trim().length == 0) {
    fnError(selector,'Invalid text entered.');
    return false;
  } else {
    fnError(selector,'');
  }
  if (label.value == undefined || label.value.trim().length == 0) {
    label.value = selector.value;
  }
  s = selector.value.toLowerCase().trim();
  l = label.value.toLowerCase().trim();
  if (s.indexOf(l) === -1) {
    fnError(label,'Unable to find substring of Label Text from Dropdown Selection Text.');
    return false;
  } else {
    fnError(label,'');
  }
  sample.innerHTML = (label.value !== undefined && label.value.length > 0) ? label.value : "Sample Text";
  if (fg !== null && bg !== null && fg.value.length > 0 && bg.value.length > 0) {
    sample.setAttribute('style','color:'+fg.value+';background-color:'+bg.value+';');
  }
  return true;
}

var fnFieldSetEnabledById = function(id) {
  if (id === undefined || id == null) {
    return false;
  }
  return fnFieldSetEnabled(document.getElementById(id));
}

var fnFieldSetEnabled = function(e) {
  if (e == undefined || e == null) {
    return false;
  }
  return e.parentElement.parentElement.parentElement.parentElement.parentElement.style.display == '';
}
/*
parseXml
*/

var parseXml;

if (typeof window.DOMParser != "undefined") {
    parseXml = function(xmlStr) {
        return ( new window.DOMParser() ).parseFromString(xmlStr, "text/xml");
    };
} else if (typeof window.ActiveXObject != "undefined" &&
    new window.ActiveXObject("Microsoft.XMLDOM")) {
    parseXml = function(xmlStr) {
        var xmlDoc = new window.ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = "false";
        xmlDoc.loadXML(xmlStr);
        return xmlDoc;
    };
} else {
    throw new Error("No XML parser found");
}

var fnParseInputData = function() {
    var input = document.getElementById('existingFileText'),
    dom = null;
    if (input == null || input.value.trim().length == 0) {
        return null;
    }
    input = input.value.replace(/[^\u0009\u000a\u000d\u0020-\uD7FF\uE000-\uFFFD]+/g,"");
    dom = parseXml(input);
    if (dom == null || dom.getElementsByTagName('parsererror').length > 0) {
        // parsing error
        var msg = dom.getElementsByTagName('parsererror')[0].innerHTML;
        console.log(input);
        alert(msg);
        throw {name: 'FatalError', message: msg };
        return null;
    }
    // iterate over 'obj' to find nodes
    for (var x=0;x<obj.length;x++) {
        if (obj[x].node == undefined) {
            continue;
        }
        // iterate over discovered root tags
        var plugin = (obj[x].node.toLowerCase().indexOf('jabber-plugin-config') > -1),
          idx_jabberplugins = 1,
          idx_instantmessageplugin = 1,
          name = plugin ? 'jabber-plugin-config' : obj[x].node,
          node = dom.getElementsByTagName(name);
        for (var y=0;y<node.length;y++) {
            var children = node[y].children;
            // iterate over values and assign to form
            // since this is only 1 layer deep we can simply do it this way
            for (var z=0;z<children.length;z++) {
                var name = (children[z].tagName.toLowerCase().indexOf('bdi') > -1) ? children[z].tagName.substr(3) : children[z].tagName,
                  o = document.getElementById(name);
                if (o !== null) {
                  switch(o.tagName) {
                    case 'CHECKBOX':
                        var selection = children[z].innerHTML.toLowerCase().split(','),
                        boxes = o.getElementsByTagName('input');
                        for (var a=0;a<boxes.length;a++) {
                            if (selection.indexOf(boxes[a].value.toLowerCase()) != -1) {
                                boxes[a].checked = true;
                            }
                        }
                        break;
                    case 'SELECT':
                        var match = false;
                        for (var a=0;a<o.children.length;a++){
                            if (!match && o.children[a].value.toLowerCase() == children[z].innerHTML.toLowerCase()) {
                                o.selectedIndex = a;
                                o.value = children[z].innerHTML;
                                match = true;
                            }
                        }
                        break;
                    case 'INPUT':
                    default:
                        o.value = children[z].innerHTML;
                        o.setAttribute('value',children[z].innerHTML);
                        break;
                }
              } else if (node.length > 0 && node[0].tagName === 'InstantMessageLabels' && name === 'item') {
                //handle import logic for InstantMessageLables
                var s = document.getElementById('selector'+idx_instantmessageplugin),
                  fg = document.getElementById('fgcolor'+idx_instantmessageplugin),
                  bg = document.getElementById('bgcolor'+idx_instantmessageplugin),
                  lb = document.getElementById('displaymarking'+idx_instantmessageplugin),
                  kids = null,
                  tmp = children[z].getAttribute('selector');
                if (tmp !== null) {
                  s.value = tmp;
                }
                kids = children[z].children;
                for (var b=0;b<kids.length;b++) {
                  var kids2 = kids[b].children;
                  for (var c=0;c<kids2.length;c++) {
                    tmp = kids2[c].getAttribute('fgcolor');
                    if (tmp !== null) {
                      fg.value = tmp;
                    }
                    tmp = kids2[c].getAttribute('bgcolor');
                    if (tmp !== null) {
                      bg.value = tmp;
                    }
                    tmp = kids2[c].innerHTML;
                    if (tmp !== null) {
                      lb.value = tmp;
                    }
                  }
                }

                toggleFieldset('Instant Message Label '+idx_instantmessageplugin);
                idx_instantmessageplugin++;
              } else if (name === 'browser-plugin') {
                //handle import logic for Jabber Plugins
                var page = children[z].children;
                for (var a=0;a<page.length;a++) {
                  var tmp = page[a].getAttribute('refresh')
                    r = document.getElementById('refresh'+idx_jabberplugins),
                    p = document.getElementById('preload'+idx_jabberplugins),
                    t = document.getElementById('tooltip'+idx_jabberplugins),
                    i = document.getElementById('icon'+idx_jabberplugins),
                    u = document.getElementById('url'+idx_jabberplugins);
                  if (tmp !== null) {
                    r.selectedIndex = 0; //TODO:
                    r.value = tmp;
                  }
                  tmp = page[a].getAttribute('preload');
                  if (tmp !== null) {
                    p.selectedIndex = 0; //TODO:
                    p.value = tmp;
                  }
                  var kids = page[a].children;
                  for (var b=0;b<kids.length;b++) {
                    switch(kids[b].tagName.toLowerCase()) {
                      case 'tooltip':
                        t.value = kids[b].innerHTML;
                        break;
                      case 'icon':
                        i.value = kids[b].innerHTML;
                        break;
                      case 'url':
                        u.value = kids[b].innerHTML;
                        break;
                    }
                  }
                  toggleFieldset('Jabber Plugins '+idx_jabberplugins,true);
                  idx_jabberplugins++;
                }
              }
            }
        }
    }

}
/*
  XMLWriter borrowed from http://www.cisco.com/web/cuc_afg/XMLWriter.js
*/
function XMLWriter()
{
  this.XML=[];
  this.Nodes=[];
  this.State="";
  this.LevelIndent = "";
  this.FormatXML = function(Str)
  {
    if (Str)
      return Str.replace(/&(?!amp;)/g, "&amp;").replace(/\"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    return ""
  }
  this.BeginNode = function(Name, Level)
  {
    this.LevelIndent = "";
    while (Level > 0)
    {
      this.LevelIndent = this.LevelIndent + "  ";
      Level = Level -1;
    }
    if (!Name) return;
    if (this.State=="beg") this.XML.push(">");
    this.State="beg";
    this.Nodes.push(Name);
    this.XML.push(this.LevelIndent+"<"+Name);
  }
  this.EndNode = function(Level)
  {
    this.LevelIndent = "";
    while (Level > 0)
    {
      this.LevelIndent = this.LevelIndent + "  ";
      Level = Level -1;
    }
    if (this.State=="beg")
    {
      this.XML.push("/>");
      this.Nodes.pop();
    }
    else if (this.Nodes.length>0)
      this.XML.push(this.LevelIndent+"</"+this.Nodes.pop()+">");
    this.State="";
  }
  this.Attrib = function(Name, Value)
  {
    if (this.State!="beg" || !Name) return;
    this.XML.push(" "+Name+"=\""+this.FormatXML(Value)+"\"");
  }
  this.WriteString = function(Value)
  {
    if (this.State=="beg") this.XML.push(">");
    this.XML.push(this.FormatXML(Value));
    this.State="";
  }
  this.Node = function(Name, Value, Level)
  {
    this.LevelIndent = "";
    while (Level > 0)
    {
      this.LevelIndent = this.LevelIndent + "  ";
      Level = Level -1;
    }
    if (!Name) return;
    if (this.State=="beg") this.XML.push(">");
    this.XML.push((Value=="" || !Value)?this.LevelIndent+"<"+Name+"/>":this.LevelIndent+"<"+Name+">"+this.FormatXML(Value)+"</"+Name+">");
    this.State="";
  }
  this.Close = function()
  {
    while (this.Nodes.length>0)
      this.EndNode();
    this.State="closed";
  }
  this.ToString = function()
  {
    return this.XML.join("");
  }
}

var getXMLObject = function() {
  var newObj = {},
    includeDefault = document.getElementById('includeDefault'),
    bincludeDefault = includeDefault.checked,
    bIncludeBDI = fnIncludeBDI();
  for (var i=0;i<obj.length;i++) {
    if (newObj[obj[i].node] == undefined) {
      newObj[obj[i].node] = {};
    }
    for (var x=0;x<obj[i].options.length;x++) {
      if (!obj[i].options[x]) {
        continue;
      }
      var e = document.getElementById(obj[i].options[x].field);
      if (e == undefined || (e.disabled && e.parentElement.parentElement.style.display == 'none') || obj[i].options[x].ignore === true) {
        //if the field is disabled, that means we don't want to render it in XML
        continue;
      }
      // special handling for checkboxes
      if (obj[i].options[x].formType == "checkbox") {
        for(var c=0;c<e.childNodes.length;c++) {
          var child = e.children[c];
          if (child.tagName != "INPUT") {
            continue;
          }
          if (child.checked == true) {
            if (typeof(newObj[obj[i].node][obj[i].options[x].field]) == 'undefined' || newObj[obj[i].node][obj[i].options[x].field].length == 0) {
              newObj[obj[i].node][obj[i].options[x].field] = child.value;
            } else {
              newObj[obj[i].node][obj[i].options[x].field] += ","+child.value;
            }
          }
        }
        continue;
      }
      var value = (e.options == undefined || e.selectedIndex == -1) ? e.value : e.options[e.selectedIndex].value;
      if (value !== '' && (bincludeDefault || (!isDefaultValue(obj[i].options[x],value) || obj[i].options[x].alwaysInclude == true))) {
        // only add the attribute if it is different from default
        if (obj[i].node && obj[i].node.indexOf('jabber-plugin-config') > -1) {
          var page = document.getElementById('url'+obj[i].pageIndex),
            rootTagName1 = 'Client',
            rootTagName2 = 'jabber-plugin-config',
            rootTagName3 = 'browser-plugin';
          if (page.value == '') {
            // there needs to be a URL for us to add it otherwise skip it
            continue;
          }
          if (!newObj[rootTagName1]) {
            newObj[rootTagName1] = {};
          }
          if (!newObj[rootTagName1][rootTagName2]) {
            newObj[rootTagName1][rootTagName2] = {};
          }
          if (!newObj[rootTagName1][rootTagName2][rootTagName3]) {
            newObj[rootTagName1][rootTagName2][rootTagName3] = [];
          }
          if (!newObj[rootTagName1][rootTagName2][rootTagName3][obj[i].pageIndex]) {
            newObj[rootTagName1][rootTagName2][rootTagName3][obj[i].pageIndex] = {};
          }
          newObj[rootTagName1][rootTagName2][rootTagName3][obj[i].pageIndex][obj[i].options[x].field] = value;
        } else if (obj[i].node && obj[i].node.indexOf('instant-message-label') > -1) {
          var page = document.getElementById('selector'+obj[i].pageIndex),
            rootTagName1 = 'Policies',
            rootTagName2 = 'InstantMessageLabels';
            if (page.value == '') {
              // there needs to be a selector name for us to add it, otherwise skip
              continue;
            }
          if (!newObj[rootTagName1]) {
            newObj[rootTagName1] = {};
          }
          if (!newObj[rootTagName1][rootTagName2]) {
            newObj[rootTagName1][rootTagName2] = [];
          }
          if (!newObj[rootTagName1][rootTagName2][obj[i].pageIndex]) {
            newObj[rootTagName1][rootTagName2][obj[i].pageIndex] = {};
          }
          newObj[rootTagName1][rootTagName2][obj[i].pageIndex][obj[i].options[x].field] = value;
        } else if (bIncludeBDI && obj[i].node === "Directory" && (
          (typeof(obj[i].dirType) !== 'undefined' && obj[i].dirType.indexOf("bdi") > -1)
          || (typeof(obj[i].options[x].dirType) !== 'undefined' && obj[i].options[x].dirType.indexOf("bdi") > -1) ) ) {
          newObj[obj[i].node][obj[i].options[x].field] = value;
          if (obj[i].options[x].field == "UseSSL") {
            newObj[obj[i].node]["BDIEnableTLS"] = value;
          } else {
            newObj[obj[i].node]["BDI"+obj[i].options[x].field] = value;
          }
        } else if (obj[i].options[x].formType == 'input' && obj[i].options[x].formOptions != undefined && obj[i].options[x].formOptions.length > 0 && obj[i].options[x].formOptions[0].type == 'button') {
          continue;
        } else {
          // hack to deal with duplicate key names in legacy versions
          //var field = (obj[i].options[x].field.indexOf("Old") !== 0) ? obj[i].options[x].field : obj[i].options[x].field.substring(3);
          var field = obj[i].options[x].field;
          newObj[obj[i].node][field] = value;
        }
      }
    }
  }
  return newObj;
}

var fnGenerate = function(e) {
	var c = document.getElementById("xmlContainer"),
        i = document.getElementById('xmlInstructions'),
        f = document.getElementById('xmlContent'),
        fc = document.getElementById('paramForm');
	if (c == undefined) {
		//TODO: handle error
		return;
	}
	if (fnValid() && fnValidTelemetry()) {
		//c.setAttribute('style','');
		//c.removeAttribute('style');
		var height = parseInt(window.innerHeight-c.clientHeight-i.clientHeight-200);
		f.setAttribute('style','height:'+height+'px; overflow:auto;');
        //fc.setAttribute('style','display:none;');
        $('#xmlContainer').modal('show');
		writeToXML();
	} else {
		alert('There is one or more error(s) on this page; you must correct them before you can continue.');
	}
}

var writeToXML = function() {
	var strXML = new String();
	strXML = '<?xml version="1.0" encoding="utf-8"?>\n';

  // create obj of flattened hiearchy for xml file
  var newObj = getXMLObject();
	try {

		// render XML structure
    var XML = new XMLWriter();
    XML.BeginNode("config");
    XML.Attrib('version','1.0');
		for (var n in newObj) {
			if (n == 'undefined' || isEmpty(newObj[n])) {
				continue;
			}
			XML.BeginNode(n,1);
			for (var a in newObj[n]) {
				if (a === 'jabber-plugin-config') {
					XML.BeginNode(a,2); //jabber-plugin-config
					for (var b in newObj[n][a]) {
						XML.BeginNode(b,3); //browser-plugin
						for (var p in newObj[n][a][b]) {
							XML.BeginNode('page',4); //page
							if (newObj[n][a][b][p]['refresh'+p] !== undefined) {
								XML.Attrib('refresh',newObj[n][a][b][p]['refresh'+p]);
							} else {
								XML.Attrib('refresh','false');
							}
							if (newObj[n][a][b][p]['preload'+p] !== undefined) {
								XML.Attrib('preload',newObj[n][a][b][p]['preload'+p]);
							} else {
								XML.Attrib('preload','false');
							}
							for (var x in newObj[n][a][b][p]) {
								if (x.indexOf('refresh') > -1 || x.indexOf('preload') > -1) {
									continue;
								}
								XML.Node(x.substr(0,x.length-1),safeXML(newObj[n][a][b][p][x]),5); //attr
							}
							XML.EndNode(4);
						}
						XML.EndNode(3);
					}
					XML.EndNode(2);
        } else if (a === 'InstantMessageLabels') {
          XML.BeginNode(a,2); //InstantMessageLabels
          for (var b in newObj[n][a]) {
            XML.BeginNode('item',3);
            XML.Attrib('selector',newObj[n][a][b]['selector'+b]);
            XML.BeginNode('securitylabel',4);
            XML.BeginNode('displaymarking',5);
            XML.Attrib('fgcolor',newObj[n][a][b]['fgcolor'+b]);
            XML.Attrib('bgcolor',newObj[n][a][b]['bgcolor'+b]);
            XML.WriteString(safeXML(newObj[n][a][b]['displaymarking'+b]));
            XML.EndNode(0);
            XML.EndNode(4);
            XML.EndNode(3);
          }
          XML.EndNode(2);
        } else {
					XML.Node(a,safeXML(newObj[n][a]),2);
				}
			}
			XML.EndNode(1);
		}

		XML.EndNode();
		XML.Close();
	} catch(Err) {
		alert("Error: "+Err.description);
	}
	strXML = strXML + XML.ToString();
	//TODO: create the valid XML characters such as &amp; rather than &
	strXML = strXML.replace(/&/g,"&amp;");
	strXML = strXML.replace(/</g,"&lt;");
	strXML = strXML.replace(/>&lt;/g,"&gt;\n&lt;");
	strXML = strXML.replace(/>\s/g,"&gt;\n");
	strXML = strXML.replace(/>/g,"&gt;");
	renderXML(strXML);
}

var safeXML = function(str) {
	if (typeof(str) == "string") {
		str.replace(/&/g,"&amp;");
		str.replace(/</g,"&lt;");
		str.replace(/>/g,"&gt;");
	}
	return str;
}

var renderXML = function(obj) {
	var d = document.getElementById('xmlContent'),
    range = document.createRange();
	if (d == undefined) {
		//TODO: handle error
		return;
	}
	d.innerHTML = '<pre>'+obj+'</pre>';
	//TODO: trigger after the modal has been displayed?
    window.setTimeout(selectAllXml, 250);
}

var selectAllXml = function() {
  var d = document.getElementById('xmlContent'),
    range = document.createRange();
  if (d == undefined) {
    //TODO: handle error
    return;
  }
  range.setStart(d.firstChild,0);
  range.setEnd(d.firstChild,1);
  window.getSelection().removeAllRanges();
  window.getSelection().addRange(range);
}
