wxc\_sdk.telephony.voice\_messaging module
==========================================

.. automodule:: wxc_sdk.telephony.voice_messaging
   :members:
   :undoc-members:
   :show-inheritance:
