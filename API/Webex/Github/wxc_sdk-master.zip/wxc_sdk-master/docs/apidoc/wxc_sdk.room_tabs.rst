wxc\_sdk.room\_tabs package
===========================

.. automodule:: wxc_sdk.room_tabs
   :members:
   :undoc-members:
   :show-inheritance:
