wxc\_sdk.person\_settings.selective\_reject module
==================================================

.. automodule:: wxc_sdk.person_settings.selective_reject
   :members:
   :undoc-members:
   :show-inheritance:
