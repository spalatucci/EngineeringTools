wxc\_sdk.telephony.organisation\_vm module
==========================================

.. automodule:: wxc_sdk.telephony.organisation_vm
   :members:
   :undoc-members:
   :show-inheritance:
