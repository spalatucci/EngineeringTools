IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'BaseLine')
	DROP DATABASE [BaseLine]
GO

CREATE DATABASE BaseLine

GO

USE BaseLine
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Customers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)														
drop table [dbo].[Customers]		
GO		

CREATE TABLE [dbo].[Customers] (		
		[strAccountNumber] [varchar] (12) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[strFirstName] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[strLastName] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[strAddress] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[strCity] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[strState] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[strZipCode] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[strPhone] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[strEmailAddress] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
		[moneyCheckingBalance] [real] NULL ,
		[moneySavingBalance] [real] NULL ,
		[moneyTotalBalance] [real] NULL ,
		[moneyFees] [real] NULL ,
		[strPIN] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]		
GO		

INSERT INTO Customers VALUES ('11501','Thomas','Smith','1550 Main Street','Metropolis','ST','12341','(555)555-5550','thomas.smith@cisco.com',871.23,7129.75,8000.98,11.75,'1111')
INSERT INTO Customers VALUES ('11502','Elizabeth','Jones','6551 Elm Street','Metropolis','ST','12342','(555)555-5551','elizabeth.jones@cisco.com',10489.34,38691.64,49180.98,23.25,'2222')
INSERT INTO Customers VALUES ('11503','Mark','Johnson','7125 North Avenue','Metropolis','ST','12343','(555)555-5552','mark.johnson@cisco.com',553.33,551.65,1104.98,24.5,'3333')
INSERT INTO Customers VALUES ('11504','Susan','Brown','3939 Spring Avenue','Anytown','ST','12344','(555)555-5553','susan.brown@cisco.com',7217.85,1328.68,8546.53,5.75	,'4444')
INSERT INTO Customers VALUES ('11505','Mike','Davis','5501 West 1st Street','Anytown','ST','12345','(555)555-5554','mike.davis@cisco.com',9591.12,35875.14,45466.26,23.25,'5555')
INSERT INTO Customers VALUES ('11506','Karen','Jackson','135 Park Street','Anytown','ST','12346','(555)555-5555','karen.jackson@cisco.com',2178.23,3975.12,6153.35,9.25,'6666')
INSERT INTO Customers VALUES ('11507','John','Anderson','4737 Oak Street','Suburbia','ST','12347','(555)555-5556','john.anderson@cisco.com',4689.14,6580.36,11269.5,13.75,'7777')
INSERT INTO Customers VALUES ('11508','Lisa','Miller','6235 Willow Road','Suburbia','ST','12348','(555)555-5557','lisa.miller@cisco.com',18975.35,525.14,19500.49,48.25,'8888')
INSERT INTO Customers VALUES ('11509','James','Wilson','1725 Cherry Road','Suburbia','ST','12349','(555)555-5558','james.wilson@cisco.com',8597.51,14586.37,23183.88,25.25,'9999')
