wxc\_sdk.workspace\_locations package
=====================================

.. automodule:: wxc_sdk.workspace_locations
   :members:
   :undoc-members:
   :show-inheritance:
