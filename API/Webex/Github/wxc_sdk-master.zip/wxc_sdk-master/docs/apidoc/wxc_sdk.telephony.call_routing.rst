wxc\_sdk.telephony.call\_routing package
========================================

.. automodule:: wxc_sdk.telephony.call_routing
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   wxc_sdk.telephony.call_routing.translation_pattern
