voicemailQueueing.aef:
***********************
Description:
============
This script is used to queue the phantom call the contains a caller's 
voicemail and callback number

How it works:
=============
(1) Accepts the incoming contact
(2) Saves the contact id to be used to retrieve the session that stores 
	the voicemail and callback number
(3) Gets the session using the contact id
(4) Gets the session info such as voicemail recording and callback number
(5) Passes that session info into Enterprise call variables to be presented on 
	the agent's CAD
(6) queues the contact

Instructions:
=============
Make sure that you use the contact id to retrieve the session
Make sure you retrieve the session data such as voicemail recording and callback number
Make sure you pass the same important data on to the agent's CAD
Need to create an ECC variable for the custom layout to be shown
on the agent's desktop.  The custom layout must be created in Cisco
Desktop Administrator

