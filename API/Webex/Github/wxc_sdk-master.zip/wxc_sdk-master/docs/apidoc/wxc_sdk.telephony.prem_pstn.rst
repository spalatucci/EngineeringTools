wxc\_sdk.telephony.prem\_pstn package
=====================================

.. automodule:: wxc_sdk.telephony.prem_pstn
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   wxc_sdk.telephony.prem_pstn.dial_plan
   wxc_sdk.telephony.prem_pstn.route_group
   wxc_sdk.telephony.prem_pstn.route_list
   wxc_sdk.telephony.prem_pstn.trunk
