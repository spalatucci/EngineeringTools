autoAgentGreeting.aef
*********************
Description:
============
This script is designed to be a subflow called from an icd application such as
"MusicianSupply.aef".  This subflow gets the responding agent's ID and checks the
prompt repository to see if the agent has a prerecorded greeting and plays it to
the caller if it exists.

How it works:
=============
(1) uses Get User Info step to retrieve the agent's user ID
(2) uses that agentID to play the prerecorded prompt if it exists
(3) exits subflow

Instructions:
=============
When inserting this as a subflow in another script, be sure to map the input from
the calling script to autoAgentGreeting.aef.  
(1) Map the user variable resulting from the "Select Resource" step to "Agent" (which
	is the corresponding user variable in autoAgentGreeting.aef)

Also remember that in order to use this, you must call the subflow AFTER the resource
is selected but BEFORE the caller is connected to the resource.
(1) make sure that the "Connect" radio button under "Properties" is set to "No"