wxc\_sdk.person\_settings.call\_policy module
=============================================

.. automodule:: wxc_sdk.person_settings.call_policy
   :members:
   :undoc-members:
   :show-inheritance:
