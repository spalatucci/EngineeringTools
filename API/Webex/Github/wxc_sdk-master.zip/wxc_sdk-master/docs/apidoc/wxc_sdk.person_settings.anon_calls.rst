wxc\_sdk.person\_settings.anon\_calls module
============================================

.. automodule:: wxc_sdk.person_settings.anon_calls
   :members:
   :undoc-members:
   :show-inheritance:
