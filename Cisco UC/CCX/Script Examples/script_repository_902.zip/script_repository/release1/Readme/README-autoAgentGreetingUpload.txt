autoAgentGreetingUpload.aef:
************************
Description:
============
This script represents an application for an agent to create customer facing whispers
to be played to the caller so that the agent does not have to repeat their greeting 
for every call they handle.

How it works:
=============
(1) The agent dials in to the application
(2) agent records his/her greeting
(3) based on the agent's extension, the app looks up their profile
(4) app asks agent to enter PIN
(5) app authenticates user
(6) app plays recording back to agent
(7) uploads prompt to server

Instructions:
=============
Deploy and run