wxc\_sdk.person\_settings.selective\_accept module
==================================================

.. automodule:: wxc_sdk.person_settings.selective_accept
   :members:
   :undoc-members:
   :show-inheritance:
