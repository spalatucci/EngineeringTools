wxc\_sdk.person\_settings.receptionist module
=============================================

.. automodule:: wxc_sdk.person_settings.receptionist
   :members:
   :undoc-members:
   :show-inheritance:
