wxc\_sdk.cdr package
====================

.. automodule:: wxc_sdk.cdr
   :members:
   :undoc-members:
   :show-inheritance:
