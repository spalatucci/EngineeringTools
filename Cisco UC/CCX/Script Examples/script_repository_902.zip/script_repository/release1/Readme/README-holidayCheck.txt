holidayCheck.aef:
*****************
Description:
============
This script can be used to parse an xml document, 
compare it to todays date, and set a boolean var to 
true that can be tested to determine what treatment to 
take.

How it works:
=============
(1) gets an instance of the current date
(2) goes through the dates.xml file, comparing each entry to the current date
(3) if anyone of the dates match, set todayIsAHoliday to true, otherwise false

Instructions:
=============
The file contains a list of holiday dates in the string format of:
mm/dd/yyyy
To get started, you can paste the following contents into the file called dates.xml which will be present in uccx.customer.dir Directory


<?xml version="1.0" encoding="ISO-8859-1"?>
<Holidays>
<Holiday1>12/25/06</Holiday1>
<Holiday2>01/01/07</Holiday2>
<Holiday3></Holiday3>
</Holidays> 

To use as a subflow, make sure to map the output.  Map "todayIsAHoliday" to a
boolean variable in the calling script that will signify whether today is a holiday
or not.