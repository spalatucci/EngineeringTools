wxc\_sdk.team\_memberships package
==================================

.. automodule:: wxc_sdk.team_memberships
   :members:
   :undoc-members:
   :show-inheritance:
