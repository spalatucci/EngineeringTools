wxc\_sdk.person\_settings.exec\_assistant module
================================================

.. automodule:: wxc_sdk.person_settings.exec_assistant
   :members:
   :undoc-members:
   :show-inheritance:
