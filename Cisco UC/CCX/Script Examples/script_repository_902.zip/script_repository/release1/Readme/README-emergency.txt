emergency.aef:
***************
Description:
============
This script allows an authorized administrator to call into the script and enable
or disable emergency routing for him.

How it works:
=============
(1) User calls into script (User need to have Administrator capabilities)
(2) prompted to enter username followed by #
(3) if successful, last name and then first name
(4) Checks users.xml to see if existing user is on authorized list, is then prompted for PIN
(5) enter PIN followed by #
(6) if successful, goes to menu: press 1 to enable, press 2 to disable, 3 to cancel
(7) if enable/disable, value is substituted into emergency_template.xml and written to emergency.xml

Instructions:
=============
 All the prompts need to be  refactored  and  uploaded in en_US location using Prompt management from UCCX appadmin
Need 3 files:
    o users.xml
    o emergency_template.xml
    o emergency.xml
 and they should be place in the Customer location of UCCX
users.xml contains a list of user id's that are authorized to access this script
The contents should follow this structure:
<?xml version="1.0" encoding="ISO-8859-1"?>
<Users>
	<User1>conrchan</User1>
	<User2></User2>
	<User3></User3>
</Users>

emergency_template.xml should look like this exactly:
<?xml version="1.0" encoding="ISO-8859-1"?>
<Emergencys>
	<Emergency1>%value%</Emergency1>
</Emergencys>

emergency.xml should look like emergency_template.xml but with the string "true" 
or "false" instead of "%value%"


