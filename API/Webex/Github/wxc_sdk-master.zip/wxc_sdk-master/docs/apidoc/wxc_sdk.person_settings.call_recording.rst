wxc\_sdk.person\_settings.call\_recording module
================================================

.. automodule:: wxc_sdk.person_settings.call_recording
   :members:
   :undoc-members:
   :show-inheritance:
