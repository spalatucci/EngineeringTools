queuestats.aef:
***************
Queue Statistics Template

Description:
============
This script is designed to be used as a tool for an agent, supervisor
or administrator to view the queue statistics on a browser.  The script
will gather the desired statistics, substitute their values into the
HTML template page and return the HTML page

How it works:
=============
(1) User clicks a link to view queuestats
(2) use Get Reporting Statistic step to gather desired information 
	(calls in queue, agents logged in, and agents busy in this case)
(3) substitute values into the queueStats-template.html
(4) send HTTP response back to user


Instructions:
=============
For whatever statistics you would like to monitor, create an approprate
variable and utilize the Get Reporting Statistic step, remembering
to provide the name of the CSQ you would like to monitor.  The name of
the CSQ is a parameter so you can modify it in Application Administrator.

You will need an HTML template file for the web page that will display the 
statistics.  The HTML template (queueStats-template.html) in this example is:
Given below	

	<html>
	<head><h1>Queue Statistics</h1></head>
	<body>
		Calls in Queue: %callsInQueue%
		Agents Logged In: %agentsLoggedIn%
		Agents Busy: %agentsBusy%
	</body>
	</html>

This html file can be uploaded in uccx via doc manager.
the url of this doc can be used in the script.	
Then, remember to change the statistics to strings (.toString()) and
substitute them into the template page with the Keyword Transform
step.

