wxc\_sdk.person\_settings.priority\_alert module
================================================

.. automodule:: wxc_sdk.person_settings.priority_alert
   :members:
   :undoc-members:
   :show-inheritance:
