utility-CSQ-based_MOH.aef:
**************************
Description:
============
This script is designed to be used as a ICD queueing subflow.  Based on
the name of the CSQ that is passed in to this script, the message that the
caller will hear while "being on hold" in the queue is unique to that queue.

How it works:
=============
(1) CSQ value passed from calling script is used in a switch statement
(2) The correct unique MOH prompt is set for that particular CSQ
(3) The caller is placed in queue and played the unique MOH prompt

Instructions:
=============
When inserting this as a subflow in another script, be sure to map the input 
from the calling script to utility-CSQ-based_MOH.aef.  
(1) Map the String variable identifying the CSQ being used in the calling app to "CSQ" on the input side

Also be sure to modify the "Switch String" step to customize to your own CSQ's to properly handle
whatever CSQ string is inputted from the calling script.