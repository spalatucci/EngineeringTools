holidayApp.aef:
***************
Description:
============
This script is designed so that an Administrator can insert holiday dates into
dates.xml through a dial-in interface instead of having to manually open the
XML file to modify the holidays.

How it works:
=============
(1) User calls in (User shouls have a pin and in UCCX it should have Administrator capability)
(2) Prompted to enter userID, followed by #
(3) Prompted to enter last name, first name to identify
(4) Prompted to enter PIN, followed by #
(5) Authenticates
(6) Prompted to enter new holiday date in the form of 6 digits (i.e. 080606 for August 6, 2006)
(7) Opens dates.xml
(8) processes date to be inserted into dates.xml
(9) Writes new dates.xml to disk
(10) Prompts user to enter another holiday date or to exit

Instructions:
=============
Need a file called dates.xml in UCCX Customer folder location 
with contents of the form:

<?xml version="1.0" encoding="ISO-8859-1"?>
<Holidays>
<Holiday1>12/25/06</Holiday1>
</Holidays>

Need ADMINISTRATOR to call into application, will need to supply:
o userID
o lastname, firstname
o PIN

MUST enter holiday dates on touchtone phone in 6 digit form:
	MMDDYY - so 080606 represents 8/6/06, or August 6, 2006