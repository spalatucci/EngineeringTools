Description:
============
This script itself allows a caller to record a voicemail message to be left
in queue for an agent to later pick up, listen to the message, and to call
back the original caller.

How it works:
=============
(1) caller prompted with implicit confirmation so if they don't interrupt, the 
	script will exit back out to the calling flow (most likely the queue)
(2) if caller wants to leave a message, the calling number is stored for later callback
(3) caller is prompted to record their voicemail followed by "#" when finished
(4) caller is prompted to review their message or finish
	(a) if review message, message is played back and they're prompted to rerecord
	(b) if finish, end the call
(5) a phantom call is placed to the route point for the voicemail_queueing.aef application
	(a) The recorded voicemail message is saved under: uccx.customer.dir location
		in case the phantom call is lost.  The format is:
			"identifier" + Contact Identifier + "callback" + callingNumber + ".wav"
			So basically if the identifier is "34" and the calling number is "1012" the saved WAV file is: "identifier34callback1012.wav"
(6) create a new session variable with the same session id as the contact id of the placed call to the voicemail_queueing
(7) set session variables such as the callback number and the recorded voicemail
(8) Prompt the voicemail_queueing contact (will be an agent) to
	(a) press 1 - listen to voicemail
	(b) press 2 - call the callback number


Instructions:
=============
To allow this voicemail callback feature to be easily plugged into another
application, you must hard code the route point of the voicemail queueing
application into the "to_icd_number" variable or its equivalent.

Be sure to have created a folder " voicemail " under default location and it should created via prompt manager and upload all the required prompt there
