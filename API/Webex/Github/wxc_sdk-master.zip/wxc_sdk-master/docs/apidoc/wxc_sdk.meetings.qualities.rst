wxc\_sdk.meetings.qualities package
===================================

.. automodule:: wxc_sdk.meetings.qualities
   :members:
   :undoc-members:
   :show-inheritance:
