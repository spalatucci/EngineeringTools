wxc\_sdk.telephony.location.receptionist\_contacts module
=========================================================

.. automodule:: wxc_sdk.telephony.location.receptionist_contacts
   :members:
   :undoc-members:
   :show-inheritance:
