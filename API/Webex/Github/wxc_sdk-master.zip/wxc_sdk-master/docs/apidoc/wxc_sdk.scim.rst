wxc\_sdk.scim package
=====================

.. automodule:: wxc_sdk.scim
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   wxc_sdk.scim.bulk
   wxc_sdk.scim.groups
   wxc_sdk.scim.users

Submodules
----------

.. toctree::
   :maxdepth: 4

   wxc_sdk.scim.child
