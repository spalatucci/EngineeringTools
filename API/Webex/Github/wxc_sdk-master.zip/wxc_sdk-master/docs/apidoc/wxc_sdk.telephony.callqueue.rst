wxc\_sdk.telephony.callqueue package
====================================

.. automodule:: wxc_sdk.telephony.callqueue
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   wxc_sdk.telephony.callqueue.announcement
   wxc_sdk.telephony.callqueue.policies
