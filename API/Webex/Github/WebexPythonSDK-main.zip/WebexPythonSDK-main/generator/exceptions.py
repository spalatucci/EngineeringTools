class ActionNotFoundError(Exception):
    pass


class PropertyNotFoundError(Exception):
    pass


class MissingKeyError(Exception):
    pass
