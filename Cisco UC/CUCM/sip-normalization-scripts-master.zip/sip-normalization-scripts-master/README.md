# SIP Normalization Scripts

Collection of personally written and sourced SIP Normalization Scripts for CUCM.

Originally sourced scripts include links as far as possible.
