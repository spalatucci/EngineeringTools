wxc\_sdk.teams package
======================

.. automodule:: wxc_sdk.teams
   :members:
   :undoc-members:
   :show-inheritance:
