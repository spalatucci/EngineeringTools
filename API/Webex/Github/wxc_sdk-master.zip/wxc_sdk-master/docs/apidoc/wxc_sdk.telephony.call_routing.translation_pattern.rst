wxc\_sdk.telephony.call\_routing.translation\_pattern package
=============================================================

.. automodule:: wxc_sdk.telephony.call_routing.translation_pattern
   :members:
   :undoc-members:
   :show-inheritance:
