wxc\_sdk.telephony.conference package
=====================================

.. automodule:: wxc_sdk.telephony.conference
   :members:
   :undoc-members:
   :show-inheritance:
