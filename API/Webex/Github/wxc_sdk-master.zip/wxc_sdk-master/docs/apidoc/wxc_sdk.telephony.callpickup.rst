wxc\_sdk.telephony.callpickup module
====================================

.. automodule:: wxc_sdk.telephony.callpickup
   :members:
   :undoc-members:
   :show-inheritance:
