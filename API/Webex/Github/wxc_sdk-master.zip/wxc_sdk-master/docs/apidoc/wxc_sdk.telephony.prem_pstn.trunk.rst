wxc\_sdk.telephony.prem\_pstn.trunk module
==========================================

.. automodule:: wxc_sdk.telephony.prem_pstn.trunk
   :members:
   :undoc-members:
   :show-inheritance:
