wxc\_sdk.person\_settings.monitoring module
===========================================

.. automodule:: wxc_sdk.person_settings.monitoring
   :members:
   :undoc-members:
   :show-inheritance:
