webcallbackQueueing.aef:
*************************
Description:
============
This script is used to queue the phantom call the contains a potential
caller's web form data that requests a callback, such as name, callback
number, and description of problem

How it works:
=============
(1) Saves the contact id and use it to retrieve the session variable that 
	contains the web form data
(2) Retrieves the web form data from the session variable
(3) Maps the values from the web form to variables that will be shown on the CAD
(4) Queues the phantom call

Instructions:
=============
Make sure that you use the contact id to retrieve the session
Make sure you retrieve the session data such as name, callback number
Make sure you pass the same important data on to the agent's CAD
Need to create an ECC variable for the custom layout to be shown
on the agent's desktop.  The custom layout must be created in Cisco
Desktop Administrator
