wxc\_sdk.person\_settings.call\_waiting module
==============================================

.. automodule:: wxc_sdk.person_settings.call_waiting
   :members:
   :undoc-members:
   :show-inheritance:
