wxc\_sdk.authorizations package
===============================

.. automodule:: wxc_sdk.authorizations
   :members:
   :undoc-members:
   :show-inheritance:
