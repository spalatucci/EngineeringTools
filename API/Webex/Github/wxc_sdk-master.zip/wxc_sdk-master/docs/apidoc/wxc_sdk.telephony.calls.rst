wxc\_sdk.telephony.calls module
===============================

.. automodule:: wxc_sdk.telephony.calls
   :members:
   :undoc-members:
   :show-inheritance:
