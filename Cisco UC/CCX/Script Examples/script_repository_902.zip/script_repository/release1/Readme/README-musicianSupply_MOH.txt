musicianSupply_MOH.aef:
***********************
Description:
============
This variant of the musicianSupply.aef script is used to show how the script
utility-CSQ-based_MOH.aef can be used as a subflow to provide CSQ based
message on hold capability.

How it works:
=============
In place of the normal Guitar, Bass, and Drum Queues in the original musicianSupply.aef, 
musicianSupply_MOH.aef calls utility-CSQ-based_MOH.aef as subflows in order to play
customized MOH prompts for each queue.

Instructions:
=============
Follow the instructions in README-musicianSupply.txt