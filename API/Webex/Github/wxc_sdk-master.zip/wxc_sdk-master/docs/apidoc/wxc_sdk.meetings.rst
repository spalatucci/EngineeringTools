wxc\_sdk.meetings package
=========================

.. automodule:: wxc_sdk.meetings
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   wxc_sdk.meetings.chats
   wxc_sdk.meetings.closed_captions
   wxc_sdk.meetings.invitees
   wxc_sdk.meetings.participants
   wxc_sdk.meetings.preferences
   wxc_sdk.meetings.qanda
   wxc_sdk.meetings.qualities
   wxc_sdk.meetings.recordings
   wxc_sdk.meetings.transcripts
