wxc\_sdk.workspace\_settings.devices package
============================================

.. automodule:: wxc_sdk.workspace_settings.devices
   :members:
   :undoc-members:
   :show-inheritance:
