wxc\_sdk.telephony.dect\_devices package
========================================

.. automodule:: wxc_sdk.telephony.dect_devices
   :members:
   :undoc-members:
   :show-inheritance:
