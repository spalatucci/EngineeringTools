wxc\_sdk.person\_settings.calling\_behavior module
==================================================

.. automodule:: wxc_sdk.person_settings.calling_behavior
   :members:
   :undoc-members:
   :show-inheritance:
