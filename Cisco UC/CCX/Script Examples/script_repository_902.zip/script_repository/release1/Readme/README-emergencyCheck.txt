emergencyCheck.aef:
*******************
Description:
============
This template is used to check the state of emergency routing

How it works:
=============
(1) parses emergency.xml to see if value is "true" or "false"
(2) based on the value, the isEmergency variable is set

Instructions:
=============
Use this script as a subflow in any call center script to check to see if emergency routing has been enabled
The variable "isEmergency" is a boolean variable that will return the status of emergency routing

Need a file: emergency.xml" with the following structure and it should be located in customer folder of UCCX

<?xml version="1.0" encoding="ISO-8859-1"?>
<Emergencys>
	<Emergency1>false</Emergency1>
</Emergencys>

To use as a subflow, make sure to map the output.  Map "isEmergency" to a
boolean variable in the calling script that will signify whether emergency
routing has been activated.