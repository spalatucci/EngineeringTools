wxc\_sdk.person\_settings.preferred\_answer module
==================================================

.. automodule:: wxc_sdk.person_settings.preferred_answer
   :members:
   :undoc-members:
   :show-inheritance:
