wxc\_sdk.telephony.hg\_and\_cq module
=====================================

.. automodule:: wxc_sdk.telephony.hg_and_cq
   :members:
   :undoc-members:
   :show-inheritance:
