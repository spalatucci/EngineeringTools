wxc\_sdk.telephony.supervisor package
=====================================

.. automodule:: wxc_sdk.telephony.supervisor
   :members:
   :undoc-members:
   :show-inheritance:
