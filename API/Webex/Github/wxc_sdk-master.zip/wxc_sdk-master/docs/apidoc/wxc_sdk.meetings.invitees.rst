wxc\_sdk.meetings.invitees package
==================================

.. automodule:: wxc_sdk.meetings.invitees
   :members:
   :undoc-members:
   :show-inheritance:
