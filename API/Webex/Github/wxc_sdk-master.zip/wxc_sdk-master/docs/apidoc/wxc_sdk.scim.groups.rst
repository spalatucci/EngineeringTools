wxc\_sdk.scim.groups package
============================

.. automodule:: wxc_sdk.scim.groups
   :members:
   :undoc-members:
   :show-inheritance:
